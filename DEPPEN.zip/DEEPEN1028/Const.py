DEFAULT_FOLD='StratifiedKFold'
TRAIN_TEST_RAIR_NUM='5'
LIMIT_FILE_SIZE=30
MAX_FRE_NUM=20
EXAMPLE_FILENAME=r'.\ex\demo.txt'
WINDOW_SIZE=3
MISMATCH_SIZE=1
KSPACE_SIZE=2
STRIDE_SIZE=1
VOCAB_SIZE=200
GENERAL_METHOD=['Kmer','WindowsSplit','SentencePiece','WordPiece','BPE']
DL_METHOD=['WindowsSplit','SentencePiece','WordPiece','BPE']
FeatureFusionMethod=['RCKmer+Mismatch','Kmer+AAC','Binary+ENAC']

TRAIN_RATIO=4
TEST_RATIO=1

NUM_WORKERS=4

POS_LABEL=1

DL_MODEL=['CNN','MLP','RNN','LSTM','GRU','RNN_Multihead_Attention','CNN_Multihead_Attention','RNN_Simple_Attention','CNN_Simple_Attention','Attention']
SEQ_MODEL=['RNN','LSTM','GRU','RNN_Multihead_Attention','RNN_Simple_Attention']

'''
    DL paramList
'''
EPOCHS=1000
MAX_EPOCHS=100000
BATCH_SIZE=64
LEARNING_RATE=0.001
FILTER_SIZE=3 #A single number is a number, multiple are lists
FILTER_NUM=16
STRIDE=1
TOPK=1
DILATION=1
EMBED_SIZE=16
LAYER_NUM=5
N_HEADS=1
HIDDEN_DIM=1
HIDDEN_SIZE=16

'''
    ML paramList
'''
#Bagging
N_ESTIMATOR=10
N_JOBS=1

#KNeighbors
N_NEIGHBORS=3

#LGBM
NUM_LEAVES=31
MAX_DEPTH=2000

#RandomForest
N_TREES=100

#SVM
PENALITY=1.0