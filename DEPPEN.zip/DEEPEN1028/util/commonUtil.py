import re
import numpy as np
import random
import pandas as pd
def tsne(data):
    from sklearn.manifold import TSNE
    embedded = TSNE(n_components=2).fit_transform(data)
    x_min, x_max = np.min(embedded, 0), np.max(embedded, 0)
    embedded = embedded / (x_max - x_min)
    return embedded
def kmeans(data,k=10):
    from sklearn.cluster import KMeans
    km = KMeans(n_clusters=k)
    km.fit(data)
    C_i = km.predict(data)
    centers = km.cluster_centers_
    return C_i,centers


def getTimeStr():
    import datetime
    timestr = datetime.datetime.now().strftime('%Y%m%d')
    return timestr
def load_data_from_text(sample_name,feature_name,text):
    """

    :param text:
    :return: 特征名称会根据生成特征个数按照F_0..F_XX起名 具体是ACGT何种组合还需要在编码方式里面看
    """

    DataFram = pd.DataFrame(text)
    data = DataFram.iloc[:, :-1]
    row = data.index.size  # 行 样本
    column = data.columns.size  # 列 特征
    data.index = sample_name#['Sample_%s' % i for i in range(row)]
    data.columns =feature_name #['F_%s' % i for i in range(column)]
    datalabel = np.array(DataFram.iloc[:, -1]).astype(int) #标签
    data_sample_purpose = np.array([True] * row)
    return datalabel,data
def preprocess_fasta(data):
    """
    :param file:
    :return:
    """
    msg = ''
    records = data.split('>')[1:]
    fasta_sequences = []
    for fasta in records:
        array = fasta.split('\n')
        #preprocess
        header, sequence = array[0].split()[0], re.sub('[^ACDEFGHIKLMNPQRSTUVWY-]', '-', ''.join(array[1:]).upper())
        header_array = header.split('|')
        #gene name
        name = header_array[0]
        #label
        label = header_array[1] if len(header_array) >= 2 else '0'
        #training or testing
        label_train = header_array[2] if len(header_array) >= 3 else 'training'
        fasta_sequences.append([name, sequence, label, label_train])
    #judge 
    sample_purpose = np.array([item[3] == 'training' for item in fasta_sequences])
    return fasta_sequences, sample_purpose, msg
def get_sample_purpose(data):
    msg = ''
    records = data.split('>')[1:]
    fasta_sequences = []
    for fasta in records:
        array = fasta.split('\n')
        #preprocess
        header, sequence = array[0].split()[0], re.sub('[^ACDEFGHIKLMNPQRSTUVWY-]', '-', ''.join(array[1:]).upper())
        header_array = header.split('|')
        #gene name
        name = header_array[0]
        #label
        label = header_array[1] if len(header_array) >= 2 else '0'
        #training or testing
        label_train = header_array[2] if len(header_array) >= 3 else 'training'
        fasta_sequences.append([name, sequence, label, label_train])
    #judge 
    sample_purpose=None
    if len(fasta_sequences)>0 and len(fasta_sequences[0])>=4:
        sample_purpose = np.array([item[3] == 'training' for item in fasta_sequences])
    return sample_purpose
def getSeqData(data):
    fasta_sequences, sample_purpose, msg=preprocess_fasta(data)
    seqData=[]
    for i in len(fasta_sequences):
        seqData.append(fasta_sequences[i][1])
    return seqData

def str2param(str):
    params={}
    allpair=str.split(';')
    if(allpair[0]!=''):
        for pair in allpair:
            if pair=='':
                continue
            p=pair.split(':')[0]
            v=pair.split(':')[1]
            params[p]=v
    return params

def getSeqType(list):
        fasta_list,_,_=preprocess_fasta(list)
        tmp_fasta_list = []
        if len(fasta_list) < 100:
            tmp_fasta_list = fasta_list
        else:
            random_index = random.sample(range(0, len(fasta_list)), 100)
            for i in random_index:
                tmp_fasta_list.append(fasta_list[i])

        sequence = ''
        for item in tmp_fasta_list:
            sequence += item[1]

        char_set = set(sequence)
        if 5 < len(char_set) <= 21:
            for line in fasta_list:
                line[1] = re.sub('[^ACDEFGHIKLMNPQRSTVWY]', '-', line[1])
            return 'Protein'
        elif 0 < len(char_set) <= 5 and 'T' in char_set:
            return 'DNA'
        elif 0 < len(char_set) <= 5 and 'U' in char_set:
            for line in fasta_list:
                line[1] = re.sub('U', 'T', line[1])
            return 'RNA'
        else:
            return 'Unknown'

def getDataDistribution(text):#需要修改
    return {'Label 1':60,'Label 0':40}

