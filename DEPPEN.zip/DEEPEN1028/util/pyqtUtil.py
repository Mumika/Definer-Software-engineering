from PyQt5.QtGui import QIntValidator,QFont
from PyQt5.QtWidgets import QLineEdit
from PyQt5.QtCore import Qt
from PyQt5.QtCore import pyqtSignal
def getIntLineEdit(self):
        edit1=QLineEdit()
        edit1.setValidator(QIntValidator())
        edit1.setMaxLength(4)
        edit1.setAlignment(Qt.AlignRight)
        edit1.setFont(QFont('Arial',10))
        return edit1

class ClickLineEdit(QLineEdit):
    clicked = pyqtSignal()
    def mouseReleaseEvent(self, QMouseEvent):
        if QMouseEvent.button() == Qt.LeftButton:
            self.clicked.emit()
def getLineEdit(value='',placeholder=''):
        edit1=ClickLineEdit()
        edit1.setAlignment(Qt.AlignRight)
        edit1.setFont(QFont('Arial',10))
        edit1.setPlaceholderText(placeholder)
        edit1.setText(value)
        return edit1