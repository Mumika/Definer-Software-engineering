from numpy import not_equal
from util.commonUtil import kmeans, tsne
from CommonClass import FastaFile, MyFile
from CommonWidget import ResultTable
import qdarkstyle
import sys
from PyQt5.QtGui import QIcon,QFont,QStandardItemModel,QStandardItem 
from PyQt5.QtWidgets import (QWidget,QFileDialog,QFormLayout,QRadioButton,QSplitter,QTabWidget,QLabel,QTextEdit,QPushButton,QLineEdit,QTableWidgetItem,
                              QMainWindow,QDesktopWidget,QApplication,QGridLayout,QVBoxLayout,QMessageBox)
from PyQt5.QtCore import QObject,Qt,pyqtSignal
from PyQt5.QtGui import QIntValidator
from PyQt5.QtWebEngineWidgets import *
import PlotWidgets
import sip

global kmeansData

class KmeansData(object):
    def __init__(self):
        self.embedData=None
        self.tsne_data=None
        self.k=None
        self.C_i=None
        self.centers=None

class InputWidget(QWidget):
    # input_signal = pyqtSignal()
    input_signal= pyqtSignal()#object,object,object,object,object,object)
    
    def __init__(self):
        super().__init__()
        self.initUI()
        self.setMaximumHeight(400)


    def initUI(self):

        self.setMaximumHeight(400)
        self.inputTitle = QLabel('Please upload your sequence results after embedding')
        self.inputTitle.setFont(QFont('Arial', 12))
        
        self.uploadTitle = QLabel('You can also load a  file(.csv)')
        self.uploadTitle.setFont(QFont('Arial', 9))
        self.uploadBtn = QPushButton("Upload a file", self)
        self.uploadBtn.clicked.connect(self.importButtonClicked)

        self.dataTable=ResultTable()
        #Set grid
        #input widget includes text and file 
        grid = QGridLayout()
        grid.addWidget(self.inputTitle, 0, 0,1,1)
        grid.addWidget(self.uploadTitle, 1, 0,1,2)
        grid.addWidget(self.uploadBtn, 2, 0,1,2)
        grid.addWidget(self.dataTable, 3, 0,1,2)
        # grid.addWidget(self.clearBtn, 3, 1,1,1)
        # grid.addWidget(self.confirmBtn, 2, 1,1,1)
        # grid.addWidget(self.progress_bar, 4, 0,1,1)
        
        self.setLayout(grid)
    def importButtonClicked(self):
        fname = QFileDialog.getOpenFileName(self, 'Open file','','Text files (*.csv)')
        if fname[0]:
            self.file=MyFile(fname[0],'csv')
            data,msg=self.file.readData()
            if len(msg)>0:
                QMessageBox.about(self,'Error',"Please upload the file again.")
            else:
                self.dataTable.updateData(None,data.values,None)
                global kmeansData
                kmeansData=KmeansData()
                tsne_data=tsne(data.values[:,1:])
                C_i,centers=kmeans(tsne_data,k=10)
                # self.plotGraph.plotKmeans(tsne_data,C_i,centers,10,data.values[:,0])
                kmeansData.embedData=data
                kmeansData.tsne_data=tsne_data
                kmeansData.C_i=C_i
                kmeansData.k=10
                kmeansData.centers=centers
                self.input_signal.emit()#kmeansData.tsne_data,kmeansData.C_i,kmeansData.centers,kmeansData.k,kmeansData.embedData.values[:,0],'Spatial clustering results of embedding data after dimension reduction')


class MainWidget(QWidget):
    def __init__(self):
        super().__init__()
        self.initUI()


    def initUI(self):
        self.grid = QGridLayout()
        self.inputWidget=InputWidget()
        self.plotGraph = PlotWidgets.FigureWidget()
        self.inputWidget.input_signal.connect(self.refreshGraph)
        self.grid.addWidget(self.inputWidget, 0, 0,1,1)
        self.grid.addWidget(self.plotGraph, 1, 0,1,1)
        self.setLayout(self.grid)

    def refreshGraph(self):
        global kmeansData
        # self.clear_graph()
        self.grid.removeWidget(self.plotGraph)
        sip.delete(self.plotGraph)

        self.plotGraph = PlotWidgets.FigureWidget()
        self.plotGraph.figureCanvas.plotKmeans(kmeansData.tsne_data,kmeansData.C_i,kmeansData.centers,kmeansData.k,kmeansData.embedData.values[:,0],'Spatial clustering results of embedding data after dimension reduction')
        self.grid.addWidget(self.plotGraph, 1, 0,1,1)

    def clear_graph(self):
        self.grid.removeWidget(self.plotGraph)
        sip.delete(self.plotGraph)
        self.plotGraph = PlotWidgets.FigureWidget()
        self.grid.addWidget(self.plotGraph, 1, 0,1,1)

#MainWindow
class MainWindow(QMainWindow):
    close_signal = pyqtSignal(str)
    def __init__(self):
        super().__init__()
        self.initUI()


    def initUI(self):
        
        #Set window properties
        self.setWindowTitle('Embedding')
        self.center()

        #Set style
        self.setStyleSheet(qdarkstyle.load_stylesheet_pyqt5())
    
        #Set core widget   
        self.mtab = MainWidget()
        self.setCentralWidget(self.mtab)
        

        self.show()

    #Set its size and location
    def center(self):
        self.resize(800, 600)
        self.setWindowState(Qt.WindowMaximized)#set windowMaximized
        qr=self.frameGeometry()
        cp = QDesktopWidget().availableGeometry().center()
        qr.moveCenter(cp)
        self.move(qr.topLeft())

    def closeEvent(self, event):
        reply = QMessageBox.question(self, 'Confirm Exit', 'Are you sure want to quit?', QMessageBox.Yes | QMessageBox.No,
                                     QMessageBox.No)
        if reply == QMessageBox.Yes:
            self.close_signal.emit('EmbeddingVis')
            self.close()
        else:
            if event:
                event.ignore()

if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = MainWindow()
    app.setFont(QFont('Arial', 10))
    window.setStyleSheet(qdarkstyle.load_stylesheet_pyqt5())
    window.show()
    sys.exit(app.exec_())