from util.commonUtil import getTimeStr
from CommonClass import PageData, PanelValue
import sys
from util.pyqtUtil import getIntLineEdit
from CommonWidget import StateWidget,DownloadWidget,ResultTable
import csv
import os
import numpy as np
from PyQt5.QtGui import QIcon,QFont,QStandardItemModel,QStandardItem,QMovie 
from PyQt5.QtWidgets import (QGroupBox,QWidget,QTabWidget,QLabel,QTextEdit,QPushButton,QSplitter,QLineEdit,QTableWidgetItem,
                              QFormLayout,QMainWindow,QDesktopWidget,QApplication,QGridLayout,QTableWidget,QAbstractItemView,
                                QAction,QMessageBox,QMenu,qApp,QFileDialog,QRadioButton,QTableView,QHeaderView,QVBoxLayout)
from PyQt5.QtCore import QObject,Qt,pyqtSignal
import feature_selection.feature_selection
import PlotWidgets
import sip
    
global pageData
global panelValue


class ParamListWidget(QWidget):
    def __init__(self):
        super().__init__()
        self.initUI()
    def initUI(self):
        title = QLabel('Please select the feature selection method')
        title.setFont(QFont('Arial', 12))
        self.btnname='CHI2'

        m1Title = QLabel('CHI2')
        m1Title.setFont(QFont('Arial', 9))
        m1Btn=QRadioButton()
        m1Btn.setChecked(True)
        m1Btn.clicked.connect(lambda:self.setMethodClicked('CHI2'))

        m2Title = QLabel('IG')
        m2Title.setFont(QFont('Arial', 9))
        m2Btn=QRadioButton()
        m2Btn.clicked.connect(lambda:self.setMethodClicked('IG'))

        m3Title = QLabel('FScore')
        m3Title.setFont(QFont('Arial', 9))
        m3Btn=QRadioButton()
        m3Btn.clicked.connect(lambda:self.setMethodClicked('FScore'))

        m4Title = QLabel('MIC')
        m4Title.setFont(QFont('Arial', 9))
        m4Btn=QRadioButton()
        m4Btn.clicked.connect(lambda:self.setMethodClicked('MIC'))

        m5Title = QLabel('Pearsonr')
        m5Title.setFont(QFont('Arial', 9))
        m5Btn=QRadioButton()
        m5Btn.clicked.connect(lambda:self.setMethodClicked('Pearsonr'))

        m6Title = QLabel('T_test')
        m6Title.setFont(QFont('Arial', 9))
        m6Btn=QRadioButton()
        m6Btn.clicked.connect(lambda:self.setMethodClicked('T_test'))

        mdlGrid = QGridLayout()

        mdlGrid.addWidget(m1Title,0,1)
        mdlGrid.addWidget(m1Btn,0,0)
        mdlGrid.addWidget(m2Title,0,3)
        mdlGrid.addWidget(m2Btn,0,2)
        mdlGrid.addWidget(m3Title,0,5)
        mdlGrid.addWidget(m3Btn,0,4)
        mdlGrid.addWidget(m4Title,0,7)
        mdlGrid.addWidget(m4Btn,0,6)
        mdlGrid.addWidget(m5Title,0,9)
        mdlGrid.addWidget(m5Btn,0,8)
        # mdlGrid.addWidget(m6Title,0,11)
        # mdlGrid.addWidget(m6Btn,0,10)

        self.setLayout(mdlGrid)

    def setMethodClicked(self,btnname):
        self.btnname=btnname

class ParamValueWidget(QWidget):
    def __init__(self,parent=None):
        super(ParamValueWidget, self).__init__(parent)
        self.initUI()
    def initUI(self):
        self.all_para={}
        formLayout=QFormLayout()
        
        self.edit=getIntLineEdit(self)
        self.edit.setPlaceholderText("Please enter an integer")
        self.edit.setText('4')#有问题要改！！！

        formLayout.addRow('   [Selected feature number]:',self.edit)
        self.all_para['feature_number']=self.edit
        
        self.setLayout(formLayout)
    
class ParameterWidget(QWidget):
    feature_selection_signal=pyqtSignal()
    datatofile_signal = pyqtSignal(object,object,object)
    next_btn_signal=pyqtSignal(object)
    # outputData_signal = pyqtSignal(object,object)
    # setnewData_signal=pyqtSignal(object)
    
    def __init__(self):
        super().__init__()
        self.initUI()
    def initUI(self):
        title = QLabel('Please select the feature selection method')
        title.setFont(QFont('Arial', 9))
        self.gif = QMovie('images/progressgif_new.gif')
        self.progress_bar = QLabel()

        self.startBtn = QPushButton("Start feature selecting", self)
        self.startBtn.clicked.connect(self.startBtnClicked)
        self.paramListWidget=ParamListWidget()
        self.paramValWidget=ParamValueWidget()

        mdlGrid = QGridLayout()
        mdlGrid.addWidget(title,0,0,1,5)
        mdlGrid.addWidget(self.paramListWidget,1,0,1,1)
        mdlGrid.addWidget(self.paramValWidget,1,1,1,2)
        mdlGrid.addWidget(self.progress_bar,2,1,1,3)
        mdlGrid.addWidget(self.startBtn,3,0,1,5)

        self.setLayout(mdlGrid)
    def startBtnClicked(self):
        import numpy as np
        global pageData
        global panelValue
        param={}
        for key, value in self.paramValWidget.all_para.items():
            param[key]=value.text()
        panelValue.refreshData(self.paramListWidget.btnname,param)
        pageData.feature_selection_panel=panelValue
        
        if int(panelValue.param['feature_number'])>pageData.encoding_feature_num:
            QMessageBox.about(self, 'Warning', 'The current feature selection number is greater than the number of encoded features, so all features will be retained.')

        self.featureSlectionFunc = getattr(feature_selection.feature_selection, panelValue.method)

        # global bdata
        # self.encoding_array=encoding_array
        try:
            self.progress_bar.setMovie(self.gif)
            #only data +label
            
            pageData.feature_selection_data= self.featureSlectionFunc(pageData.sample_name,pageData.encoding_feature_name,pageData.encoding_array,panelValue.param['feature_number'])
            pageData.feature_selection_header=list(pageData.feature_selection_data.columns)
            pageData.feature_selection_table_value=np.array(pageData.feature_selection_data.values)
            pageData.feature_selection_data=pageData.feature_selection_data.iloc[:,1:]
            pageData.feature_num=min(int(panelValue.param['feature_number']),pageData.encoding_feature_num)

            self.feature_selection_signal.emit()

            pageData.feature_selection_output_filename=pageData.type+'_'+pageData.encoding_panel.method+'_'+panelValue.method+'_'+getTimeStr()
            
            #table value需要修改！！！
            self.datatofile_signal.emit(pageData.feature_selection_output_filename,pageData.feature_selection_header,pageData.feature_selection_table_value)
            self.next_btn_signal.emit(pageData)
            self.progress_bar.clear()
            # self.setnewData_signal.emit(table_value)
            # self.outputData_signal.emit(header,table_value)#待修改
            pageData.feature_selection_feature_num=int(panelValue.param['feature_number'])# update featrue number
            
        except Exception as e:
            QMessageBox.warning(self, 'Warning', 'Please check your input data and feature selection method!', QMessageBox.Ok | QMessageBox.No,
                                QMessageBox.Ok)
        

class StatTab(QGroupBox):
    def __init__(self):
        super().__init__()
        self.initUI()
    def initUI(self):
        self.setMaximumHeight(520)
        self.grid = QGridLayout(self)
        self.graph = PlotWidgets.MyFigure()

        self.grid.addWidget(self.graph,0,0,1,1)
    
    def clear(self):
        self.grid.removeWidget(self.graph)
        sip.delete(self.graph)
        self.graph = PlotWidgets.MyFigure()

    def update_stat_graph(self):
        self.grid.removeWidget(self.graph)
        sip.delete(self.graph)
        self.graph = PlotWidgets.MyFigure()


        self.graphLenDistribution = PlotWidgets.MyFigure()
        # self.graphLenDistribution.plotErrorBar(pageData.training_dataset,pageData.testing_dataset)
        self.grid.addWidget(self.grap,0,0,1,1)


class ResultWidget(QTabWidget):
    def __init__(self):
        super().__init__()
        self.initUI()
    def initUI(self):
        '''Set tab'''
        self.tab_result_table= QWidget()
        # self.tab_result_distribution = QWidget()
        # self.tab_result_statistical_info = StatTab()
        self.addTab(self.tab_result_table, " Feature Selection Result ")
        # self.addTab(self.tab_result_distribution, " Result Distribution ")
        # self.addTab(self.tab_result_statistical_info, ' Comparison of results after feature selection ')

        ''''Initialize tab'''
        self.set_tab_result_table()

    def set_tab_result_table(self):  
        self.reTable=ResultTable()
        self.downloadWidget=DownloadWidget()
        grid = QGridLayout()
        grid.addWidget(self.reTable,0,0)
        grid.addWidget(self.downloadWidget,1,0)
        self.tab_result_table.setLayout(grid)
    def refreshData(self):
        # global header
        # global table_value
        self.reTable.updateData(pageData.feature_selection_header,pageData.feature_selection_table_value)

    def clearData(self):
        # before data
        
        # self.set_tab_encoding_distribution()
        # self.tab_statistical_info.clear()
        self.reTable.updateData([],[],np.array([]))


class FeatureSelectionContentWidget(QWidget):
    # next_set_data_signal=pyqtSignal(object)
    def __init__(self,data=''):
        super().__init__()
        #init
        global pageData
        pageData=PageData()
        self.pageData=pageData
        
        global panelValue
        panelValue=PanelValue()
        self.panelValue=panelValue

        self.initUI()

    def initUI(self):
        self.parameterWidget=ParameterWidget()
        self.resultWidget=ResultWidget()
        # self.stateWidget=StateWidget()

        #set connect
        self.parameterWidget.feature_selection_signal.connect(self.resultWidget.refreshData)
        self.parameterWidget.datatofile_signal.connect(self.resultWidget.downloadWidget.setFile)
        # self.parameterWidget.setnewData_signal.connect(self.refresh_fdata)

        mainWidget=QWidget()
        grid0 = QGridLayout(mainWidget)
        grid0.addWidget(self.parameterWidget,0,0,1,1)
        grid0.addWidget(self.resultWidget,1,0,4,1)

        # splitter = QSplitter(Qt.Vertical)
        # splitter.addWidget(mainWidget)
        # splitter.addWidget(self.stateWidget)
        # splitter.setSizes([1000, 100])

        #Set grid
        # grid = QGridLayout()
        # grid.addWidget(splitter, 0, 0,1,2)
        self.setLayout(grid0)

    # def refresh_fdata(self,data):
    #     self.fdata=data

    #     global fdata
    #     fdata=self.fdata
    #     self.next_set_date_signal.emit(self.fdata,self.purpose)

    def setdata(self,data):
        global pageData
        self.pageData=data
        pageData=data

        if data==None:
            QMessageBox.about(self, 'Warning','Data is empty')
        # else:
        #     self.next_set_data_signal.emit(pageData)
    

    
