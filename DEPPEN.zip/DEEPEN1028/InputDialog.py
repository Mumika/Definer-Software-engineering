from Const import BATCH_SIZE, DILATION, EMBED_SIZE, EPOCHS, FILTER_NUM, FILTER_SIZE, HIDDEN_SIZE, LAYER_NUM, LEARNING_RATE, MAX_EPOCHS, N_HEADS, SEQ_MODEL, STRIDE, TOPK,HIDDEN_DIM
from Const import N_ESTIMATOR, N_JOBS
from Const import N_NEIGHBORS
from Const import NUM_LEAVES,MAX_DEPTH
from Const import N_TREES
from Const import PENALITY
from CommonClass import DLparam
from util.pyqtUtil import getLineEdit
from PyQt5.QtWidgets import (QDialog, QFormLayout, QRadioButton,QWidget,QLineEdit, QDialogButtonBox, QInputDialog, QMessageBox, QComboBox,
                             QVBoxLayout, QLabel, QTableWidget, QTableWidgetItem, QTableWidgetSelectionRange,
                             QAbstractItemView, QGridLayout, QTreeWidget, QTreeWidgetItem, QCheckBox, QApplication,
                             QFileDialog, QColorDialog, QPushButton)
from PyQt5.QtGui import QFont, QIcon
from PyQt5.QtCore import pyqtSignal, Qt
import numpy as np
import pandas as pd
import qdarkgraystyle

class DLInputDialog(QDialog):
    def __init__(self, model_name,dim):
        super(DLInputDialog, self).__init__()
        self.model_name=model_name
        self.dim=dim
        self.initUI()

    def initUI(self):
        self.setStyleSheet(qdarkgraystyle.load_stylesheet_pyqt5())
        self.setWindowFlags(Qt.WindowCloseButtonHint)
        self.setWindowIcon(QIcon('images/logo.ico'))
        self.setWindowTitle('DEEPEN '+self.model_name)
        self.setFont(QFont('Arial', 8))
        self.resize(600, 200)
        layout = QFormLayout(self)


        
        self.setLineParamNameList()
        self.setParamList()
        self.model_state_dict_path=''
        self.rowName={
            'epochs':'Epochs (integer):',
            'batch_size':'Batch size (integer):',
            'learning_rate':'Learning rate  (float):',
            'embed_size':'Embed size (integer):',
            'layer_num':'Layer number (integer):',
            'n_heads':'Heads number (integer):',
            'hidden_dim':'Hidden dim:',
            'hidden_size':'Hidden size (integer):',
            'filter_size':'Filter size:',# (Multiple convolution kernel sizes are used; segmentation)
            'filter_num':'Filter number (integer):',
            'stride':'Stride (integer):',
            'topk':'Topk (integer):',
            'dilation':'Dilation (integer):'
        }
        filter_size_label = QLabel('Note: Multiple convolution kernel sizes are used, segmentation')
        filter_size_label.setAlignment(Qt.AlignLeft)
        filter_size_label.setFont(QFont('Arial', 7))
        
        getLineEdit
        self.paramLineEditList=[]
        for name in self.lineParamNameList:
            exec('self.%s=getLineEdit(f\'{%s}\')'%(name,name.upper()))
            exec('self.%s.append(self.%s)'%('paramLineEditList',name))
            
            exec('layout.addRow(\'%s\', self.%s)'%(self.rowName[name],name))
            if name=='filter_size' and self.model_name=='CNN':
                layout.addWidget(filter_size_label)
            
            if name=='layer_num':
                self.model_shape_box = QComboBox()
                self.model_shape_box.addItems(["up","down","up2down"])
                layout.addRow('Model shape:',self.model_shape_box)
            if name=='hidden_dim':
                self.hidden_dim.clicked.connect(self.set_hidden_dim)

        if 'bidirectional' in self.paramList:
            w = QWidget()
            w.setWindowTitle("QCheckBox")
            w.resize(210,110)
            bidirCheckBox = QCheckBox("bidirectional", w)
            bidirCheckBox.setTristate(False)
            bidirCheckBox.stateChanged.connect(self.set_bidirectional)
            layout.addRow('bidirectional:',bidirCheckBox)


        self.buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel, Qt.Horizontal, self)
        self.buttons.accepted.connect(self.accept)
        self.buttons.rejected.connect(self.reject)

        self.loadBtn = QPushButton("Direct load model", self)
        self.loadBtn.clicked.connect(self.loadClicked)
        self.loadBtn.setStyleSheet(    "QPushButton{font-size:25px}"
                                  "QPushButton{color:black}"
                                  "QPushButton:hover{color:grey;background-color:rgb(209,219,203)}"
                                  "QPushButton{background-color:rgb(185,219,179)}"
                                  "QPushButton{border:2px}"
                                  "QPushButton{padding:2px 4px}")
        
        layout.addWidget(self.loadBtn)
        layout.addWidget(self.buttons)

    def loadClicked(self):
        fname = QFileDialog.getOpenFileName(self, 'Open file','','(*.pth)')
        if fname[0]:
            self.model_state_dict_path=fname[0]
    def get_model_state_dict_path(self):
        return self.model_state_dict_path
    def setLineParamNameList(self):
        if self.model_name=='CNN':
            self.lineParamNameList=['epochs','batch_size','learning_rate','embed_size','filter_size','filter_num','stride','topk','dilation']
        elif self.model_name=='MLP':
            self.lineParamNameList=['epochs','batch_size','learning_rate','embed_size','layer_num']
        elif self.model_name=='LSTM':
            self.lineParamNameList=['epochs','batch_size','learning_rate','embed_size','hidden_size']
        elif self.model_name=='RNN':
            self.lineParamNameList=['epochs','batch_size','learning_rate','embed_size','hidden_size']
        elif self.model_name=='GRU':
            self.lineParamNameList=['epochs','batch_size','learning_rate','embed_size','hidden_size']
        elif self.model_name=='Attention':
            self.lineParamNameList=['epochs','batch_size','learning_rate','n_heads','hidden_dim']
        elif self.model_name=='RNN_Multihead_Attention':
            self.lineParamNameList=['epochs','batch_size','learning_rate','embed_size','n_heads','hidden_dim']
        elif self.model_name=='CNN_Multihead_Attention':
            self.lineParamNameList=['epochs','batch_size','learning_rate','embed_size','n_heads','hidden_dim','filter_size','filter_num','stride','topk','dilation']
        elif self.model_name=='RNN_Simple_Attention':
            self.lineParamNameList=['epochs','batch_size','learning_rate','embed_size','n_heads','hidden_dim']
        elif self.model_name=='CNN_Simple_Attention':
            self.lineParamNameList=['epochs','batch_size','learning_rate','embed_size','n_heads','hidden_dim','filter_size','filter_num','stride','topk','dilation']

    def setParamList(self):
        self.paramList=['model_state_dict_path']
        self.paramList=self.paramList+self.lineParamNameList
        if 'layer_num' in self.lineParamNameList:
            self.paramList.append('model_shape')
        if self.model_name in SEQ_MODEL:
            self.bidirectional=False
            self.paramList.append('bidirectional')
        # if 'n_heads' in self.lineParamNameList:
        #     self.paramList.append('hidden_dim')
        
    

    def get_epochs(self):
        try:
            if self.epochs.text() != '':
                if int(self.epochs.text()) > 0 and int(self.epochs.text())< MAX_EPOCHS:
                    return int(self.epochs.text())
                else:
                    QMessageBox.about(self, 'Error', 'Epochs (integer)(1,%d):The value range is invalid'%MAX_EPOCHS)
                    return -1
            else:
                QMessageBox.about(self, 'Error', 'Epochs (integer)(1,%d):The value range is invalid'%MAX_EPOCHS)
                return -1
        except Exception as e:
            QMessageBox.about(self, 'Error', 'Epochs (integer)(1,%d):The value range is invalid'%MAX_EPOCHS)
            return -1


    def get_batch_size(self):
        try:
            if self.batch_size.text() != '':
                if int(self.batch_size.text()) > 0:
                    return int(self.batch_size.text())
                else:
                    QMessageBox.about(self, 'Error', 'Batch size (integer):The value range is invalid')
                    return -1
            else:
                QMessageBox.about(self, 'Error', 'Batch size (integer):The value range is invalid')
                return -1
        except Exception as e:
            QMessageBox.about(self, 'Error', 'Batch size (integer):The value range is invalid')
            return -1

    def get_learning_rate(self):
        try:
            if self.learning_rate.text() != '':
                lr = float(self.learning_rate.text())
                if 0 < lr < 1:
                    return lr
                else:
                    QMessageBox.about(self, 'Error', 'Learning rate  (float)(0,1):The value range is invalid')
                    return -1
            else:
                QMessageBox.about(self, 'Error', 'Learning rate  (float)The value range is invalid')
                return -1
        except Exception as e:
            QMessageBox.about(self, 'Error', 'Learning rate  (float)The value range is invalid')
            return -1
    
    def get_embed_size(self):
        try:
            if self.embed_size.text() != '':
                if int(self.embed_size.text()) > 0:
                    return int(self.embed_size.text())
                else:
                    QMessageBox.about(self, 'Error', 'Embed size (integer):The value range is invalid')
                    return -1
            else:
                QMessageBox.about(self, 'Error', 'Embed size (integer):The value range is invalid')
                return -1
        except Exception as e:
            QMessageBox.about(self, 'Error', 'Embed size (integer):The value range is invalid')
            return -1
    def set_hidden_dim(self):
        n_heads=self.get_n_heads()
        num,ok=QInputDialog.getInt(self,'%s hidden dim setting'%self.model_name,'Please enter a number',n_heads,n_heads,n_heads*128,n_heads)
        if ok:
            self.hidden_dim.setText(str(num))

    def get_hidden_dim(self):
        try:
            if self.hidden_dim is None:
                QMessageBox.about(self, 'Error', 'Please set the hidden dim')
                return -1
            else: 
                number = int(self.hidden_dim.text())
                return number
        except Exception as e:
            QMessageBox.about(self, 'Error', 'Hidden dim (integer)The value range is invalid')
            return -1

    def get_hidden_size(self):
        try:
            if self.hidden_size.text() != '':
                if int(self.hidden_size.text()) > 0:
                    return int(self.hidden_size.text())
                else:
                    QMessageBox.about(self, 'Error', 'Hidden size (integer):The value range is invalid')
                    return -1
            else:
                QMessageBox.about(self, 'Error', 'Hidden size (integer):The value range is invalid')
                return -1
        except Exception as e:
            QMessageBox.about(self, 'Error', 'Hidden size (integer):The value range is invalid')
            return -1

    def get_layer_num(self):
        try:
            if self.layer_num.text() != '':
                if int(self.layer_num.text()) > 0:
                    return int(self.layer_num.text())
                else:
                    QMessageBox.about(self, 'Error', 'Layer number (integer):The value range is invalid')
                    return -1
            else:
                QMessageBox.about(self, 'Error', 'Layer number (integer):The value range is invalid')
                return -1
        except Exception as e:
            QMessageBox.about(self, 'Error', 'Layer number (integer):The value range is invalid')
            return -1

    def get_n_heads(self):
        try:
            if self.n_heads.text() != '':
                if int(self.n_heads.text()) > 0:
                    return int(self.n_heads.text())
                else:
                    QMessageBox.about(self, 'Error', 'Heads number (integer):The value range is invalid')
                    return -1
            else:
                QMessageBox.about(self, 'Error', 'Heads number (integer):The value range is invalid')
                return -1
        except Exception as e:
            QMessageBox.about(self, 'Error', 'Heads number (integer):The value range is invalid')
            return -1

    # def get_hidden_size(self):
    #     try:
    #         if self.hidden_size.text() != '':
    #             if int(self.hidden_size.text()) > 0:
    #                 return int(self.hidden_size.text())
    #             else:
    #                 return HIDDEN_SIZE
    #         else:
    #             return HIDDEN_SIZE
    #     except Exception as e:
    #         return HIDDEN_SIZE

    def get_filter_size(self):
        try:
            if self.filter_size.text() != '':
                filter_size_list=self.filter_size.text().replace(" ","").replace("，",",").split(',')
                filter_size_list=[int(i) for i in filter_size_list]
                flag=True
                for filter_size in filter_size_list:
                    if filter_size<=0:
                       flag=False
                       break
                if flag:
                    return filter_size_list
                else:
                    QMessageBox.about(self, 'Error', 'Filter size:Please check the input format')
                    return -1
            else:
                QMessageBox.about(self, 'Error', 'Filter size:Please check the input format')
                return -1
        except Exception as e:
            QMessageBox.about(self, 'Error', 'Filter size:Please check the input format')
            return -1

    def get_filter_num(self):
        try:
            if self.filter_num.text() != '':
                if int(self.filter_num.text()) > 0:
                    return int(self.filter_num.text())
                else:
                    QMessageBox.about(self, 'Error', 'Filter number (integer):The value range is invalid')
                    return -1
            else:
                QMessageBox.about(self, 'Error', 'Filter number (integer):The value range is invalid')
                return -1
        except Exception as e:
            QMessageBox.about(self, 'Error', 'Filter number (integer):The value range is invalid')
            return -1

    def get_stride(self):
        try:
            if self.stride.text() != '':
                if int(self.stride.text()) > 0:
                    return int(self.stride.text())
                else:
                    QMessageBox.about(self, 'Error', 'Stride (integer):The value range is invalid')
                    return -1
            else:
                QMessageBox.about(self, 'Error', 'Stride (integer):The value range is invalid')
                return -1
        except Exception as e:
            QMessageBox.about(self, 'Error', 'Stride (integer):The value range is invalid')
            return -1
    
    def get_topk(self):
        try:
            if self.topk.text() != '':
                if int(self.topk.text()) > 0:
                    return int(self.topk.text())
                else:
                    QMessageBox.about(self, 'Error', 'Topk (integer):The value range is invalid')
                    return -1
            else:
                QMessageBox.about(self, 'Error', 'Topk (integer):The value range is invalid')
                return -1
        except Exception as e:
            QMessageBox.about(self, 'Error', 'Topk (integer):The value range is invalid')
            return -1

    def get_dilation(self):
        try:
            if self.dilation.text() != '':
                if int(self.dilation.text()) > 0:
                    return int(self.dilation.text())
                else:
                    QMessageBox.about(self, 'Error', 'Topk (integer):The value range is invalid')
                    return -1
            else:
                QMessageBox.about(self, 'Error', 'Dilation:The value range is invalid')
                return -1
        except Exception as e:
            QMessageBox.about(self, 'Error', 'Dilation:The value range is invalid')
            return -1
    
    # def set_model_shape(self,model_shape):
    #     self.model_shape_value=model_shape
    
    def get_model_shape(self):
        return self.model_shape_box.currentText()
        # return self.model_shape_value
    
    def set_bidirectional(self,state):
        if state==0:
            self.bidirectional=False
        else:
            self.bidirectional=True

    def get_bidirectional(self):
        return self.bidirectional
    def getRadioGroup(self,main_title,btnnameList,btnnameDictList,func,width=500,has_main_title=False):
        btnWidget=QWidget()
        grid=QGridLayout(btnWidget)
        btnWidget.setMaximumWidth(width)
        if has_main_title:
            mainTitle = QLabel(main_title)
            grid.addWidget(mainTitle,0,0)
        for i in range(len(btnnameList)):
            title,btn = self.getRadioBtn(btnnameList[i],btnnameDictList[btnnameList[i]],i==0,func)
            grid.addWidget(title,0,2*i+1)
            grid.addWidget(btn,0,2*i+2)
        return btnWidget
    
    def getRadioBtn(self,name,name_value,flag,func):
        title = QLabel(name)
        title.setFont(QFont('Arial', 9))
        
        btn=QRadioButton()
        btn.setChecked(flag)
        btn.clicked.connect(lambda:func(name_value))

        return title,btn
    
    

    @staticmethod
    def getValues(method,dim):
        dialog = DLInputDialog(method,dim)
        result = dialog.exec_()

        all_param={}
        if result == QDialog.Accepted:
            for name in dialog.paramList:
                exec('all_param[\'%s\']=dialog.get_%s()'%(name,name))
                # if len(all_param['model_state_dict_path'])>0:
                #     return all_param, result == QDialog.Accepted
                if -1 in all_param.values():
                    return None,False
            return all_param, result == QDialog.Accepted
        else:  
            return None,False


class BaggingInputDialog(QDialog):
    def __init__(self, model_name,dim):
        super(BaggingInputDialog, self).__init__()
        self.model_name=model_name
        self.dim=dim
        self.initUI()

    def initUI(self):
        self.setStyleSheet(qdarkgraystyle.load_stylesheet_pyqt5())
        self.setWindowFlags(Qt.WindowCloseButtonHint)
        self.setWindowIcon(QIcon('images/logo.ico'))
        self.setWindowTitle('DEEPEN '+self.model_name)
        self.setFont(QFont('Arial', 8))
        self.resize(600, 200)
        layout = QFormLayout(self)

        self.setLineParamNameList()
        self.setParamList()
        self.rowName={
            'n_jobs':'CPU number (integer):',
            'n_estimator':'Estimator number (integer):',
            
        }


        self.paramLineEditList=[]
        for name in self.lineParamNameList:
            exec('self.%s=getLineEdit(f\'{%s}\')'%(name,name.upper()))
            exec('self.%s.append(self.%s)'%('paramLineEditList',name))            
            exec('layout.addRow(\'%s\', self.%s)'%(self.rowName[name],name))


        self.buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel, Qt.Horizontal, self)
        self.buttons.accepted.connect(self.accept)
        self.buttons.rejected.connect(self.reject)
        
        
        layout.addWidget(self.buttons)

    def setLineParamNameList(self):
        self.lineParamNameList=['n_estimator','n_jobs']
       
    def setParamList(self):
        self.paramList=[]
        self.paramList=self.paramList+self.lineParamNameList

    def get_n_jobs(self):
        try:
            if self.n_jobs.text() != '':
                if int(self.n_jobs.text()) > 0:
                    return int(self.n_jobs.text())
                else:
                    QMessageBox.about(self, 'Error', 'CPU number (integer):The value range is invalid')
                    return -1
            else:
                QMessageBox.about(self, 'Error', 'CPU number (integer):The value range is invalid')
                return -1
        except Exception as e:
            QMessageBox.about(self, 'Error', 'CPU number (integer):The value range is invalid')
            return -1
    
    def get_n_estimator(self):
        try:
            if self.n_estimator.text() != '':
                if int(self.n_estimator.text()) > 0:
                    return int(self.n_estimator.text())
                else:
                    QMessageBox.about(self, 'Error', 'Estimator number (integer):The value range is invalid')
                    return -1
            else:
                QMessageBox.about(self, 'Error', 'Estimator number (integer):The value range is invalid')
                return -1
        except Exception as e:
            QMessageBox.about(self, 'Error', 'Estimator number (integer):The value range is invalid')
            return -1

    


    @staticmethod
    def getValues(method,dim):
        dialog = BaggingInputDialog(method,dim)
        result = dialog.exec_()

        all_param={}
        if result == QDialog.Accepted:
            for name in dialog.paramList:
                exec('all_param[\'%s\']=dialog.get_%s()'%(name,name))
                if -1 in all_param.values():
                    return None,False
            return all_param, result == QDialog.Accepted
        else:  
            return None,False


class KNeighborsInputDialog(QDialog):
    def __init__(self, model_name,dim):
        super(KNeighborsInputDialog, self).__init__()
        self.model_name=model_name
        self.dim=dim
        self.initUI()

    def initUI(self):
        self.setStyleSheet(qdarkgraystyle.load_stylesheet_pyqt5())
        self.setWindowFlags(Qt.WindowCloseButtonHint)
        self.setWindowIcon(QIcon('images/logo.ico'))
        self.setWindowTitle('DEEPEN '+self.model_name)
        self.setFont(QFont('Arial', 8))
        self.resize(600, 200)
        layout = QFormLayout(self)

        self.setLineParamNameList()
        self.setParamList()
        self.rowName={
            'n_neighbors':'Top k neighbors number (integer):',            
        }


        self.paramLineEditList=[]
        for name in self.lineParamNameList:
            exec('self.%s=getLineEdit(f\'{%s}\')'%(name,name.upper()))
            exec('self.%s.append(self.%s)'%('paramLineEditList',name))            
            exec('layout.addRow(\'%s\', self.%s)'%(self.rowName[name],name))


        self.buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel, Qt.Horizontal, self)
        self.buttons.accepted.connect(self.accept)
        self.buttons.rejected.connect(self.reject)
        
        
        layout.addWidget(self.buttons)

    def setLineParamNameList(self):
        self.lineParamNameList=['n_neighbors']
       
    def setParamList(self):
        self.paramList=[]
        self.paramList=self.paramList+self.lineParamNameList

    def get_n_neighbors(self):
        try:
            if self.n_neighbors.text() != '':
                if int(self.n_neighbors.text()) > 0:
                    return int(self.n_neighbors.text())
                else:
                    QMessageBox.about(self, 'Error', 'Top k neighbors number (integer):The value range is invalid')
                    return -1
            else:
                QMessageBox.about(self, 'Error', 'Top k neighbors number (integer):The value range is invalid')
                return -1
        except Exception as e:
            QMessageBox.about(self, 'Error', 'Top k neighbors number (integer):The value range is invalid')
            return -1
    
    

    @staticmethod
    def getValues(method,dim):
        dialog = KNeighborsInputDialog(method,dim)
        result = dialog.exec_()

        all_param={}
        if result == QDialog.Accepted:
            for name in dialog.paramList:
                exec('all_param[\'%s\']=dialog.get_%s()'%(name,name))
                if -1 in all_param.values():
                    return None,False
            return all_param, result == QDialog.Accepted
        else:  
            return None,False


class LGBMInputDialog(QDialog):
    def __init__(self, model_name,dim):
        super(LGBMInputDialog, self).__init__()
        self.model_name=model_name
        self.dim=dim
        self.initUI()

    def initUI(self):
        self.setStyleSheet(qdarkgraystyle.load_stylesheet_pyqt5())
        self.setWindowFlags(Qt.WindowCloseButtonHint)
        self.setWindowIcon(QIcon('images/logo.ico'))
        self.setWindowTitle('DEEPEN '+self.model_name)
        self.setFont(QFont('Arial', 8))
        self.resize(600, 200)
        layout = QFormLayout(self)



        self.setLineParamNameList()
        self.setParamList()
        self.rowName={
            'num_leaves':'Leaves number (integer):',
            'max_depth':'Max depth (integer):',
            'learning_rate':'Learning rate (float):',
            'leaves_range':'Embed size (integer):',
            'depth_range':'Layer number (integer):',
            'rate_range':'Heads number (integer):',
            'n_jobs':'Hidden size (integer):',
        }

        self.boosting_type_box = QComboBox()
        self.boosting_type_box.addItems(['gbdt','dart','goss','rf'])
        layout.addRow('Boosting type:',self.boosting_type_box)

        self.paramLineEditList=[]
        for name in self.lineParamNameList:
            exec('self.%s=getLineEdit(f\'{%s}\')'%(name,name.upper()))
            exec('self.%s.append(self.%s)'%('paramLineEditList',name))
            
            exec('layout.addRow(\'%s\', self.%s)'%(self.rowName[name],name))

        self.buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel, Qt.Horizontal, self)
        self.buttons.accepted.connect(self.accept)
        self.buttons.rejected.connect(self.reject)
        
        
        layout.addWidget(self.buttons)

    def setLineParamNameList(self):
        self.lineParamNameList=['num_leaves','max_depth','learning_rate','n_jobs']#,'leaves_range','depth_range','rate_range','n_jobs']
       

    def setParamList(self):
        self.paramList=[]
        self.paramList=self.paramList+self.lineParamNameList
        self.paramList.append('boosting_type')
        

    def get_num_leaves(self):
        try:
            if self.num_leaves.text() != '':
                if int(self.num_leaves.text()) > 0:
                    return int(self.num_leaves.text())
                else:
                    QMessageBox.about(self, 'Error', 'Leaves number (integer):The value range is invalid')
                    return -1
            else:
                QMessageBox.about(self, 'Error', 'Leaves number (integer):The value range is invalid')
                return -1
        except Exception as e:
            QMessageBox.about(self, 'Error', 'Leaves number (integer):The value range is invalid')
            return -1


    def get_max_depth(self):
        try:
            if self.max_depth.text() != '':
                if int(self.max_depth.text()) > 0:
                    return int(self.max_depth.text())
                else:
                    QMessageBox.about(self, 'Error', 'Max depth (integer):The value range is invalid')
                    return -1
            else:
                QMessageBox.about(self, 'Error', 'Max depth (integer):The value range is invalid')
                return -1
        except Exception as e:
            QMessageBox.about(self, 'Error', 'Max depth (integer):The value range is invalid')
            return -1

    def get_learning_rate(self):
        try:
            if self.learning_rate.text() != '':
                lr = float(self.learning_rate.text())
                if 0 < lr < 1:
                    return lr
                else:
                    QMessageBox.about(self, 'Error', 'Learning rate  (float)(0,1):The value range is invalid')
                    return -1
            else:
                QMessageBox.about(self, 'Error', 'Learning rate  (float)The value range is invalid')
                return -1
        except Exception as e:
            QMessageBox.about(self, 'Error', 'Learning rate  (float)The value range is invalid')
            return -1
    
    def get_n_jobs(self):
        try:
            if self.n_jobs.text() != '':
                if int(self.n_jobs.text()) > 0:
                    return int(self.n_jobs.text())
                else:
                    QMessageBox.about(self, 'Error', 'CPU number (integer):The value range is invalid')
                    return -1
            else:
                QMessageBox.about(self, 'Error', 'CPU number (integer):The value range is invalid')
                return -1
        except Exception as e:
            QMessageBox.about(self, 'Error', 'CPU number (integer):The value range is invalid')
            return -1
    
    def get_boosting_type(self):
        return self.boosting_type_box.currentText()
   

    @staticmethod
    def getValues(method,dim):
        dialog = LGBMInputDialog(method,dim)
        result = dialog.exec_()

        all_param={}
        if result == QDialog.Accepted:
            for name in dialog.paramList:
                exec('all_param[\'%s\']=dialog.get_%s()'%(name,name))
                if -1 in all_param.values():
                    return None,False
            return all_param, result == QDialog.Accepted
        else:  
            return None,False


class RandomForestInputDialog(QDialog):
    def __init__(self, model_name,dim):
        super(RandomForestInputDialog, self).__init__()
        self.model_name=model_name
        self.dim=dim
        self.initUI()

    def initUI(self):
        self.setStyleSheet(qdarkgraystyle.load_stylesheet_pyqt5())
        self.setWindowFlags(Qt.WindowCloseButtonHint)
        self.setWindowIcon(QIcon('images/logo.ico'))
        self.setWindowTitle('DEEPEN '+self.model_name)
        self.setFont(QFont('Arial', 8))
        self.resize(600, 200)
        layout = QFormLayout(self)

        self.setLineParamNameList()
        self.setParamList()
        self.rowName={
            'n_jobs':'CPU number (integer):',
            'n_trees':'Trees number (integer):',
            
        }


        self.paramLineEditList=[]
        for name in self.lineParamNameList:
            exec('self.%s=getLineEdit(f\'{%s}\')'%(name,name.upper()))
            exec('self.%s.append(self.%s)'%('paramLineEditList',name))            
            exec('layout.addRow(\'%s\', self.%s)'%(self.rowName[name],name))


        self.buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel, Qt.Horizontal, self)
        self.buttons.accepted.connect(self.accept)
        self.buttons.rejected.connect(self.reject)
        
        
        layout.addWidget(self.buttons)

    def setLineParamNameList(self):
        self.lineParamNameList=['n_trees','n_jobs']
       
    def setParamList(self):
        self.paramList=[]
        self.paramList=self.paramList+self.lineParamNameList

    def get_n_jobs(self):
        try:
            if self.n_jobs.text() != '':
                if int(self.n_jobs.text()) > 0:
                    return int(self.n_jobs.text())
                else:
                    QMessageBox.about(self, 'Error', 'CPU number (integer):The value range is invalid')
                    return -1
            else:
                QMessageBox.about(self, 'Error', 'CPU number (integer):The value range is invalid')
                return -1
        except Exception as e:
            QMessageBox.about(self, 'Error', 'CPU number (integer):The value range is invalid')
            return -1
    
    def get_n_trees(self):
        try:
            if self.n_trees.text() != '':
                if int(self.n_trees.text()) > 0:
                    return int(self.n_trees.text())
                else:
                    QMessageBox.about(self, 'Error', 'Trees number (integer):The value range is invalid')
                    return -1
            else:
                QMessageBox.about(self, 'Error', 'Trees number (integer):The value range is invalid')
                return -1
        except Exception as e:
            QMessageBox.about(self, 'Error', 'Trees number (integer):The value range is invalid')
            return -1

    


    @staticmethod
    def getValues(method,dim):
        dialog = RandomForestInputDialog(method,dim)
        result = dialog.exec_()

        all_param={}
        if result == QDialog.Accepted:
            for name in dialog.paramList:
                exec('all_param[\'%s\']=dialog.get_%s()'%(name,name))
                if -1 in all_param.values():
                    return None,False
            return all_param, result == QDialog.Accepted
        else:  
            return None,False


class SVMInputDialog(QDialog):
    def __init__(self, model_name,dim):
        super(SVMInputDialog, self).__init__()
        self.model_name=model_name
        self.dim=dim
        self.initUI()

    def initUI(self):
        self.setStyleSheet(qdarkgraystyle.load_stylesheet_pyqt5())
        self.setWindowFlags(Qt.WindowCloseButtonHint)
        self.setWindowIcon(QIcon('images/logo.ico'))
        self.setWindowTitle('DEEPEN '+self.model_name)
        self.setFont(QFont('Arial', 8))
        self.resize(600, 200)
        layout = QFormLayout(self)

        self.setLineParamNameList()
        self.setParamList()
        self.rowName={
            'penality':'Penality (float):',            
        }

        self.kernel_box = QComboBox()
        self.kernel_box.addItems(['linear', 'rbf', 'poly', 'sigmoid'])
        layout.addRow('Kernel:',self.kernel_box)

        self.paramLineEditList=[]
        for name in self.lineParamNameList:
            exec('self.%s=getLineEdit(f\'{%s}\')'%(name,name.upper()))
            exec('self.%s.append(self.%s)'%('paramLineEditList',name))            
            exec('layout.addRow(\'%s\', self.%s)'%(self.rowName[name],name))


        self.buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel, Qt.Horizontal, self)
        self.buttons.accepted.connect(self.accept)
        self.buttons.rejected.connect(self.reject)
        
        
        layout.addWidget(self.buttons)

    def setLineParamNameList(self):
        self.lineParamNameList=['penality']
       
    def setParamList(self):
        self.paramList=[]
        self.paramList=self.paramList+self.lineParamNameList
        self.paramList.append('kernel')

    def get_kernel(self):
        return self.kernel_box.currentText()
    
    def get_penality(self):
        try:
            if self.penality.text() != '':
                # if float(self.n_trees.text()) > 0:
                    return float(self.penality.text())
                # else:
                #     QMessageBox.about(self, 'Error', 'Trees number (integer):The value range is invalid')
                #     return -1
            else:
                QMessageBox.about(self, 'Error', 'Penality (float):The value range is invalid')
                return -1
        except Exception as e:
            QMessageBox.about(self, 'Error', 'Penality (float):The value range is invalid')
            return -1

    


    @staticmethod
    def getValues(method,dim):
        dialog = SVMInputDialog(method,dim)
        result = dialog.exec_()

        all_param={}
        if result == QDialog.Accepted:
            for name in dialog.paramList:
                exec('all_param[\'%s\']=dialog.get_%s()'%(name,name))
                if -1 in all_param.values():
                    return None,False
            return all_param, result == QDialog.Accepted
        else:  
            return None,False