import sys
import qdarkgraystyle
from PyQt5.QtGui import QIcon,QFont,QStandardItemModel,QStandardItem 
from PyQt5.QtWidgets import (QFrame,QSizePolicy,QToolButton,QScrollArea,QWidget,QSplitter,QTabWidget,QLabel,QTextEdit,QPushButton,QLineEdit,QTableWidgetItem,
                              QMainWindow,QDesktopWidget,QApplication,QGridLayout,QVBoxLayout,QTableWidget,QAbstractItemView,
                                QAction,QMessageBox,QMenu,qApp,QFileDialog,QRadioButton,QTableView,QHeaderView)
from PyQt5.QtCore import QObject,Qt,pyqtSignal

from PyQt5.QtWidgets import QDialog, QVBoxLayout, QWidget,\
    QGraphicsDropShadowEffect, QPushButton, QGridLayout, QSpacerItem,\
    QSizePolicy
from PyQt5.QtCore import QTimer
from PyQt5.QtWidgets import QWidget, QApplication, QVBoxLayout, QProgressBar

from PyQt5.QtCore import QSize,QBasicTimer
from PyQt5.QtWidgets import QWidget, QPushButton, QFormLayout,\
    QLineEdit, QListWidget, QListWidgetItem, QCheckBox
from PyQt5.QtCore import Qt,QSize,QParallelAnimationGroup,QPropertyAnimation,pyqtSlot,QAbstractAnimation
import csv
from random import randint
import numpy as np

Stylesheet = """
#RedProgressBar {
    text-align: center; /*进度值居中*/
}

#Custom_Widget {
    background: white;
    border-radius: 10px;
}

#closeButton {
    min-width: 36px;
    min-height: 36px;
    font-family: "Webdings";
    qproperty-text: "r";
    border-radius: 10px;
}
#closeButton:hover {
    color: white;
    background: red;
}
"""
global encoding_array
class CollapsibleBox(QWidget):
    def __init__(self, title="", parent=None):
        super(CollapsibleBox, self).__init__(parent)

        self.toggle_button = QToolButton(
            text=title, checkable=True, checked=False
        )
        self.toggle_button.setStyleSheet("QToolButton { border: none; }")
        self.toggle_button.setToolButtonStyle(
            Qt.ToolButtonTextBesideIcon
        )
        self.toggle_button.setArrowType(Qt.RightArrow)
        self.toggle_button.pressed.connect(self.on_pressed)

        self.toggle_animation = QParallelAnimationGroup(self)

        self.content_area = QScrollArea(
            maximumHeight=0, minimumHeight=0
        )
        self.content_area.setSizePolicy(
            QSizePolicy.Expanding, QSizePolicy.Fixed
        )
        self.content_area.setFrameShape(QFrame.NoFrame)

        lay = QVBoxLayout(self)
        lay.setSpacing(0)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.addWidget(self.toggle_button)
        lay.addWidget(self.content_area)

        self.toggle_animation.addAnimation(
            QPropertyAnimation(self, b"minimumHeight")
        )
        self.toggle_animation.addAnimation(
            QPropertyAnimation(self, b"maximumHeight")
        )
        self.toggle_animation.addAnimation(
            QPropertyAnimation(self.content_area, b"maximumHeight")
        )

    @pyqtSlot()
    def on_pressed(self):
        checked = self.toggle_button.isChecked()
        self.toggle_button.setArrowType(
            Qt.DownArrow if not checked else Qt.RightArrow
        )
        self.toggle_animation.setDirection(
            QAbstractAnimation.Forward
            if not checked
            else QAbstractAnimation.Backward
        )
        self.toggle_animation.start()

    def setContentLayout(self, layout):
        lay = self.content_area.layout()
        del lay
        self.content_area.setLayout(layout)
        collapsed_height = (
            self.sizeHint().height() - self.content_area.maximumHeight()
        )
        content_height = layout.sizeHint().height()
        for i in range(self.toggle_animation.animationCount()):
            animation = self.toggle_animation.animationAt(i)
            animation.setDuration(500)
            animation.setStartValue(collapsed_height)
            animation.setEndValue(collapsed_height + content_height)

        content_animation = self.toggle_animation.animationAt(
            self.toggle_animation.animationCount() - 1
        )
        content_animation.setDuration(500)
        content_animation.setStartValue(0)
        content_animation.setEndValue(content_height)
class ProgressBar(QProgressBar):
    
    def __init__(self, *args, **kwargs):
        super(ProgressBar, self).__init__(*args, **kwargs)
        self.setValue(0)
        if self.minimum() != self.maximum():
            self.timer = QTimer(self, timeout=self.onTimeout)
            self.timer.start(randint(1, 3) * 1000)

    def onTimeout(self):
        if self.value() >= 100:
            self.timer.stop()
            self.timer.deleteLater()
            del self.timer
            return
        self.setValue(self.value() + 1)

class Dialog(QDialog):

    def __init__(self, *args, **kwargs):
        super(Dialog, self).__init__(*args, **kwargs)
        self.setObjectName('Custom_Dialog')
        self.setWindowFlags(self.windowFlags() | Qt.FramelessWindowHint)
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.setStyleSheet(Stylesheet)
        self.initUi()

        effect = QGraphicsDropShadowEffect(self)
        effect.setBlurRadius(12)
        effect.setOffset(0, 0)
        effect.setColor(Qt.gray)
        self.setGraphicsEffect(effect)

    def initUi(self):
        layout = QVBoxLayout(self)

        self.widget = QWidget(self)
        self.widget.setObjectName('Custom_Widget')
        layout.addWidget(self.widget)

        layout = QGridLayout(self.widget)
        layout.addItem(QSpacerItem(
            40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum), 0, 0)
        layout.addWidget(QPushButton(
            'r', self, clicked=self.accept, objectName='closeButton'), 0, 1)
        layout.addItem(QSpacerItem(20, 40, QSizePolicy.Minimum,
                                   QSizePolicy.Expanding), 1, 0)

    def sizeHint(self):
        return QSize(600, 400)

class DownloadWidget(QWidget):
    def __init__(self):
        super().__init__()
        self.table_value=''
        self.initUI()
    def initUI(self):
        downloadBtn = QPushButton("Export file", self)
        downloadBtn.setStyleSheet(
                            "QPushButton{color:black}"
                            "QPushButton:hover{color:grey;background-color:rgb(209,219,203)}"
                            "QPushButton{background-color:rgb(118,121,124)}"
                            "QPushButton{border:2px}"
                            "QPushButton{border-radius:10px}"
                            "QPushButton{padding:2px 4px}")
        downloadBtn.clicked.connect(self.downloadBtnClicked)
        
        grid = QGridLayout()
        grid.addWidget(downloadBtn, 0, 0,1,1)
        self.setLayout(grid)

    def setFile(self,filename,header,table_value):
        self.output_filename=filename
        self.header=header
        self.table_value=table_value

    def downloadBtnClicked(self):
        if len(self.table_value):
            fname,ok= QFileDialog.getSaveFileName(self, 'Save file',"./"+self.output_filename+".csv",'csv(*.csv)')
            if fname:
                index=fname.rfind('.')+1

                with open(file=fname, mode='a+',newline='',encoding='utf-8-sig') as file:
                    if fname[index:]=='csv':
                        csv_writer=csv.writer(file)
                        csv_writer.writerow((tuple(self.header)))
                        for item in self.table_value:
                            csv_writer.writerow((tuple(item)))
                file.close()
                    
                QMessageBox.about(self,'Success',"File saved successfully.")
        else:
            QMessageBox.about(self,'Error',"The result is empty.")

class StateWidget(QWidget):
    def __init__(self):
        super().__init__()
        self.initUI()
    def initUI(self):
        title = QLabel('System Message')
        title.setFont(QFont('Arial', 9))
        self.startButton = QPushButton("Load example FASTA", self)
        self.startButton.setText("开始")
        #为按钮绑定事件（点击按钮时就触发）
        self.startButton.clicked.connect(self.onStart)
        self.progressBar = QProgressBar()
        self.progressBar.setRange(0, 100)
        self.progressBar.setValue(0)

        self.timer = QBasicTimer()
        self.step = 0

        #Set grid
        grid = QGridLayout()
        grid.addWidget(title, 0, 0,1,1)
        grid.addWidget(self.progressBar, 1, 0,1,1)
        grid.addWidget(self.startButton, 2, 0,1,1)
        self.setLayout(grid)
    def onStart(self):

        # 修改文本标签显示内容
        # self.statusLabel.setText("     请稍后     ")
        #禁用按钮
        self.startButton.setEnabled(False)
        #修改按钮显示内容
        self.startButton.setText("预测中...")
        #使用定时器的start()方法启动定时器，激活进度条。其中：
        # 参数1：超时时间；参数2：到了超时时间后，接收定时器触发超时事件的对象。
        self.timer.start(100, self)

    def timerEvent(self, event):
        if self.step >= 100:
            self.timer.stop()
            # self.statusLabel.setText("     预测完成    ")
            
            # 启用按钮
            # self.startButton.setEnabled(True)
            # 修改按钮显示内容
            # self.startButton.setText("开始")
            return
        self.step = self.step + 1
        self.progressBar.setValue(self.step)


class NextWidget(QWidget):
    next_signal=pyqtSignal(object,object)
    def __init__(self,name):
        super().__init__()
        self.module_name=name
        self.data=None
        self.initUI()
    def initUI(self):
        nextBtn = QPushButton("You can click into next state", self,maximumHeight=30)
        nextBtn.clicked.connect(self.nextBtnClicked)
        nextBtn.setStyleSheet(    "QPushButton{font-size:25px}"
                                  "QPushButton{color:black}"
                                  "QPushButton:hover{color:grey;background-color:rgb(209,219,203)}"
                                  "QPushButton{background-color:rgb(185,219,179)}"
                                  "QPushButton{border:2px}"
                                  "QPushButton{border-radius:10px}"
                                  "QPushButton{padding:2px 4px}")

        grid = QGridLayout()
        grid.addWidget(nextBtn, 0, 1,1,1)
        self.setLayout(grid)
    def setData(self,data):
        self.data=data
        # self.setDisabled(False)

    def nextBtnClicked(self):
        # if self.data is None:
            # self.setDisabled(True)
        # else:
            self.next_signal.emit(self.module_name,self.data)

class PreviousWidget(QWidget):
    previous_signal=pyqtSignal(object,object)
    def __init__(self,name):
        super().__init__()
        self.module_name=name
        self.data=''
        self.initUI()
    def initUI(self):
        previousBtn = QPushButton("Previous", self,maximumHeight=30)
        previousBtn.clicked.connect(self.previousBtnClicked)
        previousBtn.setStyleSheet(    "QPushButton{font-size:25px}"
                                  "QPushButton{color:black}"
                                  "QPushButton:hover{color:grey;background-color:rgb(209,219,203)}"
                                  "QPushButton{background-color:rgb(185,219,179)}"
                                  "QPushButton{border:2px}"
                                  "QPushButton{border-radius:10px}"
                                  "QPushButton{padding:2px 4px}")

        grid = QGridLayout()
        grid.addWidget(previousBtn, 0, 0)
        self.setLayout(grid)
    def setData(self,data):
        self.data=data
    def previousBtnClicked(self):
        self.previous_signal.emit(self.module_name,self.data)

class ExitWidget(QWidget):
    close_signal=pyqtSignal()
    def __init__(self,name):
        super().__init__()
        self.module_name=name
        self.data=''
        self.initUI()
    def initUI(self):
        previousBtn = QPushButton("Exit", self,maximumHeight=20)
        previousBtn.clicked.connect(self.exitBtnClicked)
        previousBtn.setStyleSheet(    "QPushButton{font-size:25px}"
                                  "QPushButton{color:black}"
                                  "QPushButton:hover{color:grey;background-color:rgb(209,219,203)}"
                                  "QPushButton{background-color:rgb(185,219,179)}"
                                  "QPushButton{border:2px}"
                                  "QPushButton{border-radius:10px}"
                                  "QPushButton{padding:2px 4px}")

        grid = QGridLayout()
        grid.addWidget(previousBtn, 0, 0)
        self.setLayout(grid)
    def exitBtnClicked(self):
        self.close_signal.emit()

class ChangeStateWidget(QWidget):
    def __init__(self,name,loc):
        super().__init__()
        self.loc=loc
        self.name=name
        self.initUI()
    def initUI(self):
        grid = QGridLayout(self)
        if self.loc!='First':
            self.previousWidget=PreviousWidget(self.name)
            grid.addWidget(self.previousWidget, 0, 0)
        if self.loc!='Last':
            self.nextWidget=NextWidget(self.name)
            # self.nextWidget.setDisabled(True)
            grid.addWidget(self.nextWidget, 0, 1,1,3)
        # self.exitWidget=ExitWidget(self.name)
        # grid.addWidget(self.exitWidget, 1, 1,1,2)
        self.setLayout(grid)
def is_number(s):
    try:
        float(s)
        return True
    except ValueError:
        pass
 
    try:
        import unicodedata
        unicodedata.numeric(s)
        return True
    except (TypeError, ValueError):
        pass
 
    return False

class ResultTable(QTableWidget):
    def __init__(self,parent=None):
        super(ResultTable,self).__init__(parent)
        #set data readOnly
        self.setEditTriggers(QAbstractItemView.NoEditTriggers)
        
        #update data
        self.updateData([],[],np.array([]))
    
    #set header
    def setTableHeader(self,header):
        if header is not None:
            self.setHorizontalHeaderLabels(list(header))

    def setTableRowName(self,row_name=None):
        if row_name is not None:
            row_name=[str(i) for i in row_name]
            self.setVerticalHeaderLabels(row_name)
    def removeBefore(self):
        #initialize header
        self.setColumnCount(0)
        #set header
        self.setTableHeader('')
        rowcount = self.rowCount()
        while rowcount>0:
            rowcount = self.rowCount()
            self.removeRow(rowcount-1)

    def updateData(self,header,array,row_name=None):
        self.removeBefore()
        if array is not None and len(array)>0:
            max_columns_len=np.max([len(i) for i in array])
            max_header_len=0
            if header is not None:
                max_header_len=len(header)
            self.setColumnCount(max(max_header_len,max_columns_len))
            self.setTableHeader(header)
            for i in range(len(array)):
                rowcount = self.rowCount()
                self.insertRow(rowcount)
                self.cur_line=array[i]
                for j in range(len(self.cur_line)):
                    if is_number(self.cur_line[j]) and type(self.cur_line[j])=='str' and self.cur_line[j].isdigit() is False:
                        self.setItem(i,j,QTableWidgetItem('%.4f'%float(self.cur_line[j])))
                    else:
                        self.setItem(i,j,QTableWidgetItem(str(self.cur_line[j])))
            self.resizeColumnsToContents()
            self.horizontalHeader().setStretchLastSection(True)
            # self.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
            self.setRowCount(len(array))
            self.setTableRowName(row_name)


