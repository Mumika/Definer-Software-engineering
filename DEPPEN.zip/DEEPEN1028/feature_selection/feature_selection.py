import os
from util.commonUtil import load_data_from_text
from scipy.stats import ttest_ind_from_stats
import  pandas as pd
import  numpy as np
import math

'''
============================================================
    CHI2
============================================================
'''
def CHI2(sample_name,feature_name,text,feature_number):
    """

    :param file: 文件csv
    :param feature_number: 卡方检验后保留的特征个数
    :return:
    """

    try:
        feature_number=int(feature_number)
        datalabel,dataframe=load_data_from_text(sample_name,feature_name,text)
        # print(dataframe)
        binBox = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
        labels = datalabel.tolist()
        data = np.array(dataframe.values)

        #特征个数
        features = dataframe.columns

        if data.shape[0] < 5 or data.shape[1] < 2:
            error_msg = 'Sample number is two less'
            return ''
        #样本个数
        sampleNumber = len(data)
        #标签类别
        labelClass = set(labels)

        myFea = {}

        #特征数
        for i in range(len(features)):
            array = data[:, i].astype(np.float64)
            newArray = list(pd.cut(array, len(binBox), labels=binBox)) #给每一个特征下的样本分类
            binBoxClass = set(newArray)
            myObservation = {}
            # get方法 返回字典的值 如果能找到则返回值 找不到返回0，目的是看每一个特征下 binBoxClass类别出现的次数 返回到字典显示
            for j in range(len(labels)):
                myObservation[str(labels[j]) + str(newArray[j])] = myObservation.get(str(labels[j]) + str(newArray[j]), 0) + 1
            myExpect = {}
            # 原始数据中标签出现的次数*新标签中标签出现的次数/样本个数 维护到字典中
            for j in labelClass:
                for k in binBox:
                    myExpect[str(j) + str(k)] = labels.count(j) * newArray.count(k) / sampleNumber
            chiValue = 0
            #卡方检验
            for j in labelClass:
                for k in binBoxClass:
                    chiValue = chiValue + pow(((myObservation.get(str(j) + str(k), 0)) - myExpect.get(str(j) + str(k), 0)),
                                            2) / myExpect[str(j) + str(k)]
            myFea[features[i]] = chiValue
        res = []
        #按照卡方值排序
        for key in sorted(myFea.items(), key=lambda item: item[1], reverse=True):
            res.append([key[0], '{0:.3f}'.format(myFea[key[0]])])
        feature_selection_result = pd.DataFrame(res, columns=['SampleName', 'Values'])
        # print(feature_selection_result)
        selected_feature_number = feature_number if feature_number <= data.shape[1] else data.shape[1]
        # print(feature_selection_result.SampleName[:selected_feature_number])
        feature_selection_data = dataframe.loc[:, feature_selection_result.SampleName[:selected_feature_number]]
        #插入标签，返回卡方检验后排序值
        feature_selection_data['Labels']= datalabel
        feature_selection_data.insert(0,'SampleName',sample_name)
        # print(feature_selection_data)
        return feature_selection_data
    except Exception as e:
        error_msg = str(e)
        return ''
'''
============================================================
    FScore
============================================================
'''
def Calculate_Fscore(array, labels):
    try:
        array_po = []
        array_ne = []
        for i in range(len(labels)):
            if labels[i] == 1:
                array_po.append(array[i])
            else:
                array_ne.append(array[i])
        mean_po = sum(array_po) / len(array_po)
        mean_ne = sum(array_ne) / len(array_ne)
        mean = sum(array) / len(array)
        score_1 = ((mean_po - mean) ** 2 + (mean_ne - mean) ** 2)
        score_2 = sum([(i-mean_po) ** 2 for i in array_po]) / (len(array_po) - 1)
        score_3 = sum([(i-mean_ne) ** 2 for i in array_ne]) / (len(array_ne) - 1)
        if score_2 + score_3 == 0:
            return 0
        else:
            f_score = score_1 / (score_2 + score_3)
            return f_score
    except Exception as e:
        return 0

def FScore(sample_name,feature_name,file,feature_number):
    try:
        feature_number=int(feature_number)
        datalabel, dataframe = load_data_from_text(sample_name,feature_name,file)
        labels = datalabel.tolist()
        data = np.array(dataframe.values)
        features = dataframe.columns

        if data.shape[0] < 5 or data.shape[1] < 2:
            error_msg = 'Sample number is two less'
            return ''

        myFea = {}
        for i in range(len(features)):
            array = list(data[:, i].astype(np.float64))
            myFea[features[i]] = Calculate_Fscore(array, labels)

        res = []
        for key in sorted(myFea.items(), key=lambda item: item[1], reverse=True):
            res.append([key[0], '{0:.3f}'.format(myFea[key[0]])])
        feature_selection_result = pd.DataFrame(res, columns=['SampleName', 'Values'])
        selected_feature_number = feature_number if feature_number <= data.shape[1] else data.shape[1]
        feature_selection_data = dataframe.loc[:, feature_selection_result.SampleName[:selected_feature_number]]
        # feature_selection_data.insert(0, 'Labels', datalabel)
        feature_selection_data['Labels']= datalabel
        feature_selection_data.insert(0,'SampleName',sample_name)
        # print(feature_selection_data)
        return feature_selection_data
    except Exception as e:
        error_msg = str(e)
        return ''

'''
============================================================
    IG
============================================================
'''
def calProb(array):
    myProb = {}
    myClass = set(array)
    for i in myClass:
        myProb[i] = array.count(i) / len(array)
    return myProb

def jointProb(newArray, labels):
    myJointProb = {}
    for i in range(len(labels)):
        myJointProb[str(newArray[i]) + '-' + str(labels[i])] = myJointProb.get(str(newArray[i]) + '-' + str(labels[i]), 0) + 1
    for key in myJointProb:
        myJointProb[key] = myJointProb[key] / len(labels)
    return myJointProb

def IG(sample_name,feature_name,file,feature_number):
    try:
        feature_number=int(feature_number)
        datalabel, dataframe = load_data_from_text(sample_name,feature_name,file)
        binBox = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
        labels = datalabel.tolist()
        data = np.array(dataframe.values)
        features = dataframe.columns


        if data.shape[0] < 5 or data.shape[1] < 2:
            error_msg = 'Sample number is two less'
            return ''

        #数据集标签的占比
        probY = calProb(labels)

        myFea = {}
        for i in range(len(features)):
            #每一个特征对应的样本数值
            array = data[:, i].astype(np.float64)
            #根据每一个特征数的样本数值 重新划区间
            newArray = list(pd.cut(array, len(binBox), labels= binBox))
            binBoxClass = set(newArray)

            #返回newArray划分区间 每一个区间占比 未拼接的
            probX = calProb(newArray)
            #返回newArray划分区间 每一个区间占比 拼接的
            probXY = jointProb(newArray, labels)
            HX = -1 * sum([p * math.log(p, 2) for p in probX.values()])
            HXY = 0
            for y in probY.keys():
                for x in probX.keys():
                    if str(x) + '-' + str(y) in probXY:
                        HXY = HXY + (probXY[str(x) + '-' + str(y)] * math.log(probXY[str(x) + '-' + str(y)] / probY[y], 2))
            myFea[features[i]] = HX + HXY

        res = []
        for key in sorted(myFea.items(), key=lambda item:item[1], reverse=True):
            res.append([key[0], '{0:.3f}'.format(myFea[key[0]])])
        feature_selection_result = pd.DataFrame(res, columns=['SampleName', 'Values'])
        selected_feature_number = feature_number if feature_number <= data.shape[1] else data.shape[1]
        feature_selection_data = dataframe.loc[:, feature_selection_result.SampleName[:selected_feature_number]]
        # feature_selection_data.insert(0, 'Labels', datalabel)
        feature_selection_data['Labels']= datalabel
        feature_selection_data.insert(0,'SampleName',sample_name)
        return feature_selection_data
    except Exception as e:
        error_msg = str(e)
        return ''

'''
============================================================
    MIC
============================================================
'''
def calProb(array):
    myProb = {}
    myClass = set(array)
    for i in myClass:
        myProb[i] = array.count(i) / len(array)
    return myProb

def jointProb(newArray, labels):
    myJointProb = {}
    for i in range(len(labels)):
        myJointProb[str(newArray[i]) + '-' + str(labels[i])] = myJointProb.get(str(newArray[i]) + '-' + str(labels[i]), 0) + 1
    for key in myJointProb:
        myJointProb[key] = myJointProb[key] / len(labels)
    return myJointProb

def MIC(sample_name,feature_name,file,feature_number):
    try:
        feature_number=int(feature_number)
        datalabel, dataframe = load_data_from_text(sample_name,feature_name,file)
        binBox = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
        labels = datalabel.tolist()
        data = np.array(dataframe.values)
        features = dataframe.columns

        if data.shape[0] < 5 or data.shape[1] < 2:
            error_msg = 'Sample number is two less'
            return ''

        probY = calProb(labels)
        myFea = {}
        for i in range(len(features)):
            array = data[:, i].astype(np.float64)
            newArray = list(pd.cut(array, len(binBox), labels= binBox))
            binBoxClass = set(newArray)
            probX = calProb(newArray)
            probXY = jointProb(newArray, labels)
            mic = 0
            for x in probX.keys():
                for y in probY.keys():
                    if str(x) + '-' + str(y) in probXY:
                        mic = mic + probXY[str(x) + '-' + str(y)] * math.log(probXY[str(x) + '-' + str(y)]/(probX[x] * probY[y]), 2)
            myFea[features[i]] = mic

        res = []
        for key in sorted(myFea.items(), key=lambda item:item[1], reverse=True):
            res.append([key[0], '{0:.3f}'.format(myFea[key[0]])])
        feature_selection_result = pd.DataFrame(res, columns=['SampleName', 'Values'])
        selected_feature_number = feature_number if feature_number <= data.shape[1] else data.shape[1]
        feature_selection_data = dataframe.loc[:, feature_selection_result.SampleName[:selected_feature_number]]
        # feature_selection_data.insert(0, 'Labels', datalabel)
        feature_selection_data['Labels']= datalabel
        feature_selection_data.insert(0,'SampleName',sample_name)
        return feature_selection_data
    except Exception as e:
        error_msg = str(e)
        return ''
'''
============================================================
    Pearsonr
============================================================
'''
def multipl(a,b):
    sumofab=0.0
    for i in range(len(a)):
        temp=a[i]*b[i]
        sumofab+=temp
    return sumofab

def corrcoef(x,y):
    try:
        n = len(x)
        sum1 = sum(x)
        sum2 = sum(y)
        sumofxy = multipl(x, y)
        sumofx2 = sum([pow(i, 2) for i in x])
        sumofy2 = sum([pow(j, 2) for j in y])
        num = sumofxy - (float(sum1) * float(sum2) / n)
        den = math.sqrt((sumofx2 - float(sum1 ** 2) / n) * (sumofy2 - float(sum2 ** 2) / n))
        if den != 0:
            return num / den
        else:
            return 0
    except Exception as e:
        return 0

def Pearsonr(sample_name,feature_name,file,feature_number):
    try:
        feature_number=int(feature_number)
        datalabel, dataframe = load_data_from_text(sample_name,feature_name,file)
        labels = datalabel.tolist()
        data = np.array(dataframe.values)
        features = dataframe.columns

        if data.shape[0] < 5 or data.shape[1] < 2:
            error_msg = 'Sample number is two less'
            return ''

        myFea = {}
        for i in range(len(features)):
            array = list(data[:, i].astype(np.float64))
            myFea[features[i]] = corrcoef(array, labels)

        res = []
        for key in sorted(myFea.items(), key=lambda item: item[1], reverse=True):
            res.append([key[0], '{0:.3f}'.format(myFea[key[0]])])
        feature_selection_result = pd.DataFrame(res, columns=['SampleName', 'Values'])
        selected_feature_number = feature_number if feature_number <= data.shape[1] else data.shape[1]

        feature_selection_data = dataframe.loc[:, feature_selection_result.SampleName[:selected_feature_number]]
        feature_selection_data['Labels']= datalabel
        feature_selection_data.insert(0,'SampleName',sample_name)
        # feature_selection_data.insert(0, 'Labels', datalabel)
        
        return feature_selection_data
    except Exception as e:
        error_msg = str(e)
        return ''
'''
============================================================
    t_test
============================================================
'''
def T_test(file,feature_number):
    datalabel,data=load_data_from_text(file)
    # print(data)
    data=data.astype(np.float64)
    p_lable=[i for i in range(len(datalabel)) if(datalabel[i]==1)]
    N_lable=[i for i in range(len(datalabel)) if(datalabel[i]==0)]
    p_sample=data.iloc[p_lable]
    N_sample=data.iloc[N_lable]



    p_mean, n_mean = p_sample.mean(axis=0), N_sample.mean(axis=0)
    p_std, n_std = p_sample.std(axis=0), N_sample.std(axis=0)
    t_value, p_value = ttest_ind_from_stats(
        p_mean, p_std, p_sample.shape[0], n_mean, n_std, N_sample.shape[0])
    # 获取到所有的基因p_value值
    p_value = pd.Series(data=p_value, index=list(range(len(p_value))))
    # 按照升序排序得到的索引排序
    sort_index = p_value.sort_values(ascending='').index
    print(sort_index)
    reindex_data = ['F_%s' % i for i in sort_index]
    selected_feature_number = feature_number if feature_number <= data.shape[1] else data.shape[1]
    selected_feature=reindex_data[:selected_feature_number]
    feature_selection_data=data.loc[:,selected_feature]
    feature_selection_data.insert(selected_feature_number, 'Labels', datalabel)
    return feature_selection_data