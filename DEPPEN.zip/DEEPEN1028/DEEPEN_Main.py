from Result import ResultContentWidget
from Const import DL_METHOD, GENERAL_METHOD
from ModelSelction import ModelSelectionContentWidget
from datetime import date
from os import name
import sys
import qdarkgraystyle
from PyQt5.QtGui import QIcon,QFont,QStandardItemModel,QStandardItem 
from PyQt5.QtWidgets import (QWidget,QSplitter,QTabWidget,QLabel,QTextEdit,QPushButton,QLineEdit,QTableWidgetItem,
                              QMainWindow,QDesktopWidget,QApplication,QGridLayout,QVBoxLayout,QTableWidget,QAbstractItemView,
                                QAction,QMessageBox,QMenu,qApp,QFileDialog,QRadioButton,QTableView,QHeaderView)
from PyQt5.QtCore import QObject,Qt,pyqtSignal

from Encoding import EncodingContentWidget
from FeatureSelection import FeatureSelectionContentWidget
from CommonWidget import NextWidget, PreviousWidget, ChangeStateWidget
import EmbeddingVisTool
# MainTabWidget contains four tab Widget
class MainTabWidget(QTabWidget):
    def __init__(self):
        super().__init__()
        self.initUI()
    def initUI(self):
        import imp
        try:
            # imp.find_module('eggs')

            '''Add subQWidget '''
            self.tab_encoding = QWidget()
            self.tab_feature_selection = QWidget()
            self.tab_model_selection = QWidget()
            self.tab_result = QWidget()
            self.addTab(self.tab_encoding, "Encoding ")
            self.addTab(self.tab_feature_selection, "Feature Selection (Support non-DL encoding methods)")#Machine learning coding is available
            self.addTab(self.tab_model_selection, 'Model Selection ')
            self.addTab(self.tab_result, 'Result')
            '''Initialize tabWidget'''
            self.set_tab_encoding()
            self.set_tab_feature_selection()
            self.set_tab_model_selection()
            self.set_tab_result()
        except ImportError:
            QMessageBox.warning(self, 'Warning', 'Please install ... in the python environment first.', QMessageBox.Ok,
                                QMessageBox.Ok)
            exit(0)

    def show_tab_encoding(self):
        self.setCurrentWidget(self.tab_encoding)
        
    def show_tab_feature_selection(self):
        self.setCurrentWidget(self.tab_feature_selection)
    def show_tab_model_selection(self):
        self.setCurrentWidget(self.tab_model_selection)
    def show_tab_result(self):
        self.setCurrentWidget(self.tab_result)
    def show_single_tab(self,id):
        for i in range(4):
            if i!=id:
                self.setTabEnabled(i, False)
    def show_tab(self,curtab,data):
        self.refresh_show_tab()
        atabid=0
        if curtab=='Encoding':
            if data is None:
                QMessageBox.about(self,'Error',"Data is empty!")
            elif data.encoding_panel.method in DL_METHOD:
                atabid=2
                self.show_tab_model_selection()
                self.main_model_selection.setdata(data)
            else:
                atabid=1
                self.show_tab_feature_selection()
                self.main_feature_selection.setdata(data)
                self.main_feature_selection.parameterWidget.next_btn_signal.emit(data)#maybe skip fs
        elif curtab=='FeatureSelection':
            atabid=2
            self.show_tab_model_selection()
            self.main_model_selection.setdata(data) 
        elif curtab=='ModelSelection':
            atabid=3
            self.main_result.setdata(data)
            self.show_tab_result()
        self.show_single_tab(atabid)
    def clearAfterTabContent(self,curtab,data):
        curtab_index={'Encoding':0,'FeatureSelection':1,'ModelSelection':2}
        all_main_tab=[self.main_encoding,self.main_feature_selection,self.main_model_selection]
        index=curtab_index[curtab]
        for i in range(index,3):
            all_main_tab[i].resultWidget.clearData()
    


    def show_pretab(self,curtab,data):#This function doesn't set value
        self.refresh_show_tab()
        atabid=0
        if curtab=='FeatureSelection':
            atabid=0
            self.show_tab_encoding()
        elif curtab=='ModelSelection':
            if data.encoding_panel.method in DL_METHOD:
                atabid=0
                self.show_tab_encoding()
            else:
                atabid=1
                self.show_tab_feature_selection()
        elif curtab=='Result':
            atabid=2
            self.show_tab_model_selection()
        self.show_single_tab(atabid)
    def refresh_show_tab(self):
        for i in range(4):
            self.setTabEnabled(i, True)

    def set_tab_encoding(self):
        
        layout = QVBoxLayout()
        
        self.main_encoding = EncodingContentWidget()
        self.changeStateWidget=ChangeStateWidget('Encoding','First')
        
        #set connect
        self.changeStateWidget.nextWidget.next_signal.connect(self.show_tab)
        self.main_encoding.allMethodWidget.chooseWidget.next_btn_signal.connect(self.changeStateWidget.nextWidget.setData)
        
        #set layout
        splitter = QSplitter(Qt.Vertical)
        splitter.addWidget(self.main_encoding)
        splitter.addWidget(self.changeStateWidget)
        splitter.setSizes([1000, 50])

        layout.addWidget(splitter)
        self.tab_encoding.setLayout(layout)
        

    def set_tab_feature_selection(self):
        layout = QVBoxLayout()
        self.main_feature_selection = FeatureSelectionContentWidget()
        
        #set connect
        self.changeStateWidget=ChangeStateWidget('FeatureSelection','Other')
        self.changeStateWidget.nextWidget.next_signal.connect(self.show_tab)
        self.changeStateWidget.previousWidget.previous_signal.connect(self.show_pretab)
        # self.changeStateWidget.previousWidget.previous_signal.connect(self.clearAfterTabContent) #clear tab content
        self.main_feature_selection.parameterWidget.next_btn_signal.connect(self.changeStateWidget.nextWidget.setData)
        self.main_feature_selection.parameterWidget.next_btn_signal.connect(self.changeStateWidget.previousWidget.setData)
        '''
            现在的逻辑是当显示一个新的组件，会有一个信号触发，然后将这个数据传递给next组件中
            现在需要修改的还有，就是当这个页面进行操作之后也会产生一个信号，然后这个信号会触发更改当前界面的数据，然后这个数据也会被存储在next组件中

            next组件中的next按钮会触发一个信号，然后这个信号会跳转到一个新的tab，同时为这个tab赋上这个next中的值


        '''
        
        #set layout
        splitter = QSplitter(Qt.Vertical)
        splitter.addWidget(self.main_feature_selection)
        splitter.addWidget(self.changeStateWidget)
        splitter.setSizes([1000, 50])

        layout.addWidget(splitter)
        self.tab_feature_selection.setLayout(layout)


    def set_tab_model_selection(self):
        layout = QVBoxLayout()
        
        self.main_model_selection = ModelSelectionContentWidget()

        #set connect
        self.changeStateWidget=ChangeStateWidget('ModelSelection','Other')
        self.changeStateWidget.nextWidget.next_signal.connect(self.show_tab)
        self.changeStateWidget.previousWidget.previous_signal.connect(self.show_pretab)
        self.changeStateWidget.previousWidget.previous_signal.connect(self.clearAfterTabContent)
        
        self.main_model_selection.allmethodWidget.chooseWidget.next_btn_signal.connect(self.changeStateWidget.nextWidget.setData)
        self.main_model_selection.allmethodWidget.chooseWidget.pre_signal.connect(self.changeStateWidget.previousWidget.setData)
        
        #set layout
        splitter = QSplitter(Qt.Vertical) 
        splitter.addWidget(self.main_model_selection)
        splitter.addWidget(self.changeStateWidget)
        splitter.setSizes([1000, 50])

        layout.addWidget(splitter)
        self.tab_model_selection.setLayout(layout)
    def set_tab_result(self):
        layout = QVBoxLayout()
        
        self.main_result = ResultContentWidget()

        self.changeStateWidget=ChangeStateWidget('Result','Last')
        # self.changeStateWidget.nextWidget.next_signal.connect(self.show_tab)
        self.changeStateWidget.previousWidget.previous_signal.connect(self.show_pretab)

        # self.main_result.parameterWidget.next_btn_signal.connect(self.changeStateWidget.previousWidget.setData)
        #set layout
        splitter = QSplitter(Qt.Vertical) 
        splitter.addWidget(self.main_result)
        splitter.addWidget(self.changeStateWidget)
        splitter.setSizes([1000, 50])

        layout.addWidget(splitter)
        self.tab_result.setLayout(layout)
    

#MainWindow loads MainTabWidget
class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.initUI()

    def initUI(self):
        
        #Set window properties
        self.setWindowTitle('DEEPEN')
        #self.setWindowIcon(QIcon('D2.png'))#set icon
        self.center()

        #Set style
        self.setStyleSheet(qdarkgraystyle.load_stylesheet_pyqt5())
    
        #Set Menu and bar
        self.setMenu()
        # self.statusBar().showMessage('State.')

        #Set core widget   
        self.mtab = MainTabWidget()
        self.mtab.show_single_tab(0)
        self.setCentralWidget(self.mtab)
        

        self.show()

    #Set its size and location
    def center(self):
        self.resize(800, 600)
        self.setWindowState(Qt.WindowMaximized)#set windowMaximized
        qr=self.frameGeometry()
        cp = QDesktopWidget().availableGeometry().center()
        qr.moveCenter(cp)
        self.move(qr.topLeft())

    #Set menu
    def setMenu(self):
        menubar=self.menuBar()
        
        #function menu
        funcMenu = menubar.addMenu('Fucntion')

        preDictAct=QAction('Exit',self)
        preDictAct.triggered.connect(self.closeEvent)
        funcMenu.addAction(preDictAct)
        # preDictAct.setStatusTip('Predict')


        # fileMenu = QMenu('File Operation', self)

        # iptDictAct=QAction('Import',self)#导入
        # iptDictAct.triggered.connect(self.toggleMenu)
        # iptDictAct.setStatusTip('Import')


        # fileMenu.addAction(iptDictAct)

        # # funcMenu.addMenu(selectModelMenu)
        # funcMenu.addMenu(fileMenu)
        # funcMenu.addAction(preDictAct)
        
        # tool menu
        toolMenu = menubar.addMenu('Tool')

        embedVisAct=QAction('Embedding visualization',self)
        embedVisAct.triggered.connect(self.showEmbedVisActEvent)
        toolMenu.addAction(embedVisAct)


        # help menu
        helpMenu=menubar.addMenu('Help')
        runExAction=QAction('Example',self)
        helpMenu.addAction(runExAction)
        runExAction.triggered.connect(self.toggleMenu)
        
        abtAction=QAction('About',self)
        helpMenu.addAction(abtAction)
        abtAction.triggered.connect(self.aboutEvent)
    def showEmbedVisActEvent(self):
        self.embedVisWin = EmbeddingVisTool.MainWindow()
        self.embedVisWin.setFont(QFont('Arial', 10))
        self.embedVisWin.setStyleSheet(qdarkgraystyle.load_stylesheet_pyqt5())
        self.embedVisWin.close_signal.connect(self.recover)
        self.embedVisWin.show()
        self.setDisabled(True)
        self.setVisible(False)
    
    def recover(self, module):
        try:
            if module == 'EmbeddingVis':                
                del self.embedVisWin               
        except Exception as e:
            pass
        self.setDisabled(False)
        self.setVisible(True)

    #Button triggers event
    def toggleMenu(self, state):
        sender = self.sender()
        sfun=sender.text()
    def aboutEvent(self,state):
        QMessageBox.about(self, 'About', 'DEEPEN 1.0\nAuthor : Jiaxin Zheng \n\nAlgorithm implementation : Cuinan Yu ;Yingrui Li')


    def closeEvent(self, event):
        reply = QMessageBox.question(self, 'Confirm Exit', 'Are you sure want to quit?', QMessageBox.Yes | QMessageBox.No,
                                     QMessageBox.No)
        if reply == QMessageBox.Yes:
            # self.close_signal.emit('Basic')
            import os
            event.accept()
            os._exit(0)
            self.close()
        else:
            if event:
                event.ignore()


app = QApplication(sys.argv)
window=MainWindow()
# window.mtab.main_encoding.choosewidget.encoding_signal.connect(window.mtab.main_encoding.rightWidget.refreshData)
def exec():
    sys.exit(app.exec_())

if __name__=="__main__":
    exec()