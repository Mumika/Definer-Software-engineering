from util.commonUtil import preprocess_fasta
import numpy as np
import  re
import  os
import numpy as np
import time
from collections import Counter
import tqdm
import time
import pickle

def AAC(file,params,output_file=''):
    """

    :param file: encoding_array(ndarray),list_code(list)
    :return:
    """
    try:
        # clear
        fasta_list=preprocess_fasta(file)
        fasta_list=fasta_list[0]
        encoding_array = np.array([])
        AA = 'ACDEFGHIKLMNPQRSTVWY'
        header = ['SampleName', 'Label']
        encodings = []
        for i in AA:
            header.append(i)
        encodings.append(header)
        list_code=[]

        for i in fasta_list:
            name, sequence, label = i[0], re.sub('-', '', i[1]), i[2]
            #映射出字符出现的次数生成一个字典
            count = Counter(sequence)
            for key in count:
                count[key] = count[key] / len(sequence) #算出占比
            code = []
            for aa in AA:
                code.append(count[aa])
            code.append(int(label))
            list_code.append(code)

        encoding_array = np.array(list_code, dtype=str)
        #算出字符出现的频率

        vocab=['A', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'K', 'L', 'M', 'N', 'P', 'Q', 'R', 'S', 'T', 'V', 'W', 'Y']
        return  list_code,encoding_array,header,vocab


    except Exception as e:
        error_msg = str(e)
        return False
def sequence_with_equal_length(file):
    
    fasta_list=preprocess_fasta(file)
    fasta_list=fasta_list[0]

    length_set = set()
    length_set_1 = set()
    for item in fasta_list:
        #保存基因序列的个数
        length_set.add(len(item[1]))
        length_set_1.add(len(re.sub('-', '', item[1])))  #将-用空格代替 统计划分后出现的长度

    length_set = sorted(length_set)
    length_set_1 = sorted(length_set_1)

    if len(length_set) == 1:  #判断每条长度是否相等 ,length_set_1[0]最短的数据集，length_set_1[-1]最长的数据集
        return True, length_set[0], length_set[-1], length_set_1[0], length_set_1[-1]
    else:
        return False, length_set[0], length_set[-1], length_set_1[0], length_set_1[-1]

def EAAC(file,params,output_file=''):
    try:
        encoding_array = np.array([])
        fasta_list,sample_purpose,error_msg=preprocess_fasta(file)


        is_equal,length_set_begin,length_set_end,length_set_1_begin,length_set_1_end=sequence_with_equal_length(file)
        if not is_equal:
            error_msg = 'EAAC descriptor need fasta sequence with equal length.'
            return False
        sliding_window=int(params['sliding_window'])
        AA = 'ARNDCQEGHILKMFPSTWYV'
        encodings = []
        header = ['SampleName', 'Label']
        # 滑动窗口生成的碱基对个数fasta_list[0][1]) - sliding_window + 1，因为range左包右闭
        for w in range(1, len(fasta_list[0][1]) - sliding_window + 2):
            for aa in AA:
                header.append('SW.' + str(w) + '.' + aa)
        encodings.append(header)
        code_middle = []
        for i in fasta_list:
            name, sequence, label = i[0], i[1], i[2]

            # code = [name, label]
            code_new = []
            for j in range(len(sequence)):
                if j < len(sequence) and j + sliding_window <= len(sequence):
                    count = Counter(sequence[j:j +sliding_window]) #滑动步长生成的序列放进counter
                    for key in count:
                        count[key] = count[key] / len(sequence[j:j + sliding_window]) #统计字符在滑动窗口选取序列出现的概率
                    for aa in AA:
                          #将每一次滑动窗口出现的字符概率映射到'ARNDCQEGHILKMFPSTWYV'
                        code_new.append(count[aa])
                    code_new.append(int(label))
            code_middle.append(code_new)
        encoding_array = np.array([])
        encoding_array = np.array(code_middle, dtype=str)
        # EACC_csv=code_middle
        # DataFrame=pd.DataFrame(EACC_csv)
        # DataFrame.to_csv(output_file, header=0, index=0)
        vocab=['A', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'K', 'L', 'M', 'N', 'P', 'Q', 'R', 'S', 'T', 'V', 'W', 'Y']
        return  code_middle,encoding_array,header,vocab



    except Exception as e:
        error_msg = str(e)
        return False
def DPC(file,params,output_file=''):
    try:
        fasta_list=preprocess_fasta(file)
        fasta_list=fasta_list[0]
        # clear
        encoding_array = np.array([])

        AA = 'ACDEFGHIKLMNPQRSTVWY'
        encodings = []
        #按照AA排列组合生成一个新的列表
        diPeptides = [aa1 + aa2 for aa1 in AA for aa2 in AA]
        header = ['SampleName', 'label'] + diPeptides
        encodings.append(header)

        list_code=[]
        #这分字典是将AA中的字符按照他们的排序方式存入字典当中
        AADict = {}

        for i in range(len(AA)):
            AADict[AA[i]] = i

        for i in fasta_list:
            name, sequence, label = i[0], re.sub('-', '', i[1]), i[2]
            code = []
            tmpCode = [0] * 400
            for j in range(len(sequence) - 2 + 1):
                #以AA长度为20代表一组
                tmpCode[AADict[sequence[j]] * 20 + AADict[sequence[j + 1]]] = tmpCode[AADict[sequence[j]] * 20 + AADict[
                    sequence[j + 1]]] + 1
            if sum(tmpCode) != 0:
                tmpCode = [i / sum(tmpCode) for i in tmpCode]
            code = code + tmpCode
            code.append(label)
            list_code.append(code)

        encoding_array = np.array(list_code, dtype=str)
        #算出字符出现的频率

        vocab=['A', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'K', 'L', 'M', 'N', 'P', 'Q', 'R', 'S', 'T', 'V', 'W', 'Y']
        return  list_code,encoding_array,header,vocab

    except Exception as e:
        error_msg = str(e)
        return False
def CKSAAP(file,params,output_file=''):
    try:
        # clear
        encoding_array = np.array([])
        fasta_list,sample_purpose,error_msg=preprocess_fasta(file)
        header = ['SampleName', 'Label']
        kspace=int(params['Kspace'])
        AA = 'ACDEFGHIKLMNPQRSTVWY'
        encodings = []
        aaPairs = []
        for aa1 in AA:
            for aa2 in AA:
                aaPairs.append(aa1 + aa2)

        header = ['SampleName', 'label']

        gap = kspace
        #做了一个2^20 ['AA', 'AC', 'AD', 'AE', 'AF', 'AG', 'AH', 'AI', 'AK', 'AL', 'AM', 'AN', 'AP', 'AQ', 'AR'...., 'YM', 'YN', 'YP', 'YQ', 'YR', 'YS', 'YT', 'YV', 'YW', 'YY']
        #一共400个
        for g in range(gap + 1):
            for aa in aaPairs:
                header.append(aa + '.gap' + str(g))
        encodings.append(header)

        for i in fasta_list:
            end_code = []
            print("*"*100)
            name, sequence, label = i[0], re.sub('-', '' , i[1]), i[2]
            code = [name, label]
            #字典的长度为400，gap取为步长
            for g in range(gap):
                begin_code = []
                myDict = {}
                for pair in aaPairs:
                    myDict[pair] = 0
                sum = 0
                #按照随机因子，随机选取两个字母进行组合,sum为在myDict中出现的次数
                for index1 in range(len(sequence)):
                    index2 = index1 + g + 1
                    if index1 < len(sequence) and index2 < len(sequence) and sequence[index1] in AA and sequence[
                        index2] in AA:  #只要在mydict中出现一次就加1
                        myDict[sequence[index1] + sequence[index2]] = myDict[sequence[index1] + sequence[index2]] + 1
                        sum = sum + 1
                print(sum)
                print(myDict)

                for pair in aaPairs:
                    begin_code.append(myDict[pair] / sum)

                end_code.append(begin_code)
            encoding_array = np.array(end_code, dtype=str)
            # np.save(savefile+"\\{}".format(i[0]), encoding_array)



        column = encoding_array.shape[1]
        row = encoding_array.shape[0] - 1
        del encodings
        if encoding_array.shape[0] > 1:
            vocab=['A', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'K', 'L', 'M', 'N', 'P', 'Q', 'R', 'S', 'T', 'V', 'W', 'Y']
            return  end_code,encoding_array,header,vocab
        else:
            return False
    except Exception as e:
        error_msg = str(e)
        return False

def CKSAAP1(file,params,output_file=''):
    try:
        # clear
        encoding_array = np.array([])
        fasta_list,sample_purpose,error_msg=preprocess_fasta(file)
        AA = 'ACDEFGHIKLMNPQRSTVWY'
        encodings = []
        aaPairs = []
        for aa1 in AA:
            for aa2 in AA:
                aaPairs.append(aa1 + aa2)

        header = ['SampleName', 'Label']
        kspace=int(params['Kspace'])
        gap = kspace
        #做了一个2^20 ['AA', 'AC', 'AD', 'AE', 'AF', 'AG', 'AH', 'AI', 'AK', 'AL', 'AM', 'AN', 'AP', 'AQ', 'AR'...., 'YM', 'YN', 'YP', 'YQ', 'YR', 'YS', 'YT', 'YV', 'YW', 'YY']
        #一共400个
        for g in range(gap + 1):
            for aa in aaPairs:
                header.append(aa + '.gap' + str(g))
        encodings.append(header)

        for i in fasta_list:
            end_code = []
            # print("*"*100)
            name, sequence, label = i[0], re.sub('-', '' , i[1]), i[2]
            code = [name, label]
            #字典的长度为400，gap取为步长
            for g in range(gap + 1):
                begin_code = []
                myDict = {}
                for pair in aaPairs:
                    myDict[pair] = 0
                sum = 0
                #按照随机因子，随机选取两个字母进行组合,sum为在myDict中出现的次数
                for index1 in range(len(sequence)):
                    index2 = index1 + g + 1
                    if index1 < len(sequence) and index2 < len(sequence) and sequence[index1] in AA and sequence[
                        index2] in AA:  #只要在mydict中出现一次就加1
                        myDict[sequence[index1] + sequence[index2]] = myDict[sequence[index1] + sequence[index2]] + 1
                        sum = sum + 1
                # print(sum)
                # print(myDict)

            for pair in aaPairs:
                begin_code.append(myDict[pair] / sum)

            end_code.append(begin_code)
            # encoding_array = np.array(end_code, dtype=str)
            

        # column = encoding_array.shape[1]
        # row = encoding_array.shape[0] - 1
        # # del encodings
        # if encoding_array.shape[0] > 1:
        if len(output_file)>0:
            np.save(output_file+"\\{}".format(i[0]), encoding_array)
        
        encoding_array = np.array([])
        encoding_array = np.array(end_code, dtype=str)
        vocab=['A', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'K', 'L', 'M', 'N', 'P', 'Q', 'R', 'S', 'T', 'V', 'W', 'Y']
        return  end_code,encoding_array,header,vocab
        # else:
            # return False
    except Exception as e:
        error_msg = str(e)
        return False