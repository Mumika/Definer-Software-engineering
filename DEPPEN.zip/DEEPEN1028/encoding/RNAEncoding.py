import  re
import  os
import numpy as np
import time
from collections import Counter
import tqdm
import time
import pickle
import random
import itertools
import time
import pandas as pd
from util.commonUtil import preprocess_fasta

def sequence_with_equal_length(file):
    """

    :param file:
    :return:  判断
    """
    fasta_list, sample_purpose, error_msg = preprocess_fasta(file)
    length_set = set()
    length_set_1 = set()
    for item in fasta_list:
        length_set.add(len(item[1]))
        length_set_1.add(len(re.sub('-', '', item[1])))

    length_set = sorted(length_set)
    length_set_1 = sorted(length_set_1)
    "判断每条序列长度是否相同"
    if len(length_set) == 1:
        return True, length_set[0], length_set[-1], length_set_1[0], length_set_1[-1]
    else:
        return False, length_set[0], length_set[-1], length_set_1[0], length_set_1[-1]


def Binary(file,params,output_file=''):
    """

    :param file:
    :return: encode （list） encoding_array(ndarray)
    """
    try:
        fasta_list, sample_purpose, error_msg = preprocess_fasta(file)
        is_equal, minimum_length, maximum_length, minimum_length_without_minus, maximum_length_without_minus = sequence_with_equal_length(file)
        if not is_equal:
            error_msg = 'binary descriptor need fasta sequence with equal length.'
            return False
        AA = 'ACGT'
        encodings = []
        header = ['SampleName', 'Label']
        for i in range(1, len(fasta_list[0][1]) * 4 + 1):  #变成原有数据长度4倍
            header.append('BINARY.F' + str(i))



        for i in fasta_list:
            name, sequence, label = i[0], i[1], i[2]
            code = []
            for aa in sequence:
                if aa == '-':
                    code = code + [0]
                    continue

                if(aa=='A'):
                    code = code + [1]
                elif(aa=='C'):
                    code=code+[2]
                elif(aa=='G'):
                    code=code+[3]
                elif(aa=='T'):
                    code = code + [4]
                else:
                    code = code + [5]
            code.append(int(label))
            encodings.append(code)
        # 保存到csv文件当中
        binary_csv=encodings
        DataFrame=pd.DataFrame(binary_csv)
        if len(output_file)>0:
            DataFrame.to_csv(output_file,header=0,index=0)

        encoding_array = np.array([])
        encoding_array = np.array(encodings, dtype=str)
        vocab=['A','G','C','U']
        return  encodings,encoding_array,header,vocab
    except Exception as e:
        error_msg = str(e)
        return False

def sequence_with_equal_length(file):
    """

    :param file:
    :return:  判断
    """
    fasta_list, sample_purpose, error_msg = preprocess_fasta(file)
    length_set = set()
    length_set_1 = set()
    for item in fasta_list:
        length_set.add(len(item[1]))
        length_set_1.add(len(re.sub('-', '', item[1])))

    length_set = sorted(length_set)
    length_set_1 = sorted(length_set_1)
    "判断每条序列长度是否相同"
    if len(length_set) == 1:
        return True, length_set[0], length_set[-1], length_set_1[0], length_set_1[-1]
    else:
        return False, length_set[0], length_set[-1], length_set_1[0], length_set_1[-1]

def ENAC(file,params,output_file=''):
    """

    :param file:  文件名称
    :param sliding_window:  滑动窗口大小
    :param normolizi_input:  是否正则化
    :return:
    """
    try:
        fasta_list, sample_purpose, error_msg = preprocess_fasta(file)
        is_equal, minimum_length, maximum_length, minimum_length_without_minus, maximum_length_without_minus = sequence_with_equal_length(
            file)
        normolizi_input=True
        normolize=normolizi_input
        if not is_equal:
            error_msg = 'ENAC descriptor need fasta sequence with equal length.'
            return False
        sliding_window=int(params['sliding_window'])
        window = sliding_window
        if minimum_length < window:
            error_msg = 'ENAC descriptor, all the sequence length should be larger than the sliding window'
            return False
        AA = 'ACGT'
        encodings = []
        header = ['SampleName','Label']
        for w in range(1, len(fasta_list[0][1]) - window + 2):
            for aa in AA:
                header.append('SW.' + str(w) + '.' + aa)

        for i in fasta_list:
            name, sequence, label = i[0], i[1], i[2]
            code = [ ]
            for j in range(len(sequence)):
                if j < len(sequence) and j + window <= len(sequence):
                    count = Counter(sequence[j:j + window]) #Counter返回一个字典 字典的键是出现的字母 值为字母出现的次数
                    if normolize==True:
                        for key in count:
                            count[key] = count[key] / len(sequence[j:j + window])
                    for aa in AA:
                        code.append(count[aa])
            code.append(int(label))
            encodings.append(code)

        ENAC_csv=encodings
        DataFrame=pd.DataFrame(ENAC_csv)
        if len(output_file)>0:
            DataFrame.to_csv(output_file,header=0,index=0)

        encoding_array = np.array([])
        encoding_array = np.array(encodings, dtype=str)
        vocab=['A','G','C','U']
        return  encodings,encoding_array,header,vocab


    except Exception as e:
        error_msg = str(e)
        return False


def sequence_with_equal_length(file):
    """

    :param file:
    :return:  判断
    """
    fasta_list, sample_purpose, error_msg = preprocess_fasta(file)
    length_set = set()
    length_set_1 = set()
    for item in fasta_list:
        length_set.add(len(item[1]))
        length_set_1.add(len(re.sub('-', '', item[1])))

    length_set = sorted(length_set)
    length_set_1 = sorted(length_set_1)
    "判断每条序列长度是否相同"
    if len(length_set) == 1:
        return True, length_set[0], length_set[-1], length_set_1[0], length_set_1[-1]
    else:
        return False, length_set[0], length_set[-1], length_set_1[0], length_set_1[-1]

def NCP(file,params,output_file=''):
    try:
        fasta_list, sample_purpose, error_msg = preprocess_fasta(file)
        is_equal, minimum_length, maximum_length, minimum_length_without_minus, maximum_length_without_minus = sequence_with_equal_length(
            file)
        if not is_equal:
            error_msg = 'NCP descriptor need fasta sequence with equal length.'
            return False
        chemical_property = {
            'A': [1],
            'C': [2],
            'G': [3],
            'T': [4],
            'U': [5],
            '-': [0],
        }
        AA = 'ACGT'
        encodings = []
        header = ['SampleName', 'Label']
        for i in range(1, len(fasta_list[0][1]) * 3 + 1):
            header.append('NCP.F' + str(i))
        # encodings.append(header)


        for i in fasta_list:
            name, sequence, label = i[0], i[1], i[2]
            code = []
            for aa in sequence:
                code = code + chemical_property.get(aa, [0, 0, 0])  #通过字典中的键获取字典的值
            code.append(label)
            encodings.append(code)

        #保存csv文件
        NCP_csv=encodings
        DataFrame=pd.DataFrame(NCP_csv)
        if len(output_file)>0:
            DataFrame.to_csv(output_file,header=0,index=0)


        encoding_array = np.array([])
        encoding_array = np.array(encodings, dtype=str)
        vocab=['A','G','C','U']
        return  encodings,encoding_array,header,vocab
    except Exception as e:
        error_msg = str(e)
        return False

def kmerArray(sequence, k):
    kmer = []
    for i in range(len(sequence) - k + 1):
        kmer.append(sequence[i:i + k])
    return kmer

def check_sequence_type(file):
    """

    :param file: FAST文件
    :return:  返回DNA,RNA,Protein
    """
    fasta_list, sample_purpose, error_msg = preprocess_fasta(file)
    tmp_fasta_list = []
    if len(fasta_list) < 100:
        tmp_fasta_list = fasta_list
    else:
        #随机选取100条序列 返回选取序列的索引值
        random_index = random.sample(range(0, len(fasta_list)), 100)
        for i in random_index:
            tmp_fasta_list.append(fasta_list[i])
    #[['AT1G22840.1_532', 'AGATGAGGCTTTTTTACTTTGCTATATTCTTTTGCCAAATAAAATCTCAAACTTTTTTTGTTTATCATCAATTACGTTCTTGGTGGGAATTTGGCTGTAAT', '1', 'training']]
    sequence = ''
    for item in tmp_fasta_list:
        sequence += item[1]  #取基因序列

    char_set = set(sequence) #返回序列中出现的字符
    if 5 < len(char_set) <= 21:
        for line in fasta_list:
            line[1] = re.sub('[^ACDEFGHIKLMNPQRSTVWY]', '-', line[1])
        return 'Protein'
    elif 0 < len(char_set) <= 5 and 'T' in char_set:
        return 'DNA'
    elif 0 < len(char_set) <= 5 and 'U' in char_set:
        for line in fasta_list:
            line[1] = re.sub('U', 'T', line[1])
        return 'RNA'
    else:
        return 'Unknown'


def Kmer(file,params,output_file=''):
    """

    :param file: 文件名
    :param kw: 滑动窗口数
    :param flag: 是否归一化
    :return:
    """
    try:
        sequence_type=check_sequence_type(file)
        fasta_list, sample_purpose, error_msg = preprocess_fasta(file)
        fastas = fasta_list
        kw=int(params['sliding_window'])
        k = int(kw)
        upto = False
        flag=True
        normalize = flag
        type = sequence_type

        encoding = []
        end_code=[]
        header = ['SampleName', 'Label']
        NA = 'ACGT'
        if type in ("DNA", 'RNA'):
            NA = 'ACGT'
        else:
            NA = 'ACDEFGHIKLMNPQRSTVWY'

        if upto == True:
            for tmpK in range(1, k + 1):
                for kmer in itertools.product(NA, repeat=tmpK):
                    header.append(''.join(kmer))
            encoding.append(header)
            for i in fastas:
                name, sequence, label = i[0], re.sub('-', '', i[1]), i[2]
                count = Counter()
                for tmpK in range(1, k + 1):
                    kmers = kmerArray(sequence, tmpK)
                    count.update(kmers)  #计数器
                    if normalize == True:
                        for key in count:
                            if len(key) == tmpK:
                                count[key] = count[key] / len(kmers)
                code = [name, label]
                for j in range(2, len(header)):
                    if header[j] in count:
                        code.append(count[header[j]])
                    else:
                        code.append(0)
                encoding.append(code)
        else:
            for kmer in itertools.product(NA, repeat=k):
                header.append(''.join(kmer))
            encoding.append(header)
            for i in fastas:
                name, sequence, label = i[0], re.sub('-', '', i[1]), i[2]
                kmers = kmerArray(sequence, k)
                count = Counter()
                count.update(kmers)
                if normalize == True:
                    for key in count:
                        count[key] = count[key] / len(kmers)
                code = []
                for j in range(2, len(header)):
                    if header[j] in count:
                        code.append(count[header[j]])
                    else:
                        code.append(0)
                # encoding.append(code)
                end_code.append(code)
        encoding_array = np.array([])
        encoding_array = np.array(end_code, dtype=str)
        return encoding_array,end_code,header
    except Exception as e:
        error_msg = str(e)
        return False