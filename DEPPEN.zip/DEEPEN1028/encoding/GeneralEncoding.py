
import  re
import  collections
import  os
# from util.commonUtil import getSeqData
import numpy as np
import time
from collections import Counter
import tqdm
import time
import pickle
import random
import itertools
import time
import pandas as pd
import torch
# from util.commonUtil import preprocess_fasta
def preprocess_fasta(data):
    """
    :param file:
    :return:
    """
    msg = ''
    records = data.split('>')[1:]
    fasta_sequences = []
    for fasta in records:
        array = fasta.split('\n')
        #preprocess
        header, sequence = array[0].split()[0], re.sub('[^ACDEFGHIKLMNPQRSTUVWY-]', '-', ''.join(array[1:]).upper())
        header_array = header.split('|')
        #gene name
        name = header_array[0]
        #label
        label = header_array[1] if len(header_array) >= 2 else '0'
        #training or testing
        label_train = header_array[2] if len(header_array) >= 3 else 'training'
        fasta_sequences.append([name, sequence, label, label_train])
    #judge 
    sample_purpose = np.array([item[3] == 'training' for item in fasta_sequences])
    return fasta_sequences, sample_purpose, msg
def getSeqData(data):
    # fasta_sequences, sample_purpose, msg=preprocess_fasta(data)
    seqData=[]
    for i in range(len(data)):
        seqData.append(data[i][1])
    return seqData
def read_fasta(file):
    """
    read fasta sequence 读取fasta文件
    :param file:
    :return:
    """
    msg = ''
    if not os.path.exists(file):
        msg = 'Error: file %s does not exist.' % file
        return [], None, msg
    with open(file) as f:
        records = f.read()
    records = records.split('>')[1:]
    fasta_sequences = []
    for fasta in records:
        array = fasta.split('\n')
        #序列初次处理
        header, sequence = array[0].split()[0], re.sub('[^ACDEFGHIKLMNPQRSTUVWY-]', '-', ''.join(array[1:]).upper())
        header_array = header.split('|')
        #基因名称
        name = header_array[0]
        #标签
        label = header_array[1] if len(header_array) >= 2 else '0'
        #训练集or测试集
        label_train = header_array[2] if len(header_array) >= 3 else 'training'
        fasta_sequences.append([name, sequence, label, label_train])
    #判断是否每一条都是训练集
    sample_purpose = np.array([item[3] == 'training' for item in fasta_sequences])
    return fasta_sequences, sample_purpose, msg

'''
============================================================
    K-mer
============================================================
'''
def kmerArray(sequence, k):
    kmer = []
    for i in range(len(sequence) - k + 1):
        kmer.append(sequence[i:i + k])
    return kmer

def check_sequence_type(file):
    """

    :param file: FAST文件
    :return:  返回DNA,RNA,Protein
    """
    fasta_list, sample_purpose, error_msg = preprocess_fasta(file)
    tmp_fasta_list = []
    if len(fasta_list) < 100:
        tmp_fasta_list = fasta_list
    else:
        #随机选取100条序列 返回选取序列的索引值
        random_index = random.sample(range(0, len(fasta_list)), 100)
        for i in random_index:
            tmp_fasta_list.append(fasta_list[i])
    #[['AT1G22840.1_532', 'AGATGAGGCTTTTTTACTTTGCTATATTCTTTTGCCAAATAAAATCTCAAACTTTTTTTGTTTATCATCAATTACGTTCTTGGTGGGAATTTGGCTGTAAT', '1', 'training']]
    sequence = ''
    for item in tmp_fasta_list:
        sequence += item[1]  #取基因序列

    char_set = set(sequence) #返回序列中出现的字符
    if 5 < len(char_set) <= 21:
        for line in fasta_list:
            line[1] = re.sub('[^ACDEFGHIKLMNPQRSTVWY]', '-', line[1])
        return 'Protein'
    elif 0 < len(char_set) <= 5 and 'T' in char_set:
        return 'DNA'
    elif 0 < len(char_set) <= 5 and 'U' in char_set:
        for line in fasta_list:
            line[1] = re.sub('U', 'T', line[1])
        return 'RNA'
    else:
        return 'Unknown'

def Kmer(file,params,output_file=''):
    """

    :param file: 文件名
    :param kw: 滑动窗口数
    :param flag: 是否归一化
    :return:
    """
    try:
        sequence_type=check_sequence_type(file)
        fasta_list, sample_purpose, error_msg = preprocess_fasta(file)
        fastas = fasta_list
        kw=int(params['sliding_window'])
        k = int(kw)
        upto = False
        flag=True
        normalize = flag
        type = sequence_type

        encoding = []
        end_code=[]
        header = ['SampleName', 'label']
        NA = 'ACGT'
        if type in ("DNA", 'RNA'):
            NA = 'ACGT'
        else:
            NA = 'ACDEFGHIKLMNPQRSTVWY'

        if upto == True:
            for tmpK in range(1, k + 1):
                for kmer in itertools.product(NA, repeat=tmpK):
                    header.append(''.join(kmer))
            encoding.append(header)
            for i in fastas:
                name, sequence, label = i[0], re.sub('-', '', i[1]), i[2]
                count = Counter()
                for tmpK in range(1, k + 1):
                    kmers = kmerArray(sequence, tmpK)
                    count.update(kmers)  #计数器
                    if normalize == True:
                        for key in count:
                            if len(key) == tmpK:
                                count[key] = count[key] / len(kmers)
                code = [name, label]
                for j in range(2, len(header)):
                    if header[j] in count:
                        code.append(count[header[j]])
                    else:
                        code.append(0)
                encoding.append(code)
        else:
            for kmer in itertools.product(NA, repeat=k):
                header.append(''.join(kmer))
            encoding.append(header)
            for i in fastas:
                name, sequence, label = i[0], re.sub('-', '', i[1]), i[2]
                kmers = kmerArray(sequence, k)
                count = Counter()
                count.update(kmers)
                if normalize == True:
                    for key in count:
                        count[key] = count[key] / len(kmers)
                code = []
                for j in range(2, len(header)):
                    if header[j] in count:
                        code.append(count[header[j]])
                    else:
                        code.append(0)
                # encoding.append(code)
                code.append(int(label))
                end_code.append(code)
        encoding_array = np.array([])
        encoding_array = np.array(end_code, dtype=str)
        return end_code,encoding_array,header,dict(zip(header[2:],range(len(header[2:]))))
    except Exception as e:
        error_msg = str(e)
        return False
def pad_code(ngram_encode):
        ngram_encode2 = np.zeros([len(ngram_encode),len(max(ngram_encode,key = lambda x: len(x)))]) # 生成样本数*最长序列长度
        for i,j in enumerate(ngram_encode):
            ngram_encode2[i][0:len(j)] = j
        return ngram_encode2
'''
============================================================
    Tokenizer_WindowsSplit
============================================================
'''
class Tokenizer_WindowsSplit():
    def __init__(self, CODE_SETS, WINDOWS_SIZE,stride=1):
        self.windows_size = WINDOWS_SIZE
        self.code_sets = CODE_SETS
        self.rna_dict,self.dict_size = self.get_rna_dict()
        self.stride = stride
    def __get_all_word(self, windows_size):
        '''获取所有长度为windows_size的可重复组合'''
        from functools import reduce
        a, b = self.code_sets, windows_size  
        res = reduce(lambda x, y:[z0 + z1 for z0 in x for z1 in y], [a] * b)
        return res    
    
    def get_rna_dict(self):
        '''构建字典'''
        rna_dict = {'<PAD>':0,'<CLS>':1}
        num = len(rna_dict)
        for j in range(self.windows_size,0,-1):
            for word in self.__get_all_word(j):
                rna_dict[word] = num
                num += 1
        return rna_dict,len(rna_dict)
    @staticmethod
    def pad_code(ngram_encode):
        ngram_encode2 = np.zeros([len(ngram_encode),len(max(ngram_encode,key = lambda x: len(x)))]) # 生成样本数*最长序列长度
        for i,j in enumerate(ngram_encode):
            ngram_encode2[i][0:len(j)] = j
        return ngram_encode2
    def encode(self,rna_seq,padding=True,return_pt=True,concer_tail=False):
        
        mRNA_dic,_ = self.get_rna_dict()
#         print(mRNA_dic)
        n_gram = [] # 存储基因词
        n_gram_encode = [] # 存储基因词的encode
        n_gram_len = [] # 存储基因链长度
        len_rna_seq = len(rna_seq)
        for i in range(len_rna_seq):
            cur_rna_seq = []
            cur_rna_encode = []
            if "U" in rna_seq[i]:
                rna_seq[i] = rna_seq[i].replace("U","C")
            for j in range(0,len(rna_seq[i]),self.stride):
#                 print(self.windows_size)
                len_win = len(rna_seq[i][j:j+self.windows_size])
#                 print(len_win)
                if not concer_tail:
                    if  len_win == self.windows_size:
                        try:
                            cur_rna_seq.append(rna_seq[i][j:j+self.windows_size].upper())
                            cur_rna_encode.append(mRNA_dic[rna_seq[i][j:j+self.windows_size].upper()])
                        except Exception as e:
                            print(e)
                            # print(rna_seq[i],i)
                else:
                        cur_rna_seq.append(rna_seq[i][j:j+self.windows_size].upper())
                        cur_rna_encode.append(mRNA_dic[rna_seq[i][j:j+self.windows_size].upper()])
            n_gram.append(cur_rna_seq)
            n_gram_encode.append(cur_rna_encode)
            n_gram_len.append(len(cur_rna_encode))
        if padding:
            n_gram_encode = Tokenizer_WindowsSplit.pad_code(n_gram_encode)
        if return_pt:
            n_gram_encode = torch.LongTensor(n_gram_encode)  
        return n_gram, n_gram_encode, torch.LongTensor(n_gram_len), mRNA_dic

def WindowsSplit(data,params,output_file=''):
    data=preprocess_fasta(data)
    type=params['Type']
    window=int(params['sliding_window'])
    stride=int(params['Stride'])
    charset=""
    if type=='Protein':
        charset="ARNDCQEGHILKMFPSTWYV"
    elif type=='DNA':
        charset="ACTG"
    elif type=='RNA':
        charset="ACGU"
    tokenizer = Tokenizer_WindowsSplit([i for i in charset],window,stride=stride)
    header=['SampleName','Label']
    end_code=[]
    data=data[0]
    tokenizer_dict={}
    padding_array=[]
    for i in range(len(data)):
        curdata=[]
        curdata.append(data[i][1])
        re=tokenizer.encode(curdata)
        encoding_seg=re[0][0]
        encoding_value=re[1].data[0].numpy().tolist()
        if len(tokenizer_dict)==0:
            tokenizer_dict=re[3]
        padding_array.append(encoding_value)
        # end_code.append(dict(zip(encoding_seg,encoding_value)))
        end_code.append(tuple(zip(encoding_seg,encoding_value)))
    
    # encoding_array = np.array([])
    # encoding_array = np.array([i for i in end_code])
    padding_array=tokenizer.pad_code(padding_array)
    return padding_array,end_code,header,tokenizer_dict#list(tokenizer.rna_dict.keys())
    # return end_code,encoding_array,header

'''
============================================================
    Tokenize_BPE
============================================================
'''
# class Tokenize_BPE:
#     def __init__(self,file_name,merge_epochs,text=''):
#         self.file_name = file_name
#         self.vocab = {}
#         self.merge_epochs = merge_epochs
#         self.merge_dict = {}
#         self.text=text
        
#     def get_stats(self,vocab):
#         pairs = collections.defaultdict(int)
#         for word, freq in vocab.items():
#             symbols = word.split()
#             for i in range(len(symbols)-1):
#                 pairs[symbols[i],symbols[i+1]] += freq
#         return pairs

#     def merge_vocab(self,pair, v_in):
#         v_out = {}
#         bigram = re.escape(' '.join(pair))
#         p = re.compile(r'(?<!\S)' + bigram + r'(?!\S)')
#         for word in v_in:
#             w_out = p.sub(''.join(pair), word)
#             v_out[w_out] = v_in[word]
#         return v_out
#     def get_vocab_fromtext(self):
#         self.vocab = collections.Counter(list(map(lambda x:" ".join([i if i != "\n" else "</w>" for i in x]),self.text[1::2])))
#         return self.vocab

#     def get_vocab_fromfile(self):
#         with open(self.file_name) as f:
#             all_seqs = f.readlines()
#         self.vocab = collections.Counter(list(map(lambda x:" ".join([i if i != "\n" else "</w>" for i in x]),all_seqs[1::2])))
#         return self.vocab
    
#     def get_merge_list(self):
#         if not self.vocab:
#             self.vocab = self.get_vocab_fromtext()
#             # self.vocab = self.get_vocab_fromfile()
#         for i in range(self.merge_epochs):
#             pairs = self.get_stats(self.vocab)
#             if not pairs:
#                 break
#             best = max(pairs, key=pairs.get)
#             self.vocab = self.merge_vocab(best, self.vocab)
#         key_freqs = collections.Counter(sum(map(lambda x:x.split(" "),self.vocab.keys()),[]))
#         # print(key_freqs.most_common())
#         merge_list = sorted(key_freqs.keys(),key=lambda x:len(x.replace('</w>',"")),reverse=True)
#         self.merge_dict = {'<PAD>':0,'<CLS>':1,'<UNK>':2}
#         for num,i in enumerate(merge_list):
#             self.merge_dict[i] = num+2
#         return merge_list,self.merge_dict
    
#     def encode(self,seq):
#         if not self.merge_dict:
#             _,self.merge_dict = self.get_merge_list()
#         merge_dict_r = {v:k for k,v in self.merge_dict.items()}
#         # print(seq)
#         for ngram in self.merge_dict:
#             if ngram in seq:
#                 seq = seq.replace(ngram," "+str(self.merge_dict[ngram])+" ")
#         seq_num = seq.split(" ")
#         while "" in seq_num:
#             seq_num.remove("")
# #         print(seq_num)
#         seq_num = list(map(lambda x:Tokenize_BPE.turn_to_num(x) ,seq_num))
#         seq_origin = " ".join(list(map(lambda x:merge_dict_r.get(x),seq_num)))
#         return seq_num,seq_origin
#     def encode_batch(self,seq_list):
#         return list(map(lambda x:self.encode(x)[0],seq_list)),list(map(lambda x:self.encode(x)[1],seq_list))
#     @staticmethod
#     def turn_to_num(x):
#         try:
#             x = int(x)
#         except Exception as e:
# #             print(x)
#             x = 2
#         return x
class Tokenize_BPE:
    def __init__(self,file_name,merge_epochs,text=''):
        self.file_name = file_name
        self.vocab = {}
        self.merge_epochs = merge_epochs
        self.merge_dict = {}
        self.text=text
        
    def get_stats(self,vocab):
        pairs = collections.defaultdict(int)
        for word, freq in vocab.items():
            symbols = word.split()
            for i in range(len(symbols)-1):
                pairs[symbols[i],symbols[i+1]] += freq
        return pairs

    def merge_vocab(self,pair, v_in):
        v_out = {}
        bigram = re.escape(' '.join(pair))
        p = re.compile(r'(?<!\S)' + bigram + r'(?!\S)')
        for word in v_in:
            w_out = p.sub(''.join(pair), word)
            v_out[w_out] = v_in[word]
        return v_out
    def get_vocab_fromtext(self):
        self.text=[i+'\n' for i in self.text.split('\n')[:-1]]
        self.vocab = collections.Counter(list(map(lambda x:" ".join([i if i != "\n" else "</w>" for i in x]),self.text[1::2])))
        return self.vocab
    def get_vocab_fromfile(self):
        with open(self.file_name) as f:
            all_seqs = f.readlines()
        self.vocab = collections.Counter(list(map(lambda x:" ".join([i if i != "\n" else "</w>" for i in x]),all_seqs[1::2])))
        return self.vocab
    
    def get_merge_list(self):
        if not self.vocab:
            self.vocab = self.get_vocab_fromtext()
        for i in range(self.merge_epochs):
            pairs = self.get_stats(self.vocab)
            if not pairs:
                break
            best = max(pairs, key=pairs.get)
            self.vocab = self.merge_vocab(best, self.vocab)
        key_freqs = collections.Counter(sum(map(lambda x:x.split(" "),self.vocab.keys()),[]))
        # print(key_freqs.most_common())
        merge_list = sorted(key_freqs.keys(),key=lambda x:len(x.replace('</w>',"")),reverse=True)
        self.merge_dict = {'<PAD>':0,'<CLS>':1,'<UNK>':2}
        for num,i in enumerate(merge_list):
            self.merge_dict[i] = num+2
        return merge_list,self.merge_dict
    
    def encode(self,seq):
        if not self.merge_dict:
            _,self.merge_dict = self.get_merge_list()
        merge_dict_r = {v:k for k,v in self.merge_dict.items()}
        for ngram in self.merge_dict:
            if ngram in seq:
                seq = seq.replace(ngram," "+str(self.merge_dict[ngram])+" ")
        seq_num = seq.split(" ")
        while "" in seq_num:
            seq_num.remove("")
#         print(seq_num)
        seq_num = list(map(lambda x:Tokenize_BPE.turn_to_num(x) ,seq_num))
        seq_origin = " ".join(list(map(lambda x:merge_dict_r.get(x),seq_num)))
        return seq_num,seq_origin
    def encode_batch(self,seq_list):
        return list(map(lambda x:self.encode(x)[0],seq_list)),list(map(lambda x:self.encode(x)[1],seq_list))
    @staticmethod
    def turn_to_num(x):
        try:
            x = int(x)
        except Exception as e:
#             print(x)
            x = 2
        return x
def BPE(data,params,output_file=''):
    tokenize = Tokenize_BPE('',80,data)
    data=preprocess_fasta(data)
    header=['SampleName','Label']
    end_code=[]
    data=data[0]
    padding_array=[]
    for i in range(len(data)):
        re=tokenize.encode(data[i][1]+'</w>')
        segs=re[1].split(' ')
        end_code.append(tuple(zip(segs[:-1],re[0][:-1])))
        padding_array.append(re[0][:-1])
            
    # encoding_array = np.array([])
    # encoding_array = np.array([i for i in end_code])
    padding_array=pad_code(padding_array)
    vocab_dict={k:v for k,v in tokenize.merge_dict.items()}# if '/w' not in k}
    return padding_array,end_code,header,vocab_dict

'''
============================================================
    SentencePiece
============================================================
'''
from tokenizers import ByteLevelBPETokenizer,SentencePieceBPETokenizer,BertWordPieceTokenizer
from tokenizers import Tokenizer
import pandas as pd
import pickle



def SentencePiece(data,params,output_file=''):
    vocab_size=int(params['vocab_size'])
    
    with open("temp.txt","w") as f:
        data=data.split('\n')
        seq_data=[]
        for i in range(len(data)):
            if i%2==1:
                f.write(data[i]+'\n')
                seq_data.append(data[i])    
        f.close()
    header=['SampleName','Label']
    tokenizer = SentencePieceBPETokenizer()
    tokenizer.train(["temp.txt"], 
                vocab_size=vocab_size,
                special_tokens=["[PAD]", "[UNK]", "[CLS]", "[SEP]", "[MASK]"])
    end_code=[]
    tokenizer_dict=tokenizer.get_vocab()
    padding_array=[]
    for seq in seq_data:
        re=tokenizer.encode(seq)
        code=[]
        encoding_segs=re.tokens
        encoding_values=re.ids
        # for i in range(len(encoding_segs)):
        #     encoding_seg=encoding_segs[i]
        #     encoding_value=encoding_values[i]
        #     if encoding_seg=='▁':
        #         continue
        #     code.append(dict(zip(encoding_seg,encoding_value)))
        # end_code.append(dict(zip(encoding_segs[1:],encoding_values[1:])))
        padding_array.append(encoding_values)
        end_code.append(tuple(zip(encoding_segs[1:],encoding_values[1:]))) 
    
    # encoding_array = np.array([])
    # encoding_array = np.array([i for i in end_code])
    padding_array=pad_code(padding_array)

    import os
    os.remove("temp.txt")
    return padding_array,end_code,header,tokenizer_dict#list(tokenizer.vocab.keys())
    # return end_code,encoding_array,header

'''
============================================================
    WordPiece
============================================================
'''
def WordPiece(data,params,output_file=''):
    import argparse
    import glob
    from tokenizers import BertWordPieceTokenizer

    vocab_size=int(params['vocab_size'])
    # min_frequency=int(params['min_frequency'])

    with open("temp.txt","w") as f:
        data=data.split('\n')
        seq_data=[]
        for i in range(len(data)):
            if i%2==1:
                f.write(data[i]+' ')
                seq_data.append(data[i])     
        f.close()

    tokenizer = BertWordPieceTokenizer(
        clean_text=True,
        handle_chinese_chars=True,
        strip_accents=True,
        lowercase=False
    )

    tokenizer.train(
        ["temp.txt"], 
        vocab_size=vocab_size,
        min_frequency=1,
        show_progress=True,
        special_tokens=["[PAD]", "[UNK]", "[CLS]", "[SEP]", "[MASK]"],
        limit_alphabet=1000,
        wordpieces_prefix="##",
    )
    header=['SampleName','Label']
    end_code=[]
    tokenizer_dict=tokenizer.get_vocab()
    padding_array=[]
    for seq in seq_data:
        lre=None
        rre=None
        ltokens=[]
        rtokens=[]

        lids=[]
        rids=[]

        mid=int(len(seq)/2)
        
        lstr=seq[0:mid]
        rstr=seq[mid:]
        if len(lstr)>0:
            re1=tokenizer.encode(lstr)
            ltokens=[x.replace('#','') for x in re1.tokens]
            lids=re1.ids
        if len(rstr)>0:
            re2=tokenizer.encode(rstr)
            rtokens=[x.replace('#','') for x in re2.tokens]
            rids=re2.ids

        all_tokens=ltokens+rtokens 
        all_ids=lids+rids
        
        # code=dict(zip(all_tokens,all_ids))  
        code=tuple(zip(all_tokens,all_ids))  
        padding_array.append(all_ids)
        end_code.append(code)
    
    # encoding_array = np.array([])
    # encoding_array = np.array([i for i in end_code])
    padding_array=pad_code(padding_array)
    import os
    os.remove("temp.txt")

    return padding_array,end_code,header,tokenizer_dict#list(tokenizer.vocab.keys())
    # return end_code,encoding_array,header

if __name__=='__main__':
    data=read_fasta(r'D:\序列软件\reference\SeqPredict\ex\DNA_sequences.txt')
    params={}
    params['Type']='DNA'
    params['sliding_window']=3
    params['Stride']=2
    params['vocab_size']=200
    params['min_frequency']=1
    data=data[0]
    

    '''
        SentencePiece
    '''
    file=r'D:\序列软件\reference\SeqPredict\ex\DNA_sequences.txt'
    with open(file) as f:
        records = f.read()
    # SentencePiece(records,params,'')
    WordPiece(records,params,output_file='')
    
    '''
    BPE
    '''
    # # 在UI中调用
    # file=r'D:\序列软件\reference\SeqPredict\ex\DNA_sequences.txt'
    # with open(file) as f:
    #     records = f.read()
    # # WindowsSplit(data,params)
    # BPE(records,params)

    # #普通调用
    # tokenize = Tokenize_BPE(r'D:\序列软件\reference\SeqPredict\ex\DNA_sequences.txt',80,data)
    # tokenize.encode('AGATGAGGCTTTTTTACTTTGCTATATTCTTTTGCCAAATAAAATCTCAAACTTTTTTTGTTTATCATCAATTACGTTCTTGGTGGGAATTTGGCTGTAAT</w>')
    