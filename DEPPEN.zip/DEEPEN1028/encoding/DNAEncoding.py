import  re
import  os
import numpy as np
import time
from collections import Counter
import tqdm
import time
import pickle
import random
import itertools
import time
import pandas as pd
from util.commonUtil import preprocess_fasta

# def read_fasta(file):
#     """
#     read fasta sequence 读取fasta文件
#     :param file:
#     :return:
#     """
#     msg = ''
#     if not os.path.exists(file):
#         msg = 'Error: file %s does not exist.' % file
#         return [], None, msg
#     with open(file) as f:
#         records = f.read()
#     records = records.split('>')[1:]
#     fasta_sequences = []
#     for fasta in records:
#         array = fasta.split('\n')
#         #序列初次处理
#         header, sequence = array[0].split()[0], re.sub('[^ACDEFGHIKLMNPQRSTUVWY-]', '-', ''.join(array[1:]).upper())
#         header_array = header.split('|')
#         #基因名称
#         name = header_array[0]
#         #标签
#         label = header_array[1] if len(header_array) >= 2 else '0'
#         #训练集or测试集
#         label_train = header_array[2] if len(header_array) >= 3 else 'training'
#         fasta_sequences.append([name, sequence, label, label_train])
#     #判断是否每一条都是训练集
#     sample_purpose = np.array([item[3] == 'training' for item in fasta_sequences])
#     return fasta_sequences, sample_purpose, msg

def kmerArray(sequence, k):
    kmer = []
    for i in range(len(sequence) - k + 1):
        kmer.append(sequence[i:i + k])
    return kmer

def mismatch_count(seq1, seq2):
    mismatch = 0
    for i in range(min([len(seq1), len(seq2)])):
        if seq1[i] != seq2[i]:
            # print(seq1[i],seq2[i])
            mismatch += 1
    return mismatch


def Mismatch(file,params,output_file=''):
    """

    :param file: 读取的基因列表
    :param kmer: kmer的个数
    :param mismatch: mismatch的个数
    :param output_file: 保存csv的文件路径
    :return:
    """
    try:
        fasta_list, sample_purpose, error_msg = preprocess_fasta(file)
        kmer=int(params['sliding_window'])
        mismatch=int(params['Mismatch'])
        k = kmer
        m = mismatch
        NN = 'ACGT'

        encoding = []
        header = ['SampleName', 'Label']
        template_dict = {}
        for kmer in itertools.product(NN, repeat=k):
            header.append(''.join(kmer))
            template_dict[''.join(kmer)] = 0
        # encoding.append(header)


        end_code=[]
        for elem in fasta_list:
            name, sequence, label = elem[0], re.sub('-', '', elem[1]), elem[2]
            kmers = kmerArray(sequence, k) #获取sequence中kmer组合的名称
            tmp_dict = template_dict.copy() #将‘ACGT’的kmer 组合放入字典中


            """
             对比kmers与tmp_dict中的kmer组合,通过mismatch来匹配 如果匹配的字符中不相同数少于mismatch则默认两个Kmer一致
            """
            for kmer in kmers:
                for key in tmp_dict:
                    if mismatch_count(kmer, key) <= m:
                        tmp_dict[key] += 1
            code = [tmp_dict[key] for key in sorted(tmp_dict.keys())]
            code.append(int(label))
            encoding.append(code)
        DataFram=pd.DataFrame(encoding)
        if len(output_file)>0:
            DataFram.to_csv(output_file,header=0,index=0)






        encoding_array = np.array([])
        encoding_array = np.array(encoding, dtype=str)
        vocab=['A','G','C','T']
        return  encoding,encoding_array,header,vocab
    except Exception as e:
        error_msg = str(e)
        return False






def NAC(file,params=None,output_file=''):
    try:
        fasta_list, sample_purpose, error_msg = preprocess_fasta(file)
        NA = 'ACGT'
        encodings = []
        header = ['SampleName', 'Label']
        for i in NA:
            header.append(i)

        for i in fasta_list:
            name, sequence, label = i[0], re.sub('-', '', i[1]), i[2]
            count = Counter(sequence)
            for key in count:
                count[key] = count[key] / len(sequence)
            code = []
            for na in NA:
                code.append(count[na])
            code.append(int(label))
            encodings.append(code)
        #保存csv文件
        encodings_csv=encodings
        DataFrame=pd.DataFrame(encodings_csv)
        if len(output_file)>0:
            DataFrame.to_csv(output_file,header=0,index=0)

        encoding_array = np.array([])
        encoding_array = np.array(encodings, dtype=str)
        vocab=['A','G','C','T']
        return  encodings,encoding_array,header,vocab
    except Exception as e:
        error_msg = str(e)
        return False


def generateRCKmer(kmerList):
    """

    :param kmerList: 生成ACGT kmer的组合结果
    :return: DNA进行翻译，翻译后与翻译前按照首字母顺序排序，选取第一个出现的
    """
    rckmerList = set()
    myDict = {
        'A': 'T',
        'C': 'G',
        'G': 'C',
        'T': 'A'
    }
    # print('ACGT组合',kmerList)
    for kmer in kmerList:
        rckmerList.add(sorted([kmer, ''.join([myDict[nc] for nc in kmer[::-1]])])[0]) #DNA进行翻译，翻译后与翻译前按照首字母顺序排序，选取第一个出现的，并且没有重复值出现
    return sorted(rckmerList)

def RC(kmer):
    """

    :param kmer:  generateRCkmer生成的序列
    :return:  对序列进行翻译
    """

    # print(kmer)
    myDict = {
        'A': 'T',
        'C': 'G',
        'G': 'C',
        'T': 'A'
    }
    return ''.join([myDict[nc] for nc in kmer[::-1]])

def kmerArray(sequence, k):
    kmer = []
    for i in range(len(sequence) - k + 1):
        kmer.append(sequence[i:i + k])
    return kmer


def RCKmer(file,params,output_file=''):
    try:
        fasta_list, sample_purpose, error_msg = preprocess_fasta(file)
        fastas = fasta_list
        kmer=int(params['sliding_window'])
        k =kmer
        upto = False
        flag=True
        normalize = flag

        encoding = []
        header = ['SampleName', 'Label']
        NA = 'ACGT'

        if upto == True:
            for tmpK in range(1, k + 1):
                tmpHeader = []
                for kmer in itertools.product(NA, repeat=tmpK):
                    tmpHeader.append(''.join(kmer))
                header = header + generateRCKmer(tmpHeader)
            myDict = {}
            for kmer in header[2:]:
                rckmer = RC(kmer)
                if kmer != rckmer:
                    myDict[rckmer] = kmer
            encoding.append(header)
            for i in fastas:
                name, sequence, label = i[0], re.sub('-', '', i[1]), i[2]
                count = Counter()
                for tmpK in range(1, k + 1):
                    kmers = kmerArray(sequence, tmpK)
                    for j in range(len(kmers)):
                        if kmers[j] in myDict:
                            kmers[j] = myDict[kmers[j]]
                    count.update(kmers)
                    if normalize == True:
                        for key in count:
                            if len(key) == tmpK:
                                count[key] = count[key] / len(kmers)
                code = [name, label]
                for j in range(2, len(header)):
                    if header[j] in count:
                        code.append(count[header[j]])
                    else:
                        code.append(0)
                encoding.append(code)
        else:
            tmpHeader = []
            for kmer in itertools.product(NA, repeat=k):
                tmpHeader.append(''.join(kmer))  #生成ACGT kmer的组合结果
            header = header + generateRCKmer(tmpHeader)
            myDict = {}
            for kmer in header[2:]:
                rckmer = RC(kmer)
                if kmer != rckmer:
                    myDict[rckmer] = kmer #找到翻译与原始不同的碱基 {翻译：原始}
            #mydict 中健为翻译后的 值为原始的
            for i in fastas:
                name, sequence, label = i[0], re.sub('-', '', i[1]), i[2]
                kmers = kmerArray(sequence, k)  #按照Kmer分割 的序列
                for j in range(len(kmers)):
                    if kmers[j] in myDict:
                        kmers[j] = myDict[kmers[j]]  #如果数据序列按kmer切割的序列 存在于 MyDict中 将翻译的变成原始的
                count = Counter()
                count.update(kmers) #统计kmer出现的次数
                if normalize == True:
                    for key in count:
                        count[key] = count[key] / len(kmers)
                code = []
                for j in range(2, len(header)):
                    if header[j] in count:
                        code.append(count[header[j]])
                    else:
                        code.append(0)
                code.append(int(label))
                encoding.append(code)
        Dataset=pd.DataFrame(encoding)
        if len(output_file)>0:
            Dataset.to_csv(output_file, header=0, index=0)



        encoding_array = np.array([])
        encoding_array = np.array(encoding, dtype=str)

        vocab=['A','G','C','T']
        return  encoding,encoding_array,header,vocab
    except Exception as e:
        error_msg = str(e)
        return False



def GetKmerDict(piRNAletter, k):
    """

    :param piRNAletter:  ['A','C','G','T']
    :param k:  kmer
    :return:  返回kmer组合生成后的序列 再全排列的结果，字典形式返回，键为全排列后的序列的名称，值为索引值
    """
    kmerlst = []
    partkmers = list(itertools.combinations_with_replacement(piRNAletter, k)) #列表中放元组，每个元组是ACGT中Kmer的组合形式[('A', 'A'), ('A', 'C'),。。('G', 'T'), ('T', 'T')]
    for element in partkmers:
        elelst = set(itertools.permutations(element, k)) #返回Kmer组合形式 再全排列的结果,字典形式
        strlst = [''.join(ele) for ele in elelst]#转换成列表形式
        kmerlst += strlst
    kmerlst = np.sort(kmerlst) #按照字母顺序排序
    kmerdict = {kmerlst[i]: i for i in range(len(kmerlst))}
    print(kmerdict)
    return kmerdict

def GetSubsequenceProfileVector(sequence, kmerdict, k, delta):
    """

    :param sequence:  基因的序列
    :param kmerdict:  全排列的结果
    :param k:  k-mer
    :param delta:  delta
    :return:  返回 全排列中序列出现的次数
    """
    vector = np.zeros((1, len(kmerdict))) #生成一个二维数组 shape(1,len(kmerdict))
    sequence = np.array(list(sequence))
    n = len(sequence)
    index_lst = list(itertools.combinations(range(n), k)) #获取长度为k的 n的子序列[(0, 1), (0, 2), (0, 3), (0, 4), (0, 5)
    for subseq_index in index_lst:
        subseq_index = list(subseq_index)
        print(subseq_index)
        subsequence = sequence[subseq_index]  #获取基因序列长度为k的所有子序列
        print(subsequence)
        position = kmerdict.get(''.join(subsequence)) #get是字典的映射的值
        print('position',position)
        subseq_length = subseq_index[-1] - subseq_index[0] + 1  #选取的子序列 首位之间的距离
        print('subseq_length',subseq_length)
        subseq_score = 1 if subseq_length == k else delta ** subseq_length
        print('subseq_score',subseq_score)
        time.sleep(1)
        vector[0, position] += subseq_score
        print(vector)


    return list(vector[0])

def GetSubsequenceProfile(instances, piRNAletter, k, delta):
    kmerdict =GetKmerDict(piRNAletter, k)
    X = []
    for sequence in instances:
        vector = GetSubsequenceProfileVector(sequence, kmerdict, k, delta)
        X.append(vector)
    X_numpy = np.array(X)
    return X,X_numpy

def Subsequence(file,params,output_file=''):
    try:
        kmer=int(params['sliding_window'])
        delta=int(params['Delta'])
        k = kmer
        delta = delta
        fasta_list, sample_purpose, error_msg = preprocess_fasta(file)
        NN_list = ['A', 'C', 'G', 'T']

        encoding = []
        header = ['SampleName', 'Label']
        #生成kmer的组合结果
        for kmer in itertools.product(NN_list, repeat=k):
            header.append(''.join(kmer))
        encoding.append(header)

        instances = [elem[1] for elem in fasta_list]  #获取FAST文件中的基因序列


        X,X_numpy = GetSubsequenceProfile(instances, NN_list, k, delta)
        # return X,X_numpy,header
        vocab=['A','G','C','T']
        return  X,X_numpy,header,vocab
    except Exception as e:
        error_msg = str(e)
        return False


def kmerArray(sequence, k):
    kmer = []
    for i in range(len(sequence) - k + 1):
        kmer.append(sequence[i:i + k])
    return kmer




# def check_sequence_type(file):
#     """

#     :param file: FAST文件
#     :return:  返回DNA,RNA,Protein
#     """
#     fasta_list, sample_purpose, error_msg = preprocess_fasta(file)
#     tmp_fasta_list = []
#     if len(fasta_list) < 100:
#         tmp_fasta_list = fasta_list
#     else:
#         #随机选取100条序列 返回选取序列的索引值
#         random_index = random.sample(range(0, len(fasta_list)), 100)
#         for i in random_index:
#             tmp_fasta_list.append(fasta_list[i])
#     #[['AT1G22840.1_532', 'AGATGAGGCTTTTTTACTTTGCTATATTCTTTTGCCAAATAAAATCTCAAACTTTTTTTGTTTATCATCAATTACGTTCTTGGTGGGAATTTGGCTGTAAT', '1', 'training']]
#     sequence = ''
#     for item in tmp_fasta_list:
#         sequence += item[1]  #取基因序列

#     char_set = set(sequence) #返回序列中出现的字符
#     if 5 < len(char_set) <= 21:
#         for line in fasta_list:
#             line[1] = re.sub('[^ACDEFGHIKLMNPQRSTVWY]', '-', line[1])
#         return 'Protein'
#     elif 0 < len(char_set) <= 5 and 'T' in char_set:
#         return 'DNA'
#     elif 0 < len(char_set) <= 5 and 'U' in char_set:
#         for line in fasta_list:
#             line[1] = re.sub('U', 'T', line[1])
#         return 'RNA'
#     else:
#         return 'Unknown'


# def Kmer(file,params,output_file=''):
#     """

#     :param file: 文件名
#     :param kw: 滑动窗口数
#     :param flag: 是否归一化
#     :return:
#     """
#     try:
#         sequence_type=check_sequence_type(file)
#         fasta_list, sample_purpose, error_msg = preprocess_fasta(file)
#         fastas = fasta_list
#         kw=int(params['sliding_window'])
#         k = int(kw)
#         upto = False
#         flag=True
#         normalize = flag
#         type = sequence_type

#         encoding = []
#         end_code=[]
#         header = ['SampleName', 'Label']
#         NA = 'ACGT'
#         if type in ("DNA", 'RNA'):
#             NA = 'ACGT'
#         else:
#             NA = 'ACDEFGHIKLMNPQRSTVWY'

#         if upto == True:
#             for tmpK in range(1, k + 1):
#                 for kmer in itertools.product(NA, repeat=tmpK):
#                     header.append(''.join(kmer))
#             encoding.append(header)
#             for i in fastas:
#                 name, sequence, label = i[0], re.sub('-', '', i[1]), i[2]
#                 count = Counter()
#                 for tmpK in range(1, k + 1):
#                     kmers = kmerArray(sequence, tmpK)
#                     count.update(kmers)  #计数器
#                     if normalize == True:
#                         for key in count:
#                             if len(key) == tmpK:
#                                 count[key] = count[key] / len(kmers)
#                 code = [name, label]
#                 for j in range(2, len(header)):
#                     if header[j] in count:
#                         code.append(count[header[j]])
#                     else:
#                         code.append(0)
#                 encoding.append(code)
#         else:
#             for kmer in itertools.product(NA, repeat=k):
#                 header.append(''.join(kmer))
#             encoding.append(header)
#             for i in fastas:
#                 name, sequence, label = i[0], re.sub('-', '', i[1]), i[2]
#                 kmers = kmerArray(sequence, k)
#                 count = Counter()
#                 count.update(kmers)
#                 if normalize == True:
#                     for key in count:
#                         count[key] = count[key] / len(kmers)
#                 code = []
#                 for j in range(2, len(header)):
#                     if header[j] in count:
#                         code.append(count[header[j]])
#                     else:
#                         code.append(0)
#                 # encoding.append(code)
#                 end_code.append(code)
#         encoding_array = np.array([])
#         encoding_array = np.array(end_code, dtype=str)
#         return encoding_array,end_code,header
#     except Exception as e:
#         error_msg = str(e)
#         return False


    

