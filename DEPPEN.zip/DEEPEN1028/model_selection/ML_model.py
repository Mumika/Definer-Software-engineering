from model_selection.DL_model import Metrics
import os

import  pandas as pd
import  numpy as np
from sklearn.model_selection import StratifiedKFold,KFold
from sklearn.model_selection import LeaveOneOut
from sklearn.model_selection import StratifiedShuffleSplit
from sklearn.model_selection import GridSearchCV 


from sklearn.tree import DecisionTreeClassifier
import time
from sklearn.ensemble import RandomForestClassifier, AdaBoostClassifier, BaggingClassifier
from sklearn.naive_bayes import GaussianNB as GaussianNBClassifier
from sklearn.neighbors import KNeighborsClassifier
import lightgbm as lgb
from sklearn.linear_model import LogisticRegression as LogisticRegressionClassifier
from sklearn import svm

import numpy as np
import pandas as pd
import math
from sklearn.metrics import roc_curve, auc, precision_recall_curve
THRESHOLD_VALUE=0.6


def load_data_from_df(sample_name,feature_name,df):
    if df is not None:
        dataframe = df.iloc[:, :-1]
        dataframe.index = sample_name#['Sample_%s' % i for i in range(dataframe.values.shape[0])]
        dataframe.columns = ['F_%s' % i for i in range(dataframe.values.shape[1])]#feature_name 之后再修改
        datalabel = np.array(df.iloc[:, -1]).astype(int)
        return dataframe,datalabel
    else:
        return None,None
        
def isDivisionLegal(folds,datalabels):
    for i, (train, valid) in enumerate(folds):
            label_num1=len(set(datalabels[train]))
            label_num2=len(set(datalabels[valid]))
            if label_num1==1:
                return False
    return True

def data_split(X,y,method,param,training_datalabel=None):
    res=None
    splitParam = int(param['method_value'])
    if method=='KFold':
        fold=splitParam
        kf=KFold(n_splits=fold)
        kf.get_n_splits(X,y)
        res=kf.split(X,y)
        if isDivisionLegal(res,training_datalabel)==False:
            res = StratifiedKFold(fold).split(X, y)

    elif method=='StratifiedKFold':
        fold=splitParam
        res = StratifiedKFold(fold).split(X, y)
    
    elif method=='LeaveOneOut':
        loo=LeaveOneOut()
        loo.get_n_splits(X,y)
        res=loo.split(X,y)

    elif method=='StratifiedShuffleSplit':
        train_ratio=float(param['train_ratio'])
        test_ratio=float(param['test_ratio'])
        test_size=test_ratio/(train_ratio+test_ratio)
        sss=StratifiedShuffleSplit(n_splits=splitParam,test_size=test_size,random_state=0)
        sss.get_n_splits(X,y)
        res=sss.split(X,y)
    return res

def calculateEvaluationMetrics(score,is_train=True):
        import numpy as np
        import torch
        if not score is None:
            dataMetrics={}
            fold = sorted(set(score['Fold']))
            data = score.values
            aucData=[]# aucData[fold] -> list aucData[fold][1] -> Dataframe (fpr,tpr)
            prcData = []
            for f in fold:
                metrics=Metrics()
                if is_train:
                    dataMetrics['Fold'+str(int(f))]=metrics
                    tmp_data = data[data[:, 0] == f]
                else:
                    dataMetrics['Test']=metrics
                    tmp_data = data
                
                metrics.refresh_metrics(torch.tensor(tmp_data[:, 1].astype(float)),torch.tensor(tmp_data[:,2:].tolist()))
                metrics.get_end_metrics()
                
                if is_train:
                    aucData.append(['Fold %d AUROC = %s' %(f, metrics.AUC), metrics.aucDot])
                    prcData.append(['Fold %d AUPRC = %s' %(f, metrics.PRC), metrics.prcDot])
                
            if is_train:
                meanMetrics=Metrics.getMeanMetrics(dataMetrics.values())
                dataMetrics['Mean']=meanMetrics
                # aucData.append(['Mean AUROC = %s' %(meanMetrics.AUC), meanMetrics.aucDot])
                # prcData.append(['Mean AUPRC = %s' %(meanMetrics.PRC), meanMetrics.prcDot])
            return dataMetrics,aucData,prcData
        return None

'''
============================================================
    AdaBoost
============================================================
'''

def AdaBoost(training_dataset,testing_dataset,training_sample_name,testing_sample_name,feature_name,division_method,division_param,methodParam):
    """

    :param train_name:  训练样本
    :param test_name:  测试样本
    :param fold:  交叉验证
    :return:
    """
    try:
        #修改的部分 
        fold=int(division_param['method_value'])

        training_dataframe,training_datalabel=load_data_from_df(training_sample_name,feature_name,training_dataset)
        testing_dataframe,testing_datalabel=load_data_from_df(testing_sample_name,feature_name,testing_dataset)

        categories = sorted(set(training_datalabel))
        X, y = training_dataframe.values, training_datalabel
        training_score = np.zeros((X.shape[0], len(categories) + 2))
        training_score[:, 1] = y# 这里本身就有问题
        model = []
        folds=data_split(X,y,division_method,division_param,training_datalabel)
        # folds=data_split(X,y,division_method,division_param,training_datalabel) #
        for i, (train, valid) in enumerate(folds):
            train_X, train_y = X[train], y[train]
            valid_X, valid_y = X[valid], y[valid]
            abc = AdaBoostClassifier(n_estimators=200, random_state=0).fit(train_X, train_y)
            model.append(abc)
            training_score[valid, 0] = i
            training_score[valid, 2:] = abc.predict_proba(valid_X)
        training_score = pd.DataFrame(training_score,
                                           columns=['Fold', 'Label'] + ['Score_%s' % i for i in categories])
        best_model = model
        testing_score=None#m


        
        # independent dataset
        if not testing_dataframe is None:
            indep = testing_dataframe.values
            testing_score = np.zeros((indep.shape[0], len(categories) + 2))
            testing_score[:, 1] = testing_datalabel
            for abc in best_model:
                testing_score[:, 2:] += abc.predict_proba(indep)
            testing_score[:, 2:] /= fold# 需要修改
            testing_score = pd.DataFrame(testing_score,
                                              columns=['Fold', 'Label'] + ['Score_%s' % i for i in categories])
            testing_score['Fold'] = 'NA'
        # calculate metrics
        message = ''
        trainingAndMean_metric_dict,aucData,prcData=calculateEvaluationMetrics(training_score)
        if testing_score is not None:
            testing_metric_dict,_,_=calculateEvaluationMetrics(testing_score,is_train=False)
            ts_table=Metrics.getMetricsTable(testing_metric_dict,is_train=False)
        else:
            testing_metric_dict=None
            ts_table=None
        trAndMean_table=Metrics.getMetricsTable(trainingAndMean_metric_dict)
        # ts_table=Metrics.getMetricsTable(testing_metric_dict,is_train=False)

        return trainingAndMean_metric_dict,testing_metric_dict,trAndMean_table,ts_table,aucData,prcData,training_score,testing_score,message

    except Exception as e:
        error_msg = str(e)
        return None,None,None,None,None,None,None,None,error_msg


'''
============================================================
    Bagging
============================================================
'''
def Bagging(training_dataset,testing_dataset,training_sample_name,testing_sample_name,feature_name,division_method,division_param,methodParam):
    """

    :param train_name:
    :param test_name:
    :param fold:
    :param n_estimator: 集合中的基本估计量
    :param cpu:  是否并行 默认为1 不并行
    :return:
    """
    try:
        fold = int(division_param['method_value'])
        n_estimators =int(methodParam['n_estimator']) 
        n_jobs = int(methodParam['n_jobs']) 
        training_dataframe,training_datalabel=load_data_from_df(training_sample_name,feature_name,training_dataset)
        testing_dataframe,testing_datalabel=load_data_from_df(testing_sample_name,feature_name,testing_dataset)

        categories = sorted(set(training_datalabel))
        X, y = training_dataframe.values, training_datalabel
        training_score = np.zeros((X.shape[0], len(categories) + 2))
        training_score[:, 1] = y
        model = []
        folds=data_split(X,y,division_method,division_param,training_datalabel)
        for i, (train, valid) in enumerate(folds):
            train_X, train_y = X[train], y[train]
            valid_X, valid_y = X[valid], y[valid]
            bgc = BaggingClassifier(n_estimators=n_estimators, n_jobs=n_jobs).fit(train_X, train_y)
            model.append(bgc)
            training_score[valid, 0] = i
            training_score[valid, 2:] = bgc.predict_proba(valid_X)
        training_score = pd.DataFrame(training_score,
                                           columns=['Fold', 'Label'] + ['Score_%s' % i for i in categories])
        best_model = model
        testing_score=None#m
        # independent dataset
        if not testing_dataframe is None:
            indep = testing_dataframe.values
            testing_score = np.zeros((indep.shape[0], len(categories) + 2))
            testing_score[:, 1] = testing_datalabel
            for bgc in best_model:
                testing_score[:, 2:] += bgc.predict_proba(indep)
            testing_score[:, 2:] /= fold
            testing_score = pd.DataFrame(testing_score,
                                              columns=['Fold', 'Label'] + ['Score_%s' % i for i in categories])
            testing_score['Fold'] = 'NA'
        message = ''
        trainingAndMean_metric_dict,aucData,prcData=calculateEvaluationMetrics(training_score)
        if testing_score is not None:
            testing_metric_dict,_,_=calculateEvaluationMetrics(testing_score,is_train=False)
            ts_table=Metrics.getMetricsTable(testing_metric_dict,is_train=False)
        else:
            ts_table=None
        trAndMean_table=Metrics.getMetricsTable(trainingAndMean_metric_dict)
        # ts_table=Metrics.getMetricsTable(testing_metric_dict,is_train=False)

        return trainingAndMean_metric_dict,testing_metric_dict,trAndMean_table,ts_table,aucData,prcData,training_score,testing_score,message

    except Exception as e:
        error_msg = str(e)
        return None,None,None,None,None,None,None,None,error_msg


'''
============================================================
    DecisionTree
============================================================
'''
def DecisionTree(training_dataset,testing_dataset,training_sample_name,testing_sample_name,feature_name,division_method,division_param,methodParam):
    """

    :param train_name:  训练样本
    :param test_name:  测试样本
    :param fold:  交叉验证
    :return:
    """
    try:
        algorithm = 'RF'

        fold = int(division_param['method_value'])
        training_dataframe,training_datalabel=load_data_from_df(training_sample_name,feature_name,training_dataset)
        if len(set(training_datalabel)) == 2:
            task = 'binary'
        if len(set(training_datalabel)) > 2:
            task = 'muti-task'
        
        testing_dataframe,testing_datalabel=load_data_from_df(testing_sample_name,feature_name,testing_dataset)

        categories = sorted(set(training_datalabel))
        X, y = training_dataframe.values, training_datalabel
        training_score = np.zeros((X.shape[0], len(categories) + 2))
        training_score[:, 1] = y
        model = []
        folds=data_split(X,y,division_method,division_param,training_datalabel)
        for i, (train, valid) in enumerate(folds):
            train_X, train_y = X[train], y[train]
            valid_X, valid_y = X[valid], y[valid]
            dtc = DecisionTreeClassifier().fit(train_X, train_y)
            model.append(dtc)
            training_score[valid, 0] = i
            training_score[valid, 2:] = dtc.predict_proba(valid_X)
        training_score = pd.DataFrame(training_score,
                                           columns=['Fold', 'Label'] + ['Score_%s' % i for i in categories])
        best_model = model
        testing_score=None#m
        # independent dataset
        if not testing_dataframe is None:
            indep = testing_dataframe.values
            testing_score = np.zeros((indep.shape[0], len(categories) + 2))
            testing_score[:, 1] = testing_datalabel
            for dtc in best_model:
                testing_score[:, 2:] += dtc.predict_proba(indep)
            testing_score[:, 2:] /= fold
            testing_score = pd.DataFrame(testing_score,
                                              columns=['Fold', 'Label'] + ['Score_%s' % i for i in categories])
            testing_score['Fold'] = 'NA'

        # calculate metrics
        message = ''
        trainingAndMean_metric_dict,aucData,prcData=calculateEvaluationMetrics(training_score)
        if testing_score is not None:
            testing_metric_dict,_,_=calculateEvaluationMetrics(testing_score,is_train=False)
            ts_table=Metrics.getMetricsTable(testing_metric_dict,is_train=False)
        else:
            testing_metric_dict=None
            ts_table=None
        trAndMean_table=Metrics.getMetricsTable(trainingAndMean_metric_dict)
        # ts_table=Metrics.getMetricsTable(testing_metric_dict,is_train=False)

        return trainingAndMean_metric_dict,testing_metric_dict,trAndMean_table,ts_table,aucData,prcData,training_score,testing_score,message

    except Exception as e:
        error_msg = str(e)
        return None,None,None,None,None,None,None,None,error_msg

'''
============================================================
    GaussianNB
============================================================
'''
def GaussianNB(training_dataset,testing_dataset,training_sample_name,testing_sample_name,feature_name,division_method,division_param,methodParam):
    """

    :param train_name:  训练样本
    :param test_name:  测试样本
    :param fold:  交叉验证
    :return:
    """
    try:


        fold=int(division_param['method_value'])
        training_dataframe,training_datalabel=load_data_from_df(training_sample_name,feature_name,training_dataset)
        testing_dataframe,testing_datalabel=load_data_from_df(testing_sample_name,feature_name,testing_dataset)

        categories = sorted(set(training_datalabel))
        X, y = training_dataframe.values, training_datalabel
        training_score = np.zeros((X.shape[0], len(categories) + 2))
        training_score[:, 1] = y
        model = []
        folds=data_split(X,y,division_method,division_param,training_datalabel)
        for i, (train, valid) in enumerate(folds):
            train_X, train_y = X[train], y[train]
            valid_X, valid_y = X[valid], y[valid]
            gsn = GaussianNBClassifier().fit(train_X, train_y)
            model.append(gsn)
            training_score[valid, 0] = i
            training_score[valid, 2:] = gsn.predict_proba(valid_X)
        training_score = pd.DataFrame(training_score,
                                           columns=['Fold', 'Label'] + ['Score_%s' % i for i in categories])
        best_model = model
        testing_score=None#m
        # independent dataset
        if not testing_dataframe is None:
            indep = testing_dataframe.values
            testing_score = np.zeros((indep.shape[0], len(categories) + 2))
            testing_score[:, 1] = testing_datalabel
            for gsn in best_model:
                testing_score[:, 2:] += gsn.predict_proba(indep)
            testing_score[:, 2:] /= fold
            testing_score = pd.DataFrame(testing_score,
                                              columns=['Fold', 'Label'] + ['Score_%s' % i for i in categories])
            testing_score['Fold'] = 'NA'
        # calculate metrics
        message = ''
        trainingAndMean_metric_dict,aucData,prcData=calculateEvaluationMetrics(training_score)
        if testing_score is not None:
            testing_metric_dict,_,_=calculateEvaluationMetrics(testing_score,is_train=False)
            ts_table=Metrics.getMetricsTable(testing_metric_dict,is_train=False)
        else:
            testing_metric_dict=None
            ts_table=None
        trAndMean_table=Metrics.getMetricsTable(trainingAndMean_metric_dict)
        # ts_table=Metrics.getMetricsTable(testing_metric_dict,is_train=False)

        return trainingAndMean_metric_dict,testing_metric_dict,trAndMean_table,ts_table,aucData,prcData,training_score,testing_score,message

    except Exception as e:
        error_msg = str(e)
        return None,None,None,None,None,None,None,None,error_msg

'''
============================================================
    KNeighbors
============================================================
'''
def KNeighbors(training_dataset,testing_dataset,training_sample_name,testing_sample_name,feature_name,division_method,division_param,methodParam):
    """

    :param train_name:  训练样本
    :param test_name:  测试样本
    :param fold:  交叉验证
    :return:
    """
    try:

        n_neighbors = int(methodParam['n_neighbors'])
        fold=int(division_param['method_value'])

        training_dataframe,training_datalabel=load_data_from_df(training_sample_name,feature_name,training_dataset)
        testing_dataframe,testing_datalabel=load_data_from_df(testing_sample_name,feature_name,testing_dataset)
        categories = sorted(set(training_datalabel))
        X, y = training_dataframe.values, training_datalabel
        training_score = np.zeros((X.shape[0], len(categories) + 2))
        training_score[:, 1] = y
        model = []
        folds=data_split(X,y,division_method,division_param,training_datalabel)
        for i, (train, valid) in enumerate(folds):
            train_X, train_y = X[train], y[train]
            valid_X, valid_y = X[valid], y[valid]
            knn_model = KNeighborsClassifier(n_neighbors=n_neighbors).fit(train_X, train_y)
            model.append(knn_model)
            training_score[valid, 0] = i
            training_score[valid, 2:] = knn_model.predict_proba(valid_X)
        training_score = pd.DataFrame(training_score,
                                           columns=['Fold', 'Label'] + ['Score_%s' % i for i in categories])
        best_model = model
        testing_score=None#m
        # independent dataset
        if not testing_dataframe is None:
            indep = testing_dataframe.values
            testing_score = np.zeros((indep.shape[0], len(categories) + 2))
            testing_score[:, 1] = testing_datalabel
            for lrc in best_model:
                testing_score[:, 2:] += lrc.predict_proba(indep)
            testing_score[:, 2:] /= fold
            testing_score = pd.DataFrame(testing_score,
                                              columns=['Fold', 'Label'] + ['Score_%s' % i for i in categories])
            testing_score['Fold'] = 'NA'
        # calculate metrics
        message = ''
        trainingAndMean_metric_dict,aucData,prcData=calculateEvaluationMetrics(training_score)
        if testing_score is not None:
            testing_metric_dict,_,_=calculateEvaluationMetrics(testing_score,is_train=False)
            ts_table=Metrics.getMetricsTable(testing_metric_dict,is_train=False)
        else:
            testing_metric_dict=None
            ts_table=None
        trAndMean_table=Metrics.getMetricsTable(trainingAndMean_metric_dict)
        # ts_table=Metrics.getMetricsTable(testing_metric_dict,is_train=False)

        return trainingAndMean_metric_dict,testing_metric_dict,trAndMean_table,ts_table,aucData,prcData,training_score,testing_score,message

    except Exception as e:
        error_msg = str(e)
        return None,None,None,None,None,None,None,None,error_msg

'''
============================================================
    LGBM 开始有问题
============================================================
'''
def LGBM(training_dataset,testing_dataset,training_sample_name,testing_sample_name,feature_name,division_method,division_param,methodParam):
    """

    :param train_name:  训练集
    :param test_name: 测试集
    :param fold:  交叉验证
    :param boosting_type:'gbdt','dart','goss','rf'
    :param num_leaves: 31(建议一下都是)
    :param max_depth: -1
    :param learning_rate: 0.1
    :param leaves_range:（from:to:step） (20, 100, 10)
    :param depth_range:(15, 55, 10)
    :param rate_range:(0.01, 0.15, 0.02)
    :param auto:默认True
    :param cpu:默认1
    :return:
    """
    try:
        fold=int(division_param['method_value'])
        
        boosting_type = methodParam['boosting_type']
        num_leaves = int(methodParam['num_leaves'])
        max_depth = int(methodParam['max_depth'])
        learning_rate = float(methodParam['learning_rate'])
        n_jobs = int(methodParam['n_jobs'])

        leaves_range = (20, 100, 10)
        depth_range = (15, 55, 10)
        rate_range = (0.01, 0.15, 0.02)
        auto = True


        training_dataframe,training_datalabel=load_data_from_df(training_sample_name,feature_name,training_dataset)
        testing_dataframe,testing_datalabel=load_data_from_df(testing_sample_name,feature_name,testing_dataset)

        parameters = {
            'num_leaves': list(range(leaves_range[0], leaves_range[1], leaves_range[2])),
            'max_depth': list(range(depth_range[0], depth_range[1], depth_range[2])),
            'learning_rate': list(np.arange(rate_range[0], rate_range[1], rate_range[2]))
        }
        if auto:
            gbm = lgb.LGBMClassifier(boosting_type=boosting_type)
            gsearch = GridSearchCV(gbm, param_grid=parameters, n_jobs=n_jobs).fit(training_dataframe.values,
                                                                                  training_datalabel)
            best_parameters = gsearch.best_params_
            num_leaves = best_parameters['num_leaves']
            max_depth = best_parameters['max_depth']
            learning_rate = best_parameters['learning_rate']


        categories = sorted(set(training_datalabel))
        X, y = training_dataframe.values, training_datalabel
        training_score = np.zeros((X.shape[0], len(categories) + 2))
        training_score[:, 1] = y
        model = []
        folds=data_split(X,y,division_method,division_param,training_datalabel)
        for i, (train, valid) in enumerate(folds):
            train_X, train_y = X[train], y[train]
            valid_X, valid_y = X[valid], y[valid]
            gbm_model = lgb.LGBMClassifier(boosting_type=boosting_type, num_leaves=num_leaves, max_depth=max_depth,
                                           learning_rate=learning_rate).fit(train_X, train_y)
            model.append(gbm_model)
            training_score[valid, 0] = i
            training_score[valid, 2:] = gbm_model.predict_proba(valid_X)
        training_score = pd.DataFrame(training_score,
                                           columns=['Fold', 'Label'] + ['Score_%s' % i for i in categories])
        best_model = model
        testing_score=None#m


        # independent dataset
        if not testing_dataframe is None:
            indep = testing_dataframe.values
            testing_score = np.zeros((indep.shape[0], len(categories) + 2))
            testing_score[:, 1] = testing_datalabel
            for gbm in best_model:
                testing_score[:, 2:] += gbm.predict_proba(indep)
            testing_score[:, 2:] /= fold
            testing_score = pd.DataFrame(testing_score,
                                              columns=['Fold', 'Label'] + ['Score_%s' % i for i in categories])
            testing_score['Fold'] = 'NA'
        # calculate metrics
        message = ''
        trainingAndMean_metric_dict,aucData,prcData=calculateEvaluationMetrics(training_score)
        if testing_score is not None:
            testing_metric_dict,_,_=calculateEvaluationMetrics(testing_score,is_train=False)
            ts_table=Metrics.getMetricsTable(testing_metric_dict,is_train=False)
        else:
            testing_metric_dict=None
            ts_table=None
        trAndMean_table=Metrics.getMetricsTable(trainingAndMean_metric_dict)
        # ts_table=Metrics.getMetricsTable(testing_metric_dict,is_train=False)

        return trainingAndMean_metric_dict,testing_metric_dict,trAndMean_table,ts_table,aucData,prcData,training_score,testing_score,message

    except Exception as e:
        error_msg = str(e)
        return None,None,None,None,None,None,None,None,error_msg
'''
============================================================
    LogisticRegression
============================================================
'''
def LogisticRegression(training_dataset,testing_dataset,training_sample_name,testing_sample_name,feature_name,division_method,division_param,methodParam):
    """

    :param train_name:  训练样本
    :param test_name:  测试样本
    :param fold:  交叉验证
    :return:
    """
    try:


        fold=int(division_param['method_value'])

        training_dataframe,training_datalabel=load_data_from_df(training_sample_name,feature_name,training_dataset)
        testing_dataframe,testing_datalabel=load_data_from_df(testing_sample_name,feature_name,testing_dataset)

        categories = sorted(set(training_datalabel))
        X, y = training_dataframe.values, training_datalabel
        training_score = np.zeros((X.shape[0], len(categories) + 2))
        training_score[:, 1] = y
        model = []
        folds=data_split(X,y,division_method,division_param,training_datalabel)
        for i, (train, valid) in enumerate(folds):
            train_X, train_y = X[train], y[train]
            valid_X, valid_y = X[valid], y[valid]
            lr_model = LogisticRegressionClassifier(C=1.0, random_state=0).fit(train_X, train_y)
            model.append(lr_model)
            training_score[valid, 0] = i
            training_score[valid, 2:] = lr_model.predict_proba(valid_X)
        training_score = pd.DataFrame(training_score,
                                           columns=['Fold', 'Label'] + ['Score_%s' % i for i in categories])
        best_model = model
        testing_score=None#m

        # independent dataset
        if not testing_dataframe is None:
            indep = testing_dataframe.values
            testing_score = np.zeros((indep.shape[0], len(categories) + 2))
            testing_score[:, 1] = testing_datalabel
            for lrc in best_model:
                testing_score[:, 2:] += lrc.predict_proba(indep)
            testing_score[:, 2:] /= fold
            testing_score = pd.DataFrame(testing_score,
                                              columns=['Fold', 'Label'] + ['Score_%s' % i for i in categories])
            testing_score['Fold'] = 'NA'
        # calculate metrics
        message = ''
        trainingAndMean_metric_dict,aucData,prcData=calculateEvaluationMetrics(training_score)
        if testing_score is not None:
            testing_metric_dict,_,_=calculateEvaluationMetrics(testing_score,is_train=False)
            ts_table=Metrics.getMetricsTable(testing_metric_dict,is_train=False)
        else:
            testing_metric_dict=None
            ts_table=None
        trAndMean_table=Metrics.getMetricsTable(trainingAndMean_metric_dict)
        # ts_table=Metrics.getMetricsTable(testing_metric_dict,is_train=False)

        return trainingAndMean_metric_dict,testing_metric_dict,trAndMean_table,ts_table,aucData,prcData,training_score,testing_score,message

    except Exception as e:
        error_msg = str(e)
        return None,None,None,None,None,None,None,None,error_msg
'''
============================================================
    RandomForest
============================================================
'''
class oMetrics(object):
    def __init__(self, scores, labels, pos_label=None, threshold=0.5):
        super(oMetrics, self).__init__()
        self.scores = scores
        label_sets = sorted(set(labels))
        if pos_label is None:
            self.pos_label = label_sets[-1]
        else:
            self.pos_label = pos_label
        self.labels = labels
        self.threshold = threshold
        # evaluation metrics
        self.sensitivity = 0
        self.specificity = 0
        self.accuracy = 0
        self.mcc = 0
        self.precision = 0
        self.f1 = 0
        self.auc = 0
        self.prc = 0
        self.aucDot = None
        self.prcDot = None

        if len(label_sets) == 2:
            self.calculateBinaryTaskMetrics()
        elif len(label_sets) > 2:
            self.calculateMultiTaskMetrics()
        else:
            pass

    def calculateBinaryTaskMetrics(self):
        tp, tn, fp, fn = 0, 0, 0, 0
        for i in range(len(self.scores)):
            if self.labels[i] == self.pos_label:
                if self.scores[i] >= self.threshold:
                    tp += 1
                else:
                    fn += 1
            else:
                if self.scores[i] < self.threshold:
                    tn += 1
                else:
                    fp += 1

        self.sensitivity = round(tp / (tp + fn) * 100, 2) if (tp + fn) != 0 else 0
        self.specificity = round(tn / (fp + tn) * 100, 2) if (fp + tn) != 0 else 0
        self.accuracy = round((tp + tn) / (tp + fn + tn + fp) * 100, 2)
        self.mcc = round((tp * tn - fp * fn) / math.sqrt((tp + fp) * (tp + fn) * (tn + fp) * (tn + fn)), 4) if (tp + fp) * (tp + fn) * (tn + fp) * (tn + fn) != 0 else 0
        self.precision = round(tp / (tp + fp) * 100, 2) if (tp + fp) != 0 else 0
        self.f1 = round(2 * tp / (2 * tp + fp + fn), 4) if (2 * tp + fp + fn) != 0 else 0
        # roc        
        fpr, tpr, _ = roc_curve(self.labels, self.scores, pos_label=self.pos_label)
        self.auc = round(auc(fpr, tpr), 4)
        self.aucDot = pd.DataFrame(np.hstack((fpr.reshape((-1, 1)), tpr.reshape((-1, 1)))), columns=['fpr', 'tpr'])
        # prc
        precision, recall, _ = precision_recall_curve(self.labels, self.scores, pos_label=self.pos_label)
        self.prc = round(auc(recall, precision), 4)
        self.prcDot = pd.DataFrame(np.hstack((recall.reshape((-1, 1)), precision.reshape((-1, 1)))),
                                   columns=['recall', 'precision'])

    def calculateMultiTaskMetrics(self):
        result = []
        for item in self.scores:
            result.append(max(enumerate(item), key=lambda x: x[1])[0])
        result = np.array(result)
        self.accuracy = round(len(result[result == self.labels]) / len(self.labels) * 100, 2)

    @staticmethod
    def getBinaryTaskMetrics(scores, labels, pos_label=None, threshold=0.5):
        evaluationMetrics = oMetrics(scores, labels, pos_label, threshold)
        return (evaluationMetrics.sensitivity, evaluationMetrics.specificity, evaluationMetrics.precision, evaluationMetrics.accuracy, evaluationMetrics.mcc,
                evaluationMetrics.f1, evaluationMetrics.auc, evaluationMetrics.prc), True

    @staticmethod
    def getMutiTaskMetrics(scores, labels):
        evaluationMetricss = oMetrics(scores, labels)
        return evaluationMetricss.accuracy, True
def RandomForest(training_dataset,testing_dataset,training_sample_name,testing_sample_name,feature_name,division_method,division_param,methodParam):
    """

    :param file: 读取文件
    :param auto: 是否自动选择
    :param fold: 交叉验证
    :param n_trees: 设置随机种子树
    :param cpu: 默认值为1
    :return:
    """
    try:
        fold=int(division_param['method_value'])

        n_trees = int(methodParam['n_trees'])
        n_jobs = int(methodParam['n_jobs'])
        
        
        auto = True
        
        
        #若为自动的话就默认
        if auto:
            tree_range = (100, 1000, 100)
        else:
            tree_range = (n_trees, n_trees + 1, 100)

        training_dataframe,training_datalabel=load_data_from_df(training_sample_name,feature_name,training_dataset)
        if len(set(training_datalabel)) == 2:
            task = 'binary'
        if len(set(training_datalabel)) > 2:
            task = 'muti-task'
        testing_dataframe,testing_datalabel=load_data_from_df(testing_sample_name,feature_name,testing_dataset)



        if not training_dataframe is None:
            categories = sorted(set(training_datalabel))
            X, y = training_dataframe.values, training_datalabel
            # best model selection
            best_n_trees = tree_range[0]
            best_auc = 0
            best_accuracy = 0
            best_model = []
            best_training_score = None
            for tree in range(tree_range[0], tree_range[1] + 1, tree_range[2]):
                training_score = np.zeros((X.shape[0], len(categories) + 2))
                training_score[:, 1] = y
                model = []
                folds=data_split(X,y,division_method,division_param,training_datalabel)
                for i, (train, valid) in enumerate(folds):
                    train_X, train_y = X[train], y[train]
                    valid_X, valid_y = X[valid], y[valid]
                    rfc_model = RandomForestClassifier(n_estimators=tree, bootstrap=False, n_jobs=n_jobs)
                    rfc = rfc_model.fit(train_X, train_y)
                    model.append(rfc)
                    training_score[valid, 0] = i
                    training_score[valid, 2:] = rfc.predict_proba(valid_X)  #用于判断 预测的是0还是1的概率 放到training的后两列

                if len(categories) == 2:
                    #敏感性 特异性 精确度 准确率 马修系数 f1评分 auc prc 平均
                    metrics, ok = oMetrics.getBinaryTaskMetrics(training_score[:, 3], training_score[:, 1],
                                                                   pos_label=categories[-1])
                    if metrics[6] > best_auc:
                        best_auc = metrics[6]
                        best_n_trees = tree
                        best_model = model
                        best_training_score = training_score
                if len(categories) > 2:
                    metrics = oMetrics.getMutiTaskMetrics(training_score[:, 2:], training_score[:, 1])
                    if metrics[0] > best_accuracy:
                        best_accuracy = metrics[0]
                        best_n_trees = tree
                        best_model = model
                        best_training_score = training_score

            training_score = pd.DataFrame(best_training_score,
                                                columns=['Fold', 'Label'] + ['Score_%s' % i for i in categories])
            best_model = best_model
            best_n_trees = best_n_trees
            testing_score=None


            testing_score=None

            # independent dataset
            if not testing_dataframe is None:
                indep = testing_dataframe.values
                testing_score = np.zeros((indep.shape[0], len(categories) + 2))
                testing_score[:, 1] = testing_datalabel
                for rfc in best_model:
                    testing_score[:, 2:] += rfc.predict_proba(indep)
                testing_score[:, 2:] /= fold
                testing_score = pd.DataFrame(testing_score,
                                                    columns=['Fold', 'Label'] + ['Score_%s' % i for i in categories])
                # 敏感性 特异性 精确度 准确率 马修系数 f1评分 auc prc 平均
                testing_score['Fold'] = 'NA'
            message = 'Best n_trees is %d' % best_n_trees
        # calculate metrics
        message = ''
        trainingAndMean_metric_dict,aucData,prcData=calculateEvaluationMetrics(training_score)
        if testing_score is not None:
            testing_metric_dict,_,_=calculateEvaluationMetrics(testing_score,is_train=False)
            ts_table=Metrics.getMetricsTable(testing_metric_dict,is_train=False)
        else:
            testing_metric_dict=None
            ts_table=None
        trAndMean_table=Metrics.getMetricsTable(trainingAndMean_metric_dict)
        # ts_table=Metrics.getMetricsTable(testing_metric_dict,is_train=False)

        return trainingAndMean_metric_dict,testing_metric_dict,trAndMean_table,ts_table,aucData,prcData,training_score,testing_score,message

    except Exception as e:
        error_msg = str(e)
        return None,None,None,None,None,None,None,None,error_msg
'''
============================================================
    SVM
============================================================
'''
def SVM(training_dataset,testing_dataset,training_sample_name,testing_sample_name,feature_name,division_method,division_param,methodParam):
    """

    :param train_name: 训练集
    :param test_name:  测试集
    :param fold:  交叉验证
    :param kernel: liner rbf poly sigmoid
    :param auto:
    :param penality:
    :param gamma:
    :param penalityRange:
    :param gammaRange:
    :return:
    """
    try:
        fold=int(division_param['method_value'])

        training_dataframe,training_datalabel=load_data_from_df(training_sample_name,feature_name,training_dataset)
        if len(set(training_datalabel)) == 2:
            task = 'binary'
        if len(set(training_datalabel)) > 2:
            task = 'muti-task'
        testing_dataframe,testing_datalabel=load_data_from_df(testing_sample_name,feature_name,testing_dataset)

        kernel = methodParam['kernel']
        penality = float(methodParam['penality'])

        auto = True
        gamma = 1 / training_dataframe.values.shape[1] #if gamma== 'auto' else gamma
        penalityRange = (1.0, 15.0)
        gammaRange = (-10,5.0)
        parameters = {'kernel': ['linear'], 'C': penalityRange} if kernel == 'linear' else {'kernel': [kernel],
                                                                                            'C': penalityRange,
                                                                                            'gamma': 2.0 ** np.arange(
                                                                                                gammaRange[0],
                                                                                                gammaRange[1])}

        if auto:
            optimizer = GridSearchCV(svm.SVC(probability=True), parameters).fit(training_dataframe.values,
                                                                                training_datalabel)
            params = optimizer.best_params_
            penality = params['C']
            if kernel != 'linear':
                gamma = params['gamma']
        categories = sorted(set(training_datalabel))
        X, y = training_dataframe.values, training_datalabel
        training_score = np.zeros((X.shape[0], len(categories) + 2))
        training_score[:, 1] = y
        model = []
        folds=data_split(X,y,division_method,division_param,training_datalabel)
        for i, (train, valid) in enumerate(folds):
            train_X, train_y = X[train], y[train]
            valid_X, valid_y = X[valid], y[valid]
            svm_model = svm.SVC(C=penality, kernel=kernel, degree=3, gamma=gamma, coef0=0.0, shrinking=True,
                                probability=True, random_state=1)
            svc = svm_model.fit(train_X, train_y)
            model.append(svc)
            training_score[valid, 0] = i
            training_score[valid, 2:] = svc.predict_proba(valid_X)
        training_score = pd.DataFrame(training_score,
                                           columns=['Fold', 'Label'] + ['Score_%s' % i for i in categories])
        best_model = model
        testing_score=None#m
        # independent dataset
        if not testing_dataframe is None:
            indep = testing_dataframe.values
            testing_score = np.zeros((indep.shape[0], len(categories) + 2))
            testing_score[:, 1] = testing_datalabel
            for svc in best_model:
                testing_score[:, 2:] += svc.predict_proba(indep)
            testing_score[:, 2:] /= fold
            testing_score = pd.DataFrame(testing_score,
                                              columns=['Fold', 'Label'] + ['Score_%s' % i for i in categories])
            testing_score['Fold'] = 'NA'
        # calculate metrics
        message = ''
        trainingAndMean_metric_dict,aucData,prcData=calculateEvaluationMetrics(training_score)
        if testing_score is not None:
            testing_metric_dict,_,_=calculateEvaluationMetrics(testing_score,is_train=False)
            ts_table=Metrics.getMetricsTable(testing_metric_dict,is_train=False)
        else:
            testing_metric_dict=None
            ts_table=None
        trAndMean_table=Metrics.getMetricsTable(trainingAndMean_metric_dict)
        # ts_table=Metrics.getMetricsTable(testing_metric_dict,is_train=False)

        return trainingAndMean_metric_dict,testing_metric_dict,trAndMean_table,ts_table,aucData,prcData,training_score,testing_score,message

    except Exception as e:
        error_msg = str(e)
        return None,None,None,None,None,None,None,None,error_msg

if __name__ == '__main__':
    train_name=r"D:\pycharm\untitled3\lyr\encondig\machine_Learning\kmer_train.csv"
    test_name=r"D:\pycharm\untitled3\lyr\encondig\machine_Learning\kmer_test.csv"

    new_result=AdaBoost(train_name,test_name,5)
    print(new_result)