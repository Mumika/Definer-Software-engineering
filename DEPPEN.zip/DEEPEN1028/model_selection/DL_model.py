from typing import ValuesView
from torch.optim import optimizer
from Const import DL_METHOD, NUM_WORKERS, POS_LABEL
from CommonClass import PageData
import torch
import numpy as np
import random
import os
import torch.nn as nn
import torch.nn.functional as F
from PyQt5.QtCore import QObject,Qt,pyqtSignal,QThread

from sklearn.model_selection import StratifiedKFold,KFold,LeaveOneOut,StratifiedShuffleSplit

def set_seed(seed_id):
    """ Set all seeds to make results reproducible """
    torch.manual_seed(seed_id)
    torch.cuda.manual_seed_all(seed_id)
    # torch.cuda.manual_seed_all(0)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
    np.random.seed(seed_id)
    random.seed(seed_id)
    os.environ['PYTHONHASHSEED'] = str(seed_id)

class CNN_net(nn.Module):
        def __init__(self,embed_size,class_num,filter_num,filter_size,stride,dilation,topk,mRNA_dic):
            super(CNN_net, self).__init__()
            Dim = embed_size ##每个词向量长度
            Cla = class_num ##类别数
            Knum = filter_num ## 每种卷积核的数量
            Ks = filter_size ## 卷积核list，形如[2,3,4]
            strider = stride ##卷积步长
            self.topk = topk ##topk值
            self.batch_norm = nn.BatchNorm1d(filter_num)
            self.embed = nn.Embedding(len(mRNA_dic),embed_size)
            self.conv1d = nn.ModuleList([nn.Conv1d(Dim,Knum,K,stride=strider,dilation=dilation) for K in Ks])
            self.fc = nn.Linear(filter_num*len(Ks)*self.topk,Cla) ##全连接层

        @staticmethod
        def kmax_pooling(x, dim, k):    
            index = x.topk(k, dim=dim)[1].sort(dim=dim)[0]
            return x.gather(dim, index)

        def forward(self,x):
            x = self.embed(x)
            batch_size = x.shape[0]
            x = x.transpose(1,2)
            x = [F.relu(conv(x)) for conv in self.conv1d] # len(Ks)*(N,Knum,W) 窗口种数*（batch_size, filter数, 序列长）
            x = [self.batch_norm(line) for line in x]
            x = [CNN_net.kmax_pooling(line,2,self.topk) for line in x]  # len(Ks)*(N,Knum) 窗口种数*（batch_size, filter数, 6）
            x = [line.view(batch_size,-1) for line in x] #len(Ks)*(N,Knum*6)窗口种数*（batch_size*6）
            x = torch.cat(x,1)
            logit = self.fc(x)
            return logit
class MLP_net(nn.Module):
        def __init__(self,embed_size,class_num,mRNA_dic,model_shape,layer_num):
            assert model_shape in ["up","down","up2down"]
            super(MLP_net, self).__init__()
            Dim = embed_size ##每个词向量长度
            Cla = class_num ##类别数
            self.embed = nn.Embedding(len(mRNA_dic),Dim)
            if model_shape=="up":
                self.fc = nn.ModuleList([nn.Linear(embed_size*(2**i),embed_size*(2**(i+1))) for i in range(layer_num)])
                self.fc.append(nn.Linear(embed_size*(2**(layer_num)),Cla))
            elif model_shape=="down":
                if layer_num > np.log2(embed_size):
                    print("超出此形态下最大layer数，已默认修改为最大值")
                    layer_num = int(np.log2(embed_size))
                self.fc = nn.ModuleList([nn.Linear(embed_size//(2**i),embed_size//(2**(i+1))) for i in range(layer_num)])
                self.fc.append(nn.Linear(embed_size//(2**(layer_num)),Cla))
            elif model_shape=="up2down":
                layer_up,layer_down = layer_num//2,layer_num//2
                self.fc_up = nn.ModuleList([nn.Linear(embed_size*(2**i),embed_size*(2**(i+1))) for i in range(layer_up)])
                start_embed_size = embed_size*(2**(layer_up))
                if layer_down > np.log2(start_embed_size):
                    layer_down = int(np.log2(start_embed_size))
                self.fc_down = nn.ModuleList([nn.Linear(start_embed_size//(2**i),start_embed_size//(2**(i+1))) for i in range(layer_down)])
                self.fc = self.fc_up.extend(self.fc_down)
                self.fc.append(nn.Linear(start_embed_size//(2**(layer_down)),Cla))
        def forward(self,x):
            x = self.embed(x)
            for L in self.fc:
                x = L(x)
            x=torch.mean(x,dim=1)
            return x

class ImprovedRnn(nn.Module):
    def __init__(self, module, module_name, mRNA_dic, embed_size,class_num, **kwargs):
        assert module in (nn.RNN, nn.LSTM, nn.GRU)
        super().__init__()
        self.module_name = module_name
        self.embed = nn.Embedding(len(mRNA_dic),embed_size)
        self.module = module(**kwargs)
        self.kwargs = kwargs
        if kwargs["bidirectional"]:
            self.fc = nn.Linear(kwargs["hidden_size"]*2,class_num) 
        else:
            self.fc = nn.Linear(kwargs["hidden_size"],class_num) 
    def forward(self, input):#, lengths):  # input shape(batch_size, seq_len, input_size)
        #应对多GPU
        lengths=torch.tensor([input.shape[1]]*input.shape[0])
        input = self.embed(input)  
        if not hasattr(self, '_flattened'):
            self.module.flatten_parameters()
            setattr(self, '_flattened', True)
        max_len = input.shape[1]
        # package = nn.utils.rnn.pack_padded_sequence(input, input.shape[1], batch_first=self.module.batch_first, enforce_sorted=False)
        package = nn.utils.rnn.pack_padded_sequence(input, lengths.cpu(), batch_first=self.module.batch_first, enforce_sorted=False)
        result, hidden = self.module(package)
        result, lens = nn.utils.rnn.pad_packed_sequence(result, batch_first=self.module.batch_first, total_length=max_len)
        if self.kwargs["bidirectional"]:
            if self.module_name=="lstm":
                hidden_cat = torch.cat((hidden[0][0],hidden[0][1]),dim=1)
                logits = self.fc(hidden_cat)
            else:
                hidden_cat = torch.cat((hidden[0],hidden[1]),dim=1)
                logits = self.fc(hidden_cat)
        else:
            logits = self.fc(hidden[0]) #默认使用h,如有需要可以改
        return logits.squeeze(dim=0)

class SelfAttention(nn.Module):
    def __init__(self, hid_dim, n_heads, dropout, mRNA_dict, class_num):
        super(SelfAttention, self).__init__()
        self.hid_dim = hid_dim
        self.n_heads = n_heads
        assert hid_dim % n_heads == 0
        self.embed = nn.Embedding(len(mRNA_dict),hid_dim)
        self.w_q = nn.Linear(hid_dim, hid_dim)
        self.w_k = nn.Linear(hid_dim, hid_dim)
        self.w_v = nn.Linear(hid_dim, hid_dim)
        self.fc = nn.Linear(hid_dim, hid_dim)
        self.do = nn.Dropout(dropout)
        self.scale = torch.sqrt(torch.FloatTensor([hid_dim // n_heads])).to(self.fc.weight.device)
        self.fc2logits = nn.Linear(hid_dim,class_num)
    def forward(self, input_X, mask=None):
        bsz = input_X.shape[0]
        new_input_X = torch.cat((torch.ones([bsz,1]).long(),input_X),dim=1).to(input_X.device)
        new_input_X = torch.cat((torch.ones([bsz, 1]).long().to(input_X.device), input_X), dim=1)
        mask = new_input_X>0
        input_X = self.embed(new_input_X)
        query, key, value = input_X, input_X, input_X
        
#         print(query.shape)
        Q = self.w_q(query)
        K = self.w_k(key)
        V = self.w_v(value)
        Q = Q.view(bsz, -1, self.n_heads, self.hid_dim //
                   self.n_heads).permute(0, 2, 1, 3)
        K = K.view(bsz, -1, self.n_heads, self.hid_dim //
                   self.n_heads).permute(0, 2, 1, 3)
        V = V.view(bsz, -1, self.n_heads, self.hid_dim //
                   self.n_heads).permute(0, 2, 1, 3)
        # energy = torch.matmul(Q, K.permute(0, 1, 3, 2)) / self.scale
        energy = torch.matmul(Q, K.permute(0, 1, 3, 2)) / self.scale.to(input_X.device)
#         print(energy.shape)
        if mask is not None:
#             print(mask.unsqueeze(1).unsqueeze(-1) == 0)
#             print(mask.unsqueeze(1).unsqueeze(1) == 0)
            energy = energy.masked_fill(mask.unsqueeze(1).unsqueeze(-1) == 0, -1e10)\
                            .masked_fill(mask.unsqueeze(1).unsqueeze(1) == 0, -1e10)
#             print(energy)
        attention = self.do(torch.softmax(energy, dim=-1))
        x = torch.matmul(attention, V)
        x = x.permute(0, 2, 1, 3).contiguous()
        x = x.view(bsz, -1, self.n_heads * (self.hid_dim // self.n_heads))
        x = self.fc(x)
        logits = self.fc2logits(x[:,0,:])
        
        return logits
class Multihead_ImprovedRnn(nn.Module):
    def __init__(self, module, module_name, mRNA_dic, embed_size,class_num, **kwargs):
        assert module in (nn.RNN, nn.LSTM, nn.GRU)
        super().__init__()
        self.module_name = module_name
        self.embed = nn.Embedding(len(mRNA_dic),embed_size)
        self.module = module(**kwargs)
        self.kwargs = kwargs
        if kwargs["bidirectional"]:
            self.fc = nn.Linear(kwargs["hidden_size"]*2,class_num) 
        else:
            self.fc = nn.Linear(kwargs["hidden_size"],class_num) 
    def forward(self, input, lengths):  # input shape(batch_size, seq_len, input_size)
        #应对多GPU
        bsz = input.shape[0]
        # new_input_X = torch.cat((torch.ones([bsz,1]).long(),input),dim=1).to(input.device)
        new_input_X = torch.cat((torch.ones([bsz, 1]).long().to(input.device), input), dim=1)
        input = self.embed(new_input_X)
        if not hasattr(self, '_flattened'):
            self.module.flatten_parameters()
            setattr(self, '_flattened', True)
        max_len = input.shape[1]
        package = nn.utils.rnn.pack_padded_sequence(input, lengths.cpu(), batch_first=self.module.batch_first, enforce_sorted=False)
        result, hidden = self.module(package)
        result, lens = nn.utils.rnn.pad_packed_sequence(result, batch_first=self.module.batch_first, total_length=max_len)
        return result
class Multihead_SelfAttention(nn.Module):
    def __init__(self, hid_dim, n_heads, dropout):
        super(Multihead_SelfAttention, self).__init__()
        self.hid_dim = hid_dim
        self.n_heads = n_heads
        assert hid_dim % n_heads == 0
        self.w_q = nn.Linear(hid_dim, hid_dim)
        self.w_k = nn.Linear(hid_dim, hid_dim)
        self.w_v = nn.Linear(hid_dim, hid_dim)
#         print(self.w_q.weight)
#         print(self.w_q.weight.shape)
        self.fc = nn.Linear(hid_dim, hid_dim)
        self.do = nn.Dropout(dropout)
        self.scale = torch.sqrt(torch.FloatTensor([hid_dim // n_heads])).to(self.fc.weight.device)
    def forward(self, input_X, mask=None):
        query, key, value = input_X, input_X, input_X
        bsz = query.shape[0]
#         print(query.shape)
        Q = self.w_q(query)
        K = self.w_k(key)
        V = self.w_v(value)
        Q = Q.view(bsz, -1, self.n_heads, self.hid_dim //
                   self.n_heads).permute(0, 2, 1, 3)
        K = K.view(bsz, -1, self.n_heads, self.hid_dim //
                   self.n_heads).permute(0, 2, 1, 3)
        V = V.view(bsz, -1, self.n_heads, self.hid_dim //
                   self.n_heads).permute(0, 2, 1, 3)
        # energy = torch.matmul(Q, K.permute(0, 1, 3, 2)) / self.scale
        energy = torch.matmul(Q, K.permute(0, 1, 3, 2)) / self.scale.to(input_X.device)
#         print(energy.shape)

        if mask is not None:
#             print(mask.unsqueeze(1).unsqueeze(-1) == 0)
#             print(mask.unsqueeze(1).unsqueeze(1) == 0)
            energy = energy.masked_fill(mask.unsqueeze(1).unsqueeze(-1) == 0, -1e10)\
                            .masked_fill(mask.unsqueeze(1).unsqueeze(1) == 0, -1e10)
#             print(energy)
        attention = self.do(torch.softmax(energy, dim=-1))
        x = torch.matmul(attention, V)
        x = x.permute(0, 2, 1, 3).contiguous()
        x = x.view(bsz, -1, self.n_heads * (self.hid_dim // self.n_heads))
        x = self.fc(x)
        return x

class RNN_Multihead_Attention(nn.Module):
    def __init__(self, module, module_name, mRNA_dic, embed_size,class_num,n_heads,att_drop, **kwargs):
        super().__init__()
        self.rnn_module = Multihead_ImprovedRnn(module,module_name,mRNA_dic,embed_size=16,class_num=class_num,**kwargs)
        if kwargs["bidirectional"]:
            hidden_dim = kwargs["hidden_size"] * 2
        else:
            hidden_dim = kwargs["hidden_size"]
            
        self.self_attention = Multihead_SelfAttention(hidden_dim,n_heads,att_drop)
        self.fc_res = nn.Linear(hidden_dim,class_num)
        self.embed=self.rnn_module.embed
    def forward(self,input_x):#,input_x_len):
        input_x_len = lengths = torch.tensor([input_x.shape[1]] * input_x.shape[0]).to(input_x.device)
        # input_x_len=lengths=torch.tensor([input_x.shape[1]]*input_x.shape[0])
        res = self.rnn_module(input_x,input_x_len)
        res = self.self_attention(res)
        res=res[:,0]#torch.mean(res,dim=1)#修改的部分
        logits = self.fc_res(res)
        return logits
class Multihead_CNN_net(nn.Module):
        def __init__(self,embed_size,class_num,filter_num,stride,dilation,Kernal,mRNA_dic):
            super(Multihead_CNN_net, self).__init__()
            Dim = embed_size ##每个词向量长度
            Cla = class_num ##类别数
            Knum = filter_num ## 每种卷积核的数量
            strider = stride ##卷积步长

            self.batch_norm = nn.BatchNorm1d(filter_num)
            self.embed = nn.Embedding(len(mRNA_dic),embed_size)
            self.conv1d = nn.Conv1d(Dim,Knum,Kernal,stride=strider,dilation=dilation) 
#             self.fc = nn.Linear(filter_num*len(Ks)*self.topk,Cla) ##全连接层

        @staticmethod
        def kmax_pooling(x, dim, k):    
            index = x.topk(k, dim=dim)[1].sort(dim=dim)[0]
            return x.gather(dim, index)

        def forward(self,x):
            x = self.embed(x)
            batch_size = x.shape[0]
            x = x.transpose(1,2)
            x = F.relu(self.conv1d(x))  # len(Ks)*(N,Knum,W) 窗口种数*（batch_size, filter数, 序列长）
            return x.transpose(1,2)
class CNN_Multihead_Attention(nn.Module):
    def __init__(self, embed_size,class_num,filter_num,stride,dilation,n_heads,att_drop,Kernal,mRNA_dic):
        super().__init__()
        self.cnn = Multihead_CNN_net(embed_size,class_num,filter_num,stride,dilation,Kernal,mRNA_dic)
        self.self_attention = Multihead_SelfAttention(filter_num,n_heads,att_drop)
        self.fc_res = nn.Linear(filter_num,class_num)
        self.embed=self.cnn.embed
    def forward(self,input_x):
        res = self.cnn(input_x)
        res = self.self_attention(res)
        logits = self.fc_res(res[:,0])
        return logits

class RNN_Simple_Attention(nn.Module):
    def __init__(self, module, module_name, mRNA_dic, embed_size,class_num,n_heads,att_drop,seq_len, **kwargs):
        super().__init__()
        self.rnn_module = Multihead_ImprovedRnn(module,module_name,mRNA_dic,embed_size=16,class_num=class_num,**kwargs)
        if kwargs["bidirectional"]:
            hidden_dim = kwargs["hidden_size"] * 2
        else:
            hidden_dim = kwargs["hidden_size"]
            
        self.attention = nn.Embedding(seq_len,1)
        self.fc_res = nn.Linear(hidden_dim,class_num)
        self.embed=self.rnn_module.embed
    def forward(self,input_x):#,input_x_len):
        input_x_len = lengths = torch.tensor([input_x.shape[1]] * input_x.shape[0]).to(input_x.device)
        # input_x_len=lengths=torch.tensor([input_x.shape[1]]*input_x.shape[0])
        res = self.rnn_module(input_x,input_x_len)
        weight = torch.softmax(self.attention.weight,dim=0)
        weighted_res = res * weight
        weighted_res = weighted_res[:,0]#torch.mean(weighted_res,dim=1)
        logits = self.fc_res(weighted_res)
        return logits

class CNN_Simple_Attention(nn.Module):
    def __init__(self, embed_size,class_num,filter_num,stride,dilation,n_heads,att_drop,Kernal,seq_len,mRNA_dic):
        super().__init__()
        self.cnn = Multihead_CNN_net(embed_size,class_num,filter_num,stride,dilation,Kernal,mRNA_dic)
        self.attention = nn.Embedding(seq_len-Kernal+1,1)
        self.fc_res = nn.Linear(filter_num,class_num)
        self.embed=self.cnn.embed
    def forward(self,input_x):
        res = self.cnn(input_x)
        weight = torch.softmax(self.attention.weight,dim=0)
        weighted_res = res * weight
        weighted_res = weighted_res[:,0]#torch.mean(weighted_res,dim=1)
        logits = self.fc_res(weighted_res)
        return logits
from torch.utils.data import Dataset,DataLoader

class MyDataset(Dataset):
    def __init__(self,data_x,data_y):
        self.data_x=data_x
        self.data_y=data_y
    def __getitem__(self, index):
        return self.data_x[index],self.data_y[index]
    def __len__(self):
        return self.data_x.shape[0]

class ProcessPanelData():
    def __init__(self):
        pass
    @staticmethod  
    def getDataset_from_panel(pageData,encoding_type):#training_dataset,testing_dataset):
        #get data from pageData
        if pageData.encoding_panel.method in DL_METHOD:
            data=pageData.padding_array
        else:
            data=pageData.encoding_array
        training_dataset,testing_dataset=pageData.getDataset(pageData.data_purpose,data)

        training_dataset,testing_dataset=ProcessPanelData.getTonsorDataset(training_dataset,encoding_type),ProcessPanelData.getTonsorDataset(testing_dataset,encoding_type)
        train_y=torch.from_numpy(np.array(pageData.data_label)[pageData.training_sample_index].astype(float)).long()
        test_y=torch.from_numpy(np.array(pageData.data_label)[pageData.testing_sample_index].astype(float)).long()

        #get Dataset
        training_dataset=MyDataset(training_dataset,train_y)
        testing_dataset=MyDataset(testing_dataset,test_y)
        return training_dataset,testing_dataset
    @staticmethod 
    def getTonsorDataset(data,encoding_type):
        import numpy as np
        import torch
        if encoding_type in DL_METHOD:
            # array=[]
            # data=np.array(data)
            # for row in data:
            #     row=row[0]
            #     array.append([float(t2) for t1,t2 in row])
            # array=np.array(array)
            array=data.values
        else:
            array=data.values[:,:-1].astype(float)
        return torch.from_numpy(array).long()
    @staticmethod
    def getDataLoader(dataset,batch_size):
        # import sys
        # if sys.platform.startswith('win'):
        #     num_workers=1
        # else:
        #     num_workers=NUM_WORKERS
        return DataLoader(dataset,batch_size=batch_size)#,num_workers=num_workers)

    @staticmethod
    def isDivisionLegal(folds,datalabels):
        for i, (train, valid) in enumerate(folds):
            label_num1=len(set(datalabels[train]))
            label_num2=len(set(datalabels[valid]))
            if label_num1==1:
                return False
        return True
    @staticmethod
    def data_split(X,y,method,fold,train_ratio=4,test_ratio=1):
        res=None
        if method=='KFold':
            kf=KFold(n_splits=fold)
            kf.get_n_splits(X,y)
            res=kf.split(X,y)
            if ProcessPanelData.isDivisionLegal(res,y)==False:
                res = StratifiedKFold(fold).split(X, y)

        elif method=='StratifiedKFold':
            res = StratifiedKFold(fold).split(X, y)
        
        elif method=='LeaveOneOut':
            loo=LeaveOneOut()
            loo.get_n_splits(X,y)
            res=loo.split(X,y)

        elif method=='StratifiedShuffleSplit':
            train_ratio=float(train_ratio)
            test_ratio=float(test_ratio)
            test_size=test_ratio/(train_ratio+test_ratio)
            sss=StratifiedShuffleSplit(n_splits=fold,test_size=test_size,random_state=0)
            sss.get_n_splits(X,y)
            res=sss.split(X,y)
        return res
def split_long_short(all_datas,max_len):
    """按照一定长度切割"""
    over_flow = torch.Tensor([torch.count_nonzero(all_datas[0][i]).item()\
                              for i in range(all_datas[0].shape[0])]) > max_len
    not_over_flow = torch.logical_not(over_flow)
    long_datas = [all_datas[0][over_flow],all_datas[1][over_flow]]
    short_datas = [all_datas[0][not_over_flow][:,:max_len],all_datas[1][not_over_flow][:max_len]]
    return short_datas,long_datas      
class Trainer(QThread):
    _signal = pyqtSignal(object,object,object,object,object)
    def __init__(self,training_dataset,vocab_dict,feature_num, class_num,model_name,kfold,folds,config):
        # self.model = model.to(init.device)
        super().__init__()
        self.training_dataset = training_dataset
        self.vocab_dict=vocab_dict
        self.feature_num=feature_num
        self.class_num=class_num

        self.folds=folds
        self.kfold=kfold
        self.k=0

        self.model_name=model_name
        self.epochs=config['epochs']
        self.batch_size=config['batch_size']
        self.config=config

        self.len_train = None
        self.len_eval = None
        self.best_evalscore = 0
        self.curbest_model=None

        self.log_evalacc = np.empty((self.kfold, self.epochs))
        self.log_evalloss = np.empty((self.kfold, self.epochs))
        self.log_evalsn = np.empty((self.kfold, self.epochs))
        self.log_evalsp = np.empty((self.kfold, self.epochs))
        self.log_eval_mcc= np.empty((self.kfold, self.epochs))
        self.log_eval_f1= np.empty((self.kfold, self.epochs))
        self.log_eval_auc=np.empty((self.kfold, self.epochs))
        self.log_eval_prc=np.empty((self.kfold, self.epochs))
        self.log_eval={'acc':self.log_evalacc,'loss':self.log_evalloss,'sn':self.log_evalsn,'sp':self.log_evalsp,'mcc':self.log_eval_mcc,'f1':self.log_eval_f1,'auc':self.log_eval_auc,'prc':self.log_eval_prc}
        
        self.log_trainacc = np.empty((self.kfold, self.epochs))
        self.log_trainloss = np.empty((self.kfold, self.epochs))
        self.log_train={'acc':self.log_trainacc,'loss':self.log_trainloss}



        self.device=Trainer.get_device()
    @staticmethod
    def get_device():
        ''' Get device (if GPU is available, use GPU) '''
        print('cuda' if torch.cuda.is_available() else 'cpu')
        return 'cuda' if torch.cuda.is_available() else 'cpu'
    @staticmethod
    def turn_pred2_1(pred):
        v,l = F.softmax(pred,dim=1).max(dim=1)
        res = []
        for i,j in zip(v,l):
        #     print(i,j)
            if j.item()==0:
                res.append((1-i).item())
            else:
                res.append(i.item())
        return res
        
    def fold_val(self):

        for i, (train, valid) in enumerate(self.folds):
            train_set = MyDataset(self.training_dataset[train][0], self.training_dataset[train][1])
            valid_set = MyDataset(self.training_dataset[valid][0], self.training_dataset[valid][1])
            
            train_iter=ProcessPanelData.getDataLoader(train_set,self.batch_size)
            dev_iter=ProcessPanelData.getDataLoader(valid_set,self.batch_size)
                  
            net=self.get_model(seq_len=train_set.data_x.shape[1]).to(self.device)
            criterion=torch.nn.CrossEntropyLoss().to(self.device)
            optimizer=getattr(torch.optim,self.config['optimizer'])(net.parameters(),**self.config['optim_hparas'])

            
            self.train(net,criterion,optimizer,train_iter, dev_iter)
            self.k += 1
        
    def train(self, model, criterion,optimizer,train_iter, eval_iter):
        # model.train()

        for epoch in range(self.epochs):
            model.train()
            
            train_l_sum,train_acc_sum,n=0.0,0.0,0.0

            for X,y in train_iter:

                # # 这里需要修改
                # x_len=torch.tensor([X.shape[1]]*X.shape[0])
                # short,long = split_long_short([X,x_len],800)
                # X,y = short[0].to(self.device), y.to(self.device)
                X,y = X.to(self.device), y.to(self.device)


                optimizer.zero_grad()
                pred=model(X)
                l=criterion(pred,y).sum()
                l.backward()
                optimizer.step()

                train_l_sum+=l
                train_acc_sum+=(pred.argmax(dim=1)==y).float().sum().item()
                n+=y.shape[0]
            self.log_trainloss[self.k][epoch]=train_l_sum
            self.log_trainacc[self.k][epoch]=train_acc_sum/n


            self.evaluate(model, criterion,optimizer, eval_iter,  epoch)
            if (epoch+1)%100==0:
                self._signal.emit(self.log_eval,self.log_train,None,self.best_evalscore,self.curbest_model)
        print(self.best_evalscore)
                
            
    def evaluate(self,model,criterion,optimizer, eval_iter, epoch):
        # from sklearn.metrics import confusion_matrix
        from sklearn.metrics import roc_auc_score
        
        model.eval()

        with torch.no_grad():
            all_loss,all_correct,n = 0.0,0.0,0.0
            metrics=Metrics(is_DL=True)
            # origin_confuse = [[0,0],[0,0]] 
            auc_score=[]
            for x, y in eval_iter:
                    x, y = x.to(self.device), y.to(self.device)
                    model.to(self.device)
                    pred=model(x)
                    l=criterion(pred,y).sum()

                    all_loss += l
                    metrics.refresh_metrics(y,pred)

            metrics.get_end_metrics()
            self.log_evalacc[self.k][epoch] = metrics.ACC
            self.log_evalloss[self.k][epoch]= all_loss#depends on criterion
            self.log_evalsn[self.k][epoch] = metrics.SN
            self.log_evalsp[self.k][epoch] = metrics.SP
            self.log_eval_mcc[self.k][epoch]= metrics.MCC
            self.log_eval_f1[self.k][epoch]= metrics.F1
            # self.log_eval_auc=metrics
            # self.log_eval_prc=metrics.
            # print(all_loss)
            if metrics.ACC > self.best_evalscore:
                self.best_evalscore = metrics.ACC
                self.curbest_model=model.state_dict()
            # print(self.best_evalscore)
    def get_model(self,seq_len=0):
        if self.model_name=='CNN':
            net = CNN_net(embed_size=self.config['embed_size'],class_num=self.class_num,filter_num=self.config['filter_num'],filter_size=self.config['filter_size'],stride=self.config['stride'],topk=self.config['topk'],dilation=self.config['dilation'],mRNA_dic=self.vocab_dict)
        elif self.model_name=='MLP':
            net=MLP_net(embed_size=self.config['embed_size'],class_num=self.class_num,mRNA_dic=self.vocab_dict,model_shape=self.config['model_shape'],layer_num=self.config['layer_num'])
        elif self.model_name=='LSTM':
            net=lstm = ImprovedRnn(nn.LSTM,"lstm",self.vocab_dict,embed_size=self.config['embed_size'],input_size=self.config['embed_size'], hidden_size=self.config['hidden_size'],class_num=self.class_num,batch_first=True, bidirectional=self.config['bidirectional'])
        elif self.model_name=='RNN':
            net=rnn = ImprovedRnn(nn.GRU,"gru",self.vocab_dict,embed_size=self.config['embed_size'],input_size=self.config['embed_size'], hidden_size=self.config['hidden_size'],class_num=self.class_num,batch_first=True, bidirectional=self.config['bidirectional'])
        elif self.model_name=='GRU':
            net=gru = ImprovedRnn(nn.RNN,"rnn",self.vocab_dict,embed_size=self.config['embed_size'],input_size=self.config['embed_size'], hidden_size=self.config['hidden_size'],class_num=self.class_num,batch_first=True, bidirectional=self.config['bidirectional'])
        elif self.model_name=='Attention':
            net= SelfAttention(hid_dim=self.config['hidden_dim'],n_heads=self.config['n_heads'],dropout=0.1,mRNA_dict=self.vocab_dict,class_num=self.class_num)
        elif self.model_name=='RNN_Multihead_Attention':
            net=RNN_Multihead_Attention(nn.LSTM,"lstm",self.vocab_dict,embed_size=self.config['embed_size'],input_size=self.config['embed_size'], hidden_size=self.config['hidden_dim'],
                  class_num=self.class_num,n_heads=self.config['n_heads'],att_drop=0.1,batch_first=True, bidirectional=self.config['bidirectional'])
        elif self.model_name=='CNN_Multihead_Attention':
            net=CNN_Multihead_Attention(embed_size=self.config['embed_size'],class_num=self.class_num,filter_num=self.config['filter_num'],stride=self.config['stride'],dilation=self.config['dilation'],
                  n_heads=self.config['n_heads'], att_drop=0.1,Kernal=self.config['filter_size'][0],mRNA_dic=self.vocab_dict)
        elif self.model_name=='RNN_Simple_Attention':#!!!!!注意这里面一定要改
            net=RNN_Simple_Attention(nn.LSTM,"lstm",self.vocab_dict,embed_size=self.config['embed_size'],input_size=self.config['embed_size'], hidden_size=self.config['hidden_dim'],
                  class_num=self.class_num,n_heads=self.config['n_heads'],att_drop=0.1,seq_len=seq_len+1,batch_first=True, bidirectional=self.config['bidirectional'])
        elif self.model_name=='CNN_Simple_Attention':#!!!!!注意这里面一定要改
            net=CNN_Simple_Attention(embed_size=self.config['embed_size'],class_num=self.class_num,filter_num=self.config['filter_num'],stride=self.config['stride'],dilation=self.config['dilation'],
                  n_heads=self.config['n_heads'], att_drop=0.1,Kernal=self.config['filter_size'][0],seq_len=seq_len,mRNA_dic=self.vocab_dict)
        if len(self.config['model_state_dict_path'])>0:
            net.load_state_dict(torch.load(self.config['model_state_dict_path']))
            self.curbest_model=torch.load(self.config['model_state_dict_path'])
        return net
                    
    def pred(self,dataset):
        net = self.get_model(seq_len=dataset.data_x.shape[1])#CNN_net(embed_size=16,class_num=self.class_num,filter_num=16,filter_size=[3],stride=1,topk=2,dilation=1,mRNA_dic=self.vocab_dict)
        net.load_state_dict(self.curbest_model)
        net.eval()
        y=dataset.data_y 
        preds = net(dataset.data_x).detach().cpu()   
        metrics=Metrics(is_DL=True)
        metrics.refresh_metrics(y,preds)
        metrics.get_end_metrics()
        return metrics

class Metrics(object):
    def __init__(self,is_DL=False):
        self.is_DL=is_DL
        self.all_correct=0.0
        self.n=0.0
        self.origin_confuse = [[0,0],[0,0]]
        self.TP = 0.0
        self.FN = 0.0
        self.TN = 0.0
        self.FP = 0.0
        self.SN = 0.0
        self.SP = 0.0
        self.ACC=0.0
        self.MCC=0.0
        self.F1=0.0
        self.PRE=0.0

        self.pos_label=POS_LABEL
        self.AUC=[]
        self.aucDot=None
        self.PRC=[]
        self.prcDot=None

        self.FPR=[]
        self.TPR=[]

        self.PRECISION=[]
        self.RECALL=[]
        # self.auc_score=[]
        
        # self.fpr=[]
        # self.tpr=[]
        # self.auc=[]

        # self.precision=[]
        # self.recall=[]
        # self.prc=[] #prc

        self.y=[]
        self.pred=[]

    @staticmethod
    def pred2label(pred):
        return pred.argmax(dim=1)

    @staticmethod
    def turn_pred2_1(pred):
        import torch.nn.functional as F
        v,l = F.softmax(pred,dim=1).max(dim=1)
        res = []
        for i,j in zip(v,l):
        #     print(i,j)
            if j.item()==0:
                res.append((1-i).item())
            else:
                res.append(i.item())
        return res
    def setVaules(self,sn,sp,pre,acc,mcc,f1,auc,prc):
        self.SN=sn
        self.SP=sp
        self.PRE=pre
        self.ACC=acc
        self.MCC=mcc
        self.F1=f1
        self.AUC=auc
        self.PRC=prc
    def refresh_metrics(self,y,pred):
        from sklearn.metrics import roc_auc_score
        from sklearn.metrics import confusion_matrix
        from sklearn.metrics import roc_curve, auc, precision_recall_curve
        import numpy as np
        import pandas as pd

        self.y=self.y+y.tolist()
        if self.is_DL:
            pred=torch.nn.functional.softmax(pred,dim=1)
        self.pred=self.pred+pred[:,self.pos_label].tolist()

        self.all_correct += (pred.argmax(dim=1)==y).float().sum().item()
        self.n+=y.shape[0]
        # y.detach().cuda().numpy()
        cur_confuse = confusion_matrix(y.cpu().numpy(), pred.argmax(dim=1).cpu().numpy())
        
        if len(cur_confuse) < 2:
            self.origin_confuse[0][0] += cur_confuse[0][0]
        else:
            self.origin_confuse[0][0] += cur_confuse[0][0]
            self.origin_confuse[0][1] += cur_confuse[0][1]
            self.origin_confuse[1][0] += cur_confuse[1][0]
            self.origin_confuse[1][1] += cur_confuse[1][1]
    def get_end_metrics(self):
        import math
        import numpy as np
        import pandas as pd
        from sklearn.metrics import roc_curve, auc, precision_recall_curve
        self.TP = self.origin_confuse[0][0]
        self.FN = self.origin_confuse[0][1]
        self.TN = self.origin_confuse[1][1]
        self.FP = self.origin_confuse[1][0]
        
        self.SN = self.TP/(self.TP+self.FN) if (self.TP+self.FN) != 0 else 0
        self.SP = self.TN/(self.TN+self.FP) if (self.TN+self.FP) != 0 else 0
        self.PRE = round(self.TP / (self.TP + self.FP), 4) if (self.TP + self.FP) != 0 else 0
        self.ACC = self.all_correct/self.n
        self.MCC = round((self.TP * self.TN - self.FP * self.FN) / math.sqrt((self.TP + self.FP) * (self.TP + self.FN) * (self.TN + self.FP) * (self.TN + self.FN)), 4) if (self.TP + self.FP) * (self.TP + self.FN) * (self.TN + self.FP) * (self.TN + self.FN) != 0 else 0 
        self.F1 = round(2 * self.TP / (2 * self.TP + self.FP + self.FN), 4) if (2 * self.TP + self.FP + self.FN) != 0 else 0 
        
        #auc
        self.FPR, self.TPR, _ = roc_curve(self.y, self.pred, pos_label=self.pos_label)
        self.AUC=round(auc(self.FPR, self.TPR), 4) #auc

        #prc
        self.PRECISION, self.RECALL, _ = precision_recall_curve(self.y, self.pred, pos_label=self.pos_label)
        self.PRC=round(auc(self.RECALL, self.PRECISION), 4) #prc

        self.aucDot = pd.DataFrame(np.hstack((self.FPR.reshape((-1, 1)), self.TPR.reshape((-1, 1)))), columns=['fpr', 'tpr'])
        self.prcDot = pd.DataFrame(np.hstack((self.RECALL.reshape((-1, 1)), self.PRECISION.reshape((-1, 1)))),columns=['recall', 'precision'])

    @staticmethod
    def getMetricsTable(data:dict,is_train=True):
        import pandas as pd
        index_name=[] if is_train else ['Test']
        column_name=['Sn', 'Sp', 'Pre', 'Acc', 'MCC', 'F1', 'AUROC', 'AUPRC']
        values= np.zeros((len(data), 8))
        for i,(f,metrics) in enumerate(data.items()):
            if metrics==None:
                return None
            if is_train:
                index_name.append(f)
            values[int(i)]=np.array(['%.4f'%metrics.SN, '%.4f'%metrics.SP, '%.4f'%metrics.PRE, '%.4f'%metrics.ACC, '%.4f'%metrics.MCC, '%.4f'%metrics.F1, '%.4f'%metrics.AUC, '%.4f'%metrics.PRC]).reshape((1, -1))    
        table_data=pd.DataFrame(values, index=index_name, columns=column_name)
        return table_data
    @staticmethod
    def getMeanMetrics(all_metrics):#param metric类型

        sn,sp,pre,acc,mcc,f1,auc,prc=[],[],[],[],[],[],[],[]
        all=[sn,sp,pre,acc,mcc,f1,auc,prc]
        for metric in all_metrics:
            sn.append(metric.SN)
            sp.append(metric.SP)
            pre.append(metric.PRE)
            acc.append(metric.ACC)
            mcc.append(metric.MCC)
            f1.append(metric.F1)
            auc.append(metric.AUC)
            prc.append(metric.PRC)
        mean_data=[]
        for i in all:
            i=np.mean(i)
            mean_data.append(i)
        metric=Metrics()
        metric.setVaules(mean_data[0],mean_data[1],mean_data[2],mean_data[3],mean_data[4],mean_data[5],mean_data[6],mean_data[7])
        return metric

    def get_device(self):
        ''' Get device (if GPU is available, use GPU) '''
        return 'cuda' if torch.cuda.is_available() else 'cpu'

class DL_model():
    def __init__(self,pageData,division_method,division_param,model_name,methodParam):




        #get parameter from panel
        method=division_method
        fold=int(division_param['method_value']) if len(division_param)>0 else 5
        train_ratio=int(division_param['train_ratio']) if 'train_ratio' in division_param.keys() else None
        test_ratio=int(division_param['test_ratio']) if 'train_ratio' in division_param.keys() else None
        feature_num=pageData.encoding_feature_num


        config = {
        'optimizer': 'Adam',             
        'optim_hparas': {                
            'lr': methodParam['learning_rate'],        
        },
        'early_stop': 200,              
        'save_path': 'models/model.pth'  
        }

        config=dict( config, **methodParam )

        #get data from pageData
        training_sample_name,testing_sample_name=pageData.training_sample_name,pageData.testing_sample_name
        vocab_dict=pageData.vocab
        class_num=len(set(pageData.data_label))
        training_dataset,testing_dataset=ProcessPanelData.getDataset_from_panel(pageData,pageData.encoding_panel.method)




        set_seed(24)
        # device=get_device()
        folds=ProcessPanelData.data_split(training_dataset.data_x,training_dataset.data_y,method,fold,train_ratio,test_ratio)
        print("folds",folds)

        trainer=Trainer(training_dataset,vocab_dict, feature_num,class_num,model_name,fold,folds,config)
        self.trainer=trainer
        self.config=config
        self.testing_dataset=testing_dataset
    def run_net(self):
        if len(self.config['model_state_dict_path'])==0:
            self.trainer.fold_val()
        test_metrics=self.trainer.pred(self.testing_dataset)
        self.trainer._signal.emit(self.trainer.log_eval,self.trainer.log_train,test_metrics,self.trainer.best_evalscore,self.trainer.curbest_model)
        return self.trainer.log_eval,self.trainer.log_train,test_metrics,self.trainer.best_evalscore,self.trainer.curbest_model