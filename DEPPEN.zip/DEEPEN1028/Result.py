from CommonWidget import DownloadWidget, ResultTable
from Encoding import StatisticalTextInfo
from PyQt5.QtGui import QIcon,QFont,QStandardItemModel,QStandardItem,QMovie
from PyQt5.QtWidgets import (QLineEdit,QScrollArea,QGroupBox,QWidget,QTabWidget,QLabel,QTextEdit,QPushButton,QSplitter,QLineEdit,QTableWidgetItem,
                              QFormLayout,QMainWindow,QDesktopWidget,QApplication,QGridLayout,QTableWidget,QAbstractItemView,
                                QAction,QMessageBox,QMenu,qApp,QFileDialog,QRadioButton,QTableView,QHeaderView,QVBoxLayout)
from PyQt5.QtCore import QObject,Qt,pyqtSignal
from PyQt5.QtGui import QIntValidator
from CommonClass import PageData, PanelValue
class TableWidget(QWidget):
    def __init__(self,minHeight=350,maxHeight=400,layout=[[0,0,1,1],[1,0,1,1]]):
        super().__init__()

        self.setMinimumHeight(minHeight)
        self.setMaximumHeight(maxHeight)
        self.layout=layout
        self.initUI()
    def initUI(self):
        self.reTable=ResultTable()
        self.downloadWidget=DownloadWidget()
        grid = QGridLayout()
        grid.addWidget(self.reTable,self.layout[0][0],self.layout[0][1],self.layout[0][2],self.layout[0][3])
        grid.addWidget(self.downloadWidget,self.layout[1][0],self.layout[1][1],self.layout[1][2],self.layout[1][3])
        self.setLayout(grid)
    @staticmethod
    def get_table_info(result,index=None):
        if result is None:
            return [],None,[]

        if index is None:
            return list(result.columns),result.values,list(result.index)
        else:
            return [str(i) for i in range(result.shape[1])],result,index

    @staticmethod
    def set_Table_File(table_signal,file_signal,data,filename='t',index=None):
        header,table_array,row_name=TableWidget.get_table_info(data,index)
        table_signal.emit(header,table_array,row_name)
        file_signal.emit(filename,header,table_array)



class ReDemoWidget(QWidget):#QGroupBox):
    def __init__(self,title,tabelHeight=250,minWidth=1500,maxWidth=1500,maxHeight=300):
        super().__init__()
        # self.setTitle(title)
        self.setStyleSheet(      "QGroupBox{font: bold}"
                                  "QGroupBox{color:white}"
                                  "QGroupBox:hover{color:grey;background-color:rgb(209,219,203)}")
        self.title=title
        
        self.minWidth=minWidth
        self.maxWidth=maxWidth
        self.maxHeight=maxHeight
        self.tabelHeight=tabelHeight
        self.initUI()

    def initUI(self):
          
        self.setMinimumWidth(self.minWidth)
        self.setMaximumWidth(self.maxWidth)
        self.setMaximumHeight(self.maxHeight)

        self.grid = QGridLayout(self)
        self.result=TableWidget(self.tabelHeight,self.tabelHeight)
        self.grid.addWidget(self.result,0,0)
    def update(self,array,header=None,row_name=None):
        self.array=array
        if header is None:
            self.header=[str(i) for i in range(len(array[0]))]
        else:
            self.header=header
        self.result.reTable.updateData(self.header,self.array,row_name)
        global pageData
        self.result.downloadWidget.setFile(pageData.encoding_panel.method+'_'+pageData.model_selection_panel.method+'_'+self.title,self.header,self.array)



  
class ResultContentWidget(QWidget):
    # next_set_data_signal=pyqtSignal(object)
    def __init__(self,data=''):
        super().__init__()
        #init
        global pageData
        pageData=PageData()
        self.pageData=pageData
        
        global panelValue
        panelValue=PanelValue()
        self.panelValue=panelValue

        self.initUI()

    def initUI(self):
        self.title = QLabel('Conclusion')
        self.title.setFont(QFont('Arial', 12))        

        # self.dataWidget=ReDemoWidget('Data',150,600,600,200)
        # self.encodingResultWidget=ReDemoWidget('Encoding',150,800,800,200)
        # self.featureSelectionResultWidget=ReDemoWidget('Feature selection',145,1590,1590,200)
        # self.modelSelectionReWidget=ReDemoWidget('Model selection',260,1590,1590)
        self.testMetricWidget=ReDemoWidget('test_result',145,1590,1590,200)

        self.conclusionWidget=ReDemoWidget('param_conclusion',580,1590,1590,600)

        self.best_evalacc_title = QLabel('Conclusion')
        self.best_evalacc_title.setFont(QFont('Arial', 12))

        grid = QGridLayout(self)
        
        grid.addWidget(self.title, 0, 0,1,2)
        # grid.addWidget(self.dataWidget, 1, 0)
        # grid.addWidget(self.encodingResultWidget, 1, 1)
        # grid.addWidget(self.featureSelectionResultWidget, 2, 0,1,2)
        # grid.addWidget(self.modelSelectionReWidget, 3, 0,1,2)
        grid.addWidget(self.conclusionWidget, 2, 0,1,2)
        grid.addWidget(self.testMetricWidget, 1, 0,1,2)        
        grid.addWidget(self.best_evalacc_title, 3, 0,1,2)
        # self.setLayout(grid0)

    # def update(self):
    #     global pageData
        
    #     header=['Total data number','Training data number','Testing  data number']
    #     data_array=[[str(pageData.data_num),str(pageData.data_train_num),str(pageData.data_test_num)]]
    #     self.dataWidget.update(data_array,header)

    #     header=['Encoding method','Encoding param','Number of features after encoding']
    #     data_array=[[str(pageData.encoding_panel.method),str(pageData.encoding_panel.param),str(pageData.feature_num)]]
    #     self.encodingResultWidget.update(data_array,header)

    #     if pageData.feature_selection_data is None:
    #         self.featureSelectionResultWidget.setVisible(False)
    #     else:
    #         header=['Selection method','Initial number of features','Number of features after feature selection']
    #         data_array=[[str(pageData.feature_selection_panel.method),str(pageData.feature_num),str(pageData.feature_selection_feature_num)]]
    #         self.featureSelectionResultWidget.update(data_array,header)

    #     data_array=[['Model',str(pageData.model_selection_panel.method)],['Model param',str(pageData.model_selection_panel.param)],['Dataset partitioning method',str(pageData.model_selection_panel.division_method)],['Dataset partitioning method param',str(pageData.model_selection_panel.division_param)]]
    #     self.modelSelectionReWidget.update(data_array,None)

    #     if pageData.test_metrics_table_value is not None:
    #         header,table_array,row_name=TableWidget.get_table_info(pageData.test_metrics_table_value)
    #         self.testMetricWidget.update(table_array,header,row_name)
    #     else:
    #         self.testMetricWidget.setVisible(False)

    #     if pageData.best_evalacc is not None:
    #         self.best_evalacc_title.setText('The highest accuracy of the model is '+str(pageData.best_evalacc))
    #     else:
    #         self.best_evalacc_title.setVisible(False)
    def update(self):
        global pageData
        
        rows=['Total data number','Training data number','Testing  data number']
        data_array=[[str(pageData.data_num)],[str(pageData.data_train_num)],[str(pageData.data_test_num)]]

        rows=rows+['Encoding method','Encoding param','Number of features after encoding']
        data_array=data_array+[[str(pageData.encoding_panel.method)],[str(pageData.encoding_panel.param)],[str(pageData.feature_num)]]

        if pageData.feature_selection_data is None:
            pass
        else:
            rows=rows+['Selection method','Initial number of features','Number of features after feature selection']
            data_array=data_array+[[str(pageData.feature_selection_panel.method)],[str(pageData.feature_num)],[str(pageData.feature_selection_feature_num)]]

        rows=rows+['Model','Model param','Dataset partitioning method','Dataset partitioning method param']            
        data_array=data_array+[[str(pageData.model_selection_panel.method)],[str(pageData.model_selection_panel.param)],[str(pageData.model_selection_panel.division_method)],[str(pageData.model_selection_panel.division_param)]]
        
        self.conclusionWidget.update(data_array,None,rows)

        if pageData.test_metrics_table_value is not None:
            header,table_array,row_name=TableWidget.get_table_info(pageData.test_metrics_table_value)
            self.testMetricWidget.update(table_array,header,row_name)
        else:
            self.testMetricWidget.setVisible(False)

        if pageData.best_evalacc is not None:
            self.best_evalacc_title.setText('The highest accuracy of the model is '+str(pageData.best_evalacc))
        else:
            self.best_evalacc_title.setVisible(False)
        

    def setdata(self,data):
        global pageData
        self.pageData=data
        pageData=data

        if data==None:
            QMessageBox.about(self, 'Warning','Data is empty')
        else:
            self.update()