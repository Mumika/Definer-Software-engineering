
from typing import Text
from numpy import not_equal
from Const import BATCH_SIZE, DILATION, EPOCHS, FILTER_NUM, FILTER_SIZE, LIMIT_FILE_SIZE, LEARNING_RATE, STRIDE, TOPK
from PyQt5.QtCore import pyqtSignal
from PyQt5.QtWidgets import QWidget
class PageData(object):
    def __init__(self):
              
        self.bar_state=''
        self.error_msg = ''
        self.type=''
        self.data_num=0
        self.data_train_num=0
        self.data_test_num=0
        self.min_fasta_len=0
        self.max_fasta_len=0
        
        self.vocab=[]
        self.feature_num=0
        self.ori_words_frequency = None
        self.data=None
        self.original_data = None 
        self.assemble_data=None#name seq label train
        self.sample_name=None 
        self.training_sample_name=None
        self.testing_sample_name=None
        self.seqdata=None                 
        self.datalabel = None                   
        self.data_purpose = None     
        self.training_dataset=None
        self.testing_dataset=None    
        self.training_sample_index=[]
        self.testing_sample_index=[]

        self.encoding_array=None
        self.encoding_header=None
        self.encoding_feature_name=None
        self.encoding_output_filename=''
        self.encoding_feature_num=0
        self.padding_array=None
        self.segmentation_frequency=None
        
        self.feature_selection_feature_num=None
        self.feature_selection_data = None
        self.feature_selection_header = None
        self.feature_selection_output_filename=''
        self.feature_selection_table_value = None     
        
        self.test_metrics_table_value=None
        self.best_evalacc=None
        self.best_model_state_dict=None
        self.encoding_panel=PanelValue()
        self.feature_selection_panel=PanelValue()
        self.model_selection_panel=PanelValue()
        self.table_value=None

        self.model_save_path='model.pth'
        self.model_state_dict_path=''

    def clearEncodingData(self):
        self.encoding_array=None
        self.encoding_header=None
        self.encoding_feature_name=None
        self.encoding_output_filename=''
        self.encoding_feature_num=0
        self.segmentation_frequency=None
        self.feature_selection_data = None
        self.feature_selection_header = None
        self.feature_selection_output_filename=''
        self.feature_selection_table_value = None     

        self.encoding_panel=PanelValue()
        self.feature_selection_panel=PanelValue()
        self.table_value=None

    def get_segmentation_frequency(self,data):
        import collections
        total_data=[]
        for i in data:
            t=[t1 for t1,t2 in i]
            total_data+=t
        return dict(collections.Counter(total_data).most_common())
    def get_words_frequency_by_ori(self,seqdata):
        import collections
        totalseqData=seqdata[0]
        for i in range(1,len(seqdata)):
            totalseqData+=seqdata[i]
        totalseqData=[i for i in totalseqData]
        
        return dict(collections.Counter(totalseqData).most_common())

    def setData_index(self):
        import numpy as np
        import pandas as pd
        self.training_sample_index=[]
        self.testing_sample_index=[]

        if len(self.data_purpose)>0:
            self.training_sample_index = np.where(self.data_purpose == True)[0]
            self.testing_sample_index = np.where(self.data_purpose == False)[0]
        
        self.training_dataset = pd.DataFrame(np.array(self.assemble_data)[self.training_sample_index])
        
        if len(self.testing_sample_index) != 0:
            self.testing_dataset = pd.DataFrame(np.array(self.assemble_data)[self.testing_sample_index])
    def getDataset(self,data_purpose,data):
        import numpy as np
        import pandas as pd
        
        training_sample_index=[]
        testing_sample_index=[]

        training_dataset=None
        testing_dataset=None

        if len(data_purpose)>0:
            training_sample_index = np.where(data_purpose == True)[0]
            testing_sample_index = np.where(data_purpose == False)[0]
        
        training_dataset = pd.DataFrame(np.array(data)[training_sample_index])
        
        if len(testing_sample_index) != 0:
            testing_dataset = pd.DataFrame(np.array(data)[testing_sample_index])
        
        return training_dataset,testing_dataset


    def clearOriginalData(self):
        self.bar_state=''
        self.error_msg = ''
        self.type=''
        self.original_data = None  
        self.seqdata=None                 
        self.datalabel = None                   
        self.data_purpose = None  
        
    def clearAll(self):
        self.bar_state=''
        self.error_msg = ''
        self.type=''
        self.data_num=0
        self.data_train_num=0
        self.data_test_num=0
        self.min_fasta_len=0
        self.max_fasta_len=0
        
        self.vocab=[]
        self.feature_num=0
        self.ori_words_frequency = None
        self.data=None
        self.original_data = None 
        self.assemble_data=None#name seq label train
        self.sample_name=None 
        self.training_sample_name=None
        self.testing_sample_name=None
        self.seqdata=None                 
        self.datalabel = None                   
        self.data_purpose = None     
        self.training_dataset=None
        self.testing_dataset=None    
        self.training_sample_index=[]
        self.testing_sample_index=[]

        self.encoding_array=None
        self.encoding_header=None
        self.encoding_feature_name=None
        self.encoding_output_filename=''
        self.encoding_feature_num=0
        self.padding_array=None
        self.segmentation_frequency=None
        
        self.feature_selection_feature_num=None
        self.feature_selection_data = None
        self.feature_selection_header = None
        self.feature_selection_output_filename=''
        self.feature_selection_table_value = None     
        
        self.test_metrics_table_value=None
        self.best_evalacc=None
        self.best_model_state_dict=None
        self.encoding_panel=PanelValue()
        self.feature_selection_panel=PanelValue()
        self.model_selection_panel=PanelValue()
        self.table_value=None

        self.model_save_path='model.pth'
        self.model_state_dict_path=''
    def changeArray2table(self,name,array,label):
        import numpy as np
        table_value=[]
        if array is not None and len(array)>0:
            if isinstance(array[0],tuple):
                for i in range(len(array)):
                    array_data=[]
                    array_data.append(name[i][0])
                    array_data.append(label[i])    
                    for (key,val) in array[i]:
                        v=str(key)#+':'+str(val)
                        array_data.append(v)
                    table_value.append(array_data)
                # table_value=np.array(table_value)
            else:
                table_value=np.hstack((name,array[:,-1].reshape(-1,1),array[:,:-1]))

        return table_value
    def refreshData(self,data):
        self.clearAll()
        import numpy as np
        self.data=data.strip('\n')
        self.original_data='\n'.join(self.preprocess_original_data(self.data))
        self.assemble_data,self.sample_name,self.seqdata,self.data_label,self.data_purpose,self.error_msg=self.preprocess_fasta(data)
        if self.assemble_data is not None:
            # self.setDataset()
            self.setData_index()# 这个地方有点慢
            self.training_sample_name=np.array(self.sample_name)[self.training_sample_index].tolist()
            self.testing_sample_name=np.array(self.sample_name)[self.testing_sample_index].tolist()
            self.data_train_num=np.sum(self.data_purpose!=0)
            self.data_test_num=np.sum(self.data_purpose==0)
            self.data_num=len(self.assemble_data)
            self.type=self.getSeqType(self.assemble_data)
            self.ori_words_frequency = self.get_words_frequency_by_ori(self.seqdata)


    def getEncodingDistribution(self,dict):
        pass

    def judge_data(self,fasta_list):
        msg=''
        
        if fasta_list is None or (fasta_list is not None and len(fasta_list)==0) :
            return 'Please input your data.'
        t=0
        try:
            fasta_list = fasta_list.split('\n')
            aa=[]+fasta_list
            fasta_list=[]
            for a in aa:
                if len(a)>0:
                    fasta_list.append(a)
            re_fasta_list=[]
            while t<len(fasta_list):
                if len(fasta_list[t])==0:
                    t=t+1
                    continue

                if not(fasta_list[t][0]=='>'):
                    msg=fasta_list[t][1:]+'\tIllegal format'
                
                else:
                    re_fasta_list.append(fasta_list[t])
                    if t+1==len(fasta_list):
                        msg=fasta_list[t][1:]+"\tMissing data"
                        
                    elif t+1<len(fasta_list) and fasta_list[t+1][0]=='>': 
                        msg=fasta_list[t][1:]+"\tMissing data"
                        
                    elif  t+1<len(fasta_list) and fasta_list[t+1][0]!='>':
                        re_fasta_list.append(fasta_list[t+1])
                        t=t+2
                        while(t<len(fasta_list) and fasta_list[t][0]!='>'):
                            re_fasta_list[len(re_fasta_list)-1]=re_fasta_list[len(re_fasta_list)-1]+fasta_list[t]
                            t=t+1
                    else:
                        t_data=fasta_list[t].split('|')
                        if(len(t_data)<3):
                            msg=t_data[0][1:]+'\tIllegal format'
                        else:
                            if t_data[2] not in ['training','testing']:
                                msg=t_data[0][1:]+'\tIllegal format'
                            if len(t_data[1])==0:
                                msg=t_data[0][1:]+'\tIllegal format'
                            t=t+2
                if len(msg)>0:
                    return [],msg
        except Exception as e:
            msg='Illegal format'
        return re_fasta_list,msg
    
    def preprocess_original_data(self,data):
        import numpy as np
        import re
        msg=''
        all_data,msg=self.judge_data(data)
        if len(msg)>0:
            return None,None,None,None,None,msg

        for i in range(1,len(all_data),2):
            all_data[i]=re.sub('[^ACDEFGHIKLMNPQRSTUVWY-]', '-', ''.join(all_data[i]).upper())
        return all_data

    def preprocess_fasta(self,data):
        import numpy as np
        import re
        msg=''
        all_data,msg=self.judge_data(data)
        if len(msg)>0:
            return None,None,None,None,None,msg
        fasta_sequences = []
        seq_data=[]
        sample_name=[]
        labels=[]
        
        for i in range(0,len(all_data),2):

            header, seq = all_data[i][1:], re.sub('[^ACDEFGHIKLMNPQRSTUVWY-]', '-', ''.join(all_data[i+1]).upper())
            header_array = header.split('|')

            name = header_array[0]

            label = header_array[1] if len(header_array) >= 2 else '0'

            label_train = header_array[2] if len(header_array) >= 3 else 'training'
            fasta_sequences.append([name, seq, label, label_train])
            labels.append(label)
            sample_name.append(name)
            seq_data.append(seq)
 
        purpose = np.array([item[3] == 'training' for item in fasta_sequences])
        return fasta_sequences,sample_name,seq_data,labels, purpose,msg

    def getSeqType(self,all_seq_data):
        import random
        import re
        tmp_fasta_list = []
        if len(all_seq_data) < 100:
            tmp_fasta_list = all_seq_data
        else:
            random_index = random.sample(range(0, len(all_seq_data)), 100)
            for i in random_index:
                tmp_fasta_list.append(all_seq_data[i])

        sequence = ''
        for item in tmp_fasta_list:
            sequence += item[1]

        char_set = set(sequence)
        if 5 < len(char_set) <= 21:
            for line in all_seq_data:
                line[1] = re.sub('[^ACDEFGHIKLMNPQRSTVWY]', '-', line[1])
            return 'Protein'
        elif 0 < len(char_set) <= 5 and 'T' in char_set:
            return 'DNA'
        elif 0 < len(char_set) <= 5 and 'U' in char_set:
            for line in all_seq_data:
                line[1] = re.sub('U', 'T', line[1])
            return 'RNA'
        else:
            return 'Unknown'


class FastaFile(object):
    def __init__(self,filename):
        self.filename=filename
    def readData(self):
        import os
        f = open(self.filename, 'r')
        size=self.toMB(os.stat(self.filename).st_size)

        data=''
        msg=''
        if float(size)<=float(LIMIT_FILE_SIZE)+0.1:
            with f:
                data = f.read()
                f.close
        else:
            msg='Exceed'
        return data,msg
        
    def toMB(self,bytesize):
          return f'{bytesize/1024/1024:.2f}'

class MyFile(object):
    def __init__(self,filename,type='csv'):
        self.type=type
        self.filename=filename

    def readData(self):
        if self.type=='csv':
            import pandas as pd
            data = pd.read_csv(self.filename)
            msg=''
        elif  self.type=='txt':
            import os
            f = open(self.filename, 'r')
            size=self.toMB(os.stat(self.filename).st_size)

            data=''
            msg=''
            if float(size)<=float(LIMIT_FILE_SIZE)+0.1:
                with f:
                    data = f.read()
                    f.close
            else:
                msg='Exceed'
        return data,msg
        
    def toMB(self,bytesize):
          return f'{bytesize/1024/1024:.2f}'

class PanelValue(QWidget):
    refresh_signal=pyqtSignal()
    refresh_division_signal=pyqtSignal()
    def __init__(self):
        super().__init__()
        self.method=''
        self.param={}
        self.state=''
        self.division_method=''
        self.division_param={}
    def clear(self):
        self.refreshData('',{})

    def refreshData(self,method,param):
        self.method=method
        self.param=param
        self.refresh_signal.emit()
    def refreshDivisionData(self,method,param):
        self.division_method=method
        self.division_param=param
        self.refresh_division_signal.emit()

    def dict2text(self,data):
        text=''
        for key, value in data.items():
            text=text+key+':'+str(value)+';'
        return text


class DLparam(object):
    def __init__(self):
        super().__init__()
        self.epochs=EPOCHS
        self.batch_size=BATCH_SIZE
        self.learning_rate=LR
        self.filter_size=FILTER_SIZE#list
        self.filter_num=FILTER_NUM
        self.stride=STRIDE
        self.topk=TOPK#max_pooling
        self.dilation=DILATION

