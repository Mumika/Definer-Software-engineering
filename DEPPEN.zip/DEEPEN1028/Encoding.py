import collections
from Const import DL_METHOD, EXAMPLE_FILENAME, GENERAL_METHOD, KSPACE_SIZE, LIMIT_FILE_SIZE, MAX_FRE_NUM, MISMATCH_SIZE, STRIDE_SIZE, VOCAB_SIZE, WINDOW_SIZE, FeatureFusionMethod
from CommonClass import  FastaFile, PageData, PanelValue
import sys
from  CommonWidget import Dialog, ResultTable, StateWidget,DownloadWidget
import csv
import os
from PyQt5.QtGui import QIntValidator,QIcon,QFont,QStandardItemModel,QStandardItem,QMovie 
from PyQt5.QtWidgets import (QGroupBox,QToolTip,QFormLayout,QFrame,QSizePolicy,QToolButton,QScrollArea,QDockWidget,QListWidget,QWidget,QListWidgetItem,QTabWidget,QLabel,QTextEdit,QPushButton,QSplitter,QLineEdit,QTableWidgetItem,
                              QMainWindow,QDesktopWidget,QApplication,QGridLayout,QTableWidget,QAbstractItemView,
                                QAction,QMessageBox,QMenu,qApp,QFileDialog,QRadioButton,QTableView,QHeaderView,QVBoxLayout)
from PyQt5.QtCore import QObject,Qt,pyqtSignal,QSize,QParallelAnimationGroup,QPropertyAnimation,pyqtSlot,QAbstractAnimation

from CommonWidget import ProgressBar,DownloadWidget,CollapsibleBox
from PyQt5 import QtWidgets
import threading
from util.commonUtil import getTimeStr, get_sample_purpose, str2param,getSeqType,getDataDistribution
import encoding.DNAEncoding
import encoding.RNAEncoding
import encoding.ProteinEncoding
import encoding.GeneralEncoding
import numpy as np
import PlotWidgets
import sip

global pageData
global panelValue


  
class InputWidget(QWidget):
    input_signal = pyqtSignal()
    clear_signal= pyqtSignal()

    def __init__(self):
        super().__init__()
        self.initUI()


    def initUI(self):

        self.gif = QMovie('images/progressgif_new.gif')
        self.progress_bar = QLabel()

        self.setMaximumHeight(330)
        self.inputTitle = QLabel('Step 1:Please input FASTA sequence(s) in the area below')
        self.inputTitle.setFont(QFont('Arial', 12))
        # global inputDataEdit
        self.inputDataEdit = QTextEdit()

        self.exampleBtn = QPushButton("Load example FASTA", self)
        self.exampleBtn.clicked.connect(self.examplebuttonClicked)
        
        self.uploadTitle = QLabel('You can also load a FASTA file(.txt/.fasta/.fa)')
        self.uploadTitle.setFont(QFont('Arial', 9))
        self.uploadBtn = QPushButton("Upload a FASTA file", self)
        self.uploadBtn.clicked.connect(self.importButtonClicked)

        self.clearBtn = QPushButton("Clear", self)
        self.clearBtn.clicked.connect(self.clearButtonClicked)

        self.confirmBtn = QPushButton("Confirm", self)
        self.confirmBtn.clicked.connect(self.confirmBtnClicked)
        

        #Set grid
        #input widget includes text and file 
        grid = QGridLayout()
        grid.addWidget(self.inputTitle, 0, 0,1,1)
        grid.addWidget(self.exampleBtn, 0, 1,1,1)
        grid.addWidget(self.inputDataEdit, 1, 0,1,2)
        grid.addWidget(self.uploadTitle, 2, 0,1,1)
        grid.addWidget(self.uploadBtn, 2, 1,1,1)
        grid.addWidget(self.clearBtn, 3, 1,1,1)
        grid.addWidget(self.confirmBtn, 3, 0,1,1)
        grid.addWidget(self.progress_bar, 4, 0,1,1)
        
        self.setLayout(grid)
    def confirmBtnClicked(self):
        # global inputDataEdit
        self.progress_bar.setMovie(self.gif)
        self.gif.start()
        self.confirmBtn.setDisabled(True)
        text=self.inputDataEdit.toPlainText()
        
        self.t = threading.Thread(target=self.refreshData(text))
        self.t.start()
        
        # self.refreshData(text)
        self.progress_bar.clear()
        self.confirmBtn.setDisabled(False)
    def examplebuttonClicked(self):
        with open(EXAMPLE_FILENAME) as f:
            text = f.read()
        self.inputDataEdit.setPlainText(text)
        # self.refreshData(text)
        

    def importButtonClicked(self):

        fname = QFileDialog.getOpenFileName(self, 'Open file','','Text files (*.txt *.fasta *.fa)')
        if fname[0]:
            self.fastaFile=FastaFile(fname[0])
            text,msg=self.fastaFile.readData()
            if len(msg)>0:
                QMessageBox.about(self,'Error',"The file size cannot exceed "+str(LIMIT_FILE_SIZE)+"MB.")
            else:
                self.inputDataEdit.setPlainText(text)
                # self.refreshData(text)
                # pass
            

    
    def clearButtonClicked(self):
        # global inputDataEdit
        self.inputDataEdit.setPlainText('')

        global pageData
        pageData.clearAll()
        global panelValue
        panelValue.clear()

        self.clear_signal.emit()
    
    def refreshData(self,text):
        # global inputDataEdit
        text=self.inputDataEdit.toPlainText()
        # inputDataEdit.setPlainText(text)
        global pageData
        try:
            pageData.refreshData(text)
            if len(pageData.error_msg)==0:
                self.input_signal.emit()
            else:
                QMessageBox.about(self,'Error',pageData.error_msg)
        except Exception as e:
            QMessageBox.about(self,'Error','Please check your input.')


class CommonParamWidget(QWidget):

    def __init__(self,method,parent=None):
        super(CommonParamWidget, self).__init__(parent)
        self.method=method
        self.initUI()
    def initUI(self):

        formLayout=QFormLayout()
        
        self.windowedit=self.getIntLineEdit()
        self.windowedit.setPlaceholderText("Please enter an integer")
        self.windowedit.setText(str(WINDOW_SIZE))
        self.mismatchedit=self.getIntLineEdit()
        self.mismatchedit.setPlaceholderText("Please enter an integer")
        self.mismatchedit.setText(str(MISMATCH_SIZE))
        self.deltaedit=self.getIntLineEdit()
        self.deltaedit.setPlaceholderText("Please enter an integer")
        self.deltaedit.setText(str(MISMATCH_SIZE))
        self.kspaceedit=self.getIntLineEdit()
        self.kspaceedit.setPlaceholderText("Please enter an integer")
        self.kspaceedit.setText(str(KSPACE_SIZE))
        self.strideedit=self.getIntLineEdit()
        self.strideedit.setPlaceholderText("Please enter an integer")
        self.strideedit.setText(str(STRIDE_SIZE))
        self.vocabedit=self.getIntLineEdit()
        self.vocabedit.setPlaceholderText("Please enter an integer")
        self.vocabedit.setText(str(VOCAB_SIZE))
        
        windowList=['Kmer','Mismatch','Subsequence','RCKmer','Binary+ENAC','ENAC','EAAC','WindowsSplit','RCKmer+Mismatch']
        mismacthList=['Mismatch','RCKmer+Mismatch']
        deltaList=['Subsequence']
        kspaceList=['CKSAAP']
        strideList=['WindowsSplit']
        vocabList=['SentencePiece','WordPiece']

        
        self.all_para={}
        if self.method in windowList:
            formLayout.addRow('Sliding window',self.windowedit)
            self.all_para['sliding_window']=self.windowedit
        if self.method in mismacthList:
            formLayout.addRow('Mismatch',self.mismatchedit)
            self.all_para['Mismatch']=self.mismatchedit
        if self.method in deltaList:
            formLayout.addRow('Delta',self.deltaedit)
            self.all_para['Delta']=self.deltaedit
        if self.method in kspaceList:
            formLayout.addRow('Kspace',self.kspaceedit)
            self.all_para['Kspace']=self.kspaceedit
        if self.method in strideList:
            formLayout.addRow('Stride',self.strideedit)
            self.all_para['Stride']=self.strideedit
        if self.method in vocabList:
            formLayout.addRow('Vocab size',self.vocabedit)
            self.all_para['vocab_size']=self.vocabedit
        
        btnWidget=QWidget()
        btngrid=QGridLayout(btnWidget)
        confirmBtn = QPushButton("Confirm", self)
        confirmBtn.clicked.connect(self.confirmBtnClicked)
        btngrid.addWidget(confirmBtn,0,0)

        
        formLayout.addRow(confirmBtn)
        
        
        self.setLayout(formLayout)
    def getIntLineEdit(self):
        edit1=QLineEdit()
        edit1.setValidator(QIntValidator())
        edit1.setMaxLength(4)
        edit1.setAlignment(Qt.AlignRight)
        edit1.setFont(QFont('Arial',10))
        return edit1

    def confirmBtnClicked(self):
        global panelValue
        param={}
        for key, value in self.all_para.items():
            param[key]=value.text()
        panelValue.refreshData(self.method,param)


class TabDNA(QWidget):
    def __init__(self, *args, **kwargs):
        super(TabDNA, self).__init__(*args, **kwargs)
        self.seqType='DNA'
        self.initUI()
    def initUI(self):
        
        vlay = QVBoxLayout(self)
        scroll = QScrollArea()
        vlay.addWidget(scroll)
        content = QWidget()
        scroll.setWidget(content)
        scroll.setWidgetResizable(True)
        vlay = QVBoxLayout(content)

        
        #set item
        nacbox = CollapsibleBox("NAC")
        lay = QVBoxLayout()
        lay.addWidget(CommonParamWidget('NAC'))
        nacbox.setContentLayout(lay)

        #set item
        kmerbox = CollapsibleBox("Kmer")
        lay = QVBoxLayout()
        lay.addWidget(CommonParamWidget('Kmer'))
        kmerbox.setContentLayout(lay)

        #set item
        mismatchbox = CollapsibleBox("Mismatch")
        lay = QVBoxLayout()
        lay.addWidget(CommonParamWidget('Mismatch'))
        mismatchbox.setContentLayout(lay)

        #set item
        rckmerbox = CollapsibleBox("RCKmer")
        lay = QVBoxLayout()
        lay.addWidget(CommonParamWidget('RCKmer'))
        rckmerbox.setContentLayout(lay)

        #set item
        rckmerMisbox = CollapsibleBox("RCKmer+Mismatch")
        lay = QVBoxLayout()
        lay.addWidget(CommonParamWidget('RCKmer+Mismatch'))
        rckmerMisbox.setContentLayout(lay)

        vlay.addWidget(kmerbox)
        vlay.addWidget(nacbox)
        vlay.addWidget(mismatchbox)
        vlay.addWidget(rckmerbox)
        vlay.addWidget(rckmerMisbox)
        
        vlay.addStretch()
class TabRNA(QWidget):
    def __init__(self, *args, **kwargs):
        super(TabRNA, self).__init__(*args, **kwargs)
        self.seqType='RNA'
        self.initUI()
    def initUI(self):
        
        vlay = QVBoxLayout(self)
        scroll = QScrollArea()
        vlay.addWidget(scroll)
        content = QWidget()
        scroll.setWidget(content)
        scroll.setWidgetResizable(True)
        vlay = QVBoxLayout(content)

        #set item
        box1 = CollapsibleBox("Kmer")
        lay = QVBoxLayout()
        lay.addWidget(CommonParamWidget('Kmer'))
        box1.setContentLayout(lay)

        #set item
        box2 = CollapsibleBox("Binary")
        lay = QVBoxLayout()
        lay.addWidget(CommonParamWidget('Binary'))
        box2.setContentLayout(lay)

        #set item
        box3 = CollapsibleBox("NCP")
        lay = QVBoxLayout()
        lay.addWidget(CommonParamWidget('NCP'))
        box3.setContentLayout(lay)

        #set item
        box4 = CollapsibleBox("ENAC")
        lay = QVBoxLayout()
        lay.addWidget(CommonParamWidget('ENAC'))
        box4.setContentLayout(lay)

        #set item
        box5 = CollapsibleBox("Binary+ENAC")
        lay = QVBoxLayout()
        lay.addWidget(CommonParamWidget('Binary+ENAC'))
        box5.setContentLayout(lay)
        
        vlay.addWidget(box1)
        vlay.addWidget(box2)
        vlay.addWidget(box3)
        vlay.addWidget(box4)
        vlay.addWidget(box5)
        
        vlay.addStretch()

class TabProtein(QWidget):
    def __init__(self, *args, **kwargs):
        super(TabProtein, self).__init__(*args, **kwargs)
        self.seqType='Protein'
        self.initUI()
    def initUI(self):
        
        vlay = QVBoxLayout(self)
        scroll = QScrollArea()
        vlay.addWidget(scroll)
        content = QWidget()
        scroll.setWidget(content)
        scroll.setWidgetResizable(True)
        vlay = QVBoxLayout(content)

        #set item
        box1 = CollapsibleBox("Kmer")
        lay = QVBoxLayout()
        lay.addWidget(CommonParamWidget('Kmer'))
        box1.setContentLayout(lay)

        #set item
        box2 = CollapsibleBox("AAC")
        lay = QVBoxLayout()
        lay.addWidget(CommonParamWidget('AAC'))
        box2.setContentLayout(lay)

        #set item
        box3 = CollapsibleBox("EAAC")
        lay = QVBoxLayout()
        lay.addWidget(CommonParamWidget('EAAC'))
        box3.setContentLayout(lay)

        #set item
        box4 = CollapsibleBox("DPC")
        lay = QVBoxLayout()
        lay.addWidget(CommonParamWidget('DPC'))
        box4.setContentLayout(lay)

        #set item
        box5 = CollapsibleBox("Kmer+AAC")
        lay = QVBoxLayout()
        lay.addWidget(CommonParamWidget('Kmer+AAC'))
        box5.setContentLayout(lay)
        
        vlay.addWidget(box1)
        vlay.addWidget(box2)
        vlay.addWidget(box3)
        vlay.addWidget(box4)
        vlay.addWidget(box5)
        
        vlay.addStretch()
class TabDLEncoding(QWidget):
    def __init__(self, *args, **kwargs):
        super(TabDLEncoding, self).__init__(*args, **kwargs)
        self.initUI()
    def initUI(self):
        vlay = QVBoxLayout(self)
        scroll = QScrollArea()
        vlay.addWidget(scroll)
        content = QWidget()
        scroll.setWidget(content)
        scroll.setWidgetResizable(True)
        vlay = QVBoxLayout(content)

        #set item
        box1 = CollapsibleBox("Kmer")
        lay = QVBoxLayout()
        lay.addWidget(CommonParamWidget('Kmer'))
        box1.setContentLayout(lay)

        #set item
        box2 = CollapsibleBox("WindowsSplit")
        lay = QVBoxLayout()
        lay.addWidget(CommonParamWidget('WindowsSplit'))
        box2.setContentLayout(lay)

        #set item
        box3 = CollapsibleBox("SentencePiece")
        lay = QVBoxLayout()
        lay.addWidget(CommonParamWidget('SentencePiece'))
        box3.setContentLayout(lay)

        #set item
        box4 = CollapsibleBox("WordPiece")
        lay = QVBoxLayout()
        lay.addWidget(CommonParamWidget('WordPiece'))
        box4.setContentLayout(lay)

        #set item
        box5 = CollapsibleBox("BPE")
        lay = QVBoxLayout()
        lay.addWidget(CommonParamWidget('BPE'))
        box5.setContentLayout(lay)
        
        # vlay.addWidget(box1)
        vlay.addWidget(box2)
        vlay.addWidget(box3)
        vlay.addWidget(box4)
        vlay.addWidget(box5)

        
        vlay.addStretch()

class CurParamWidget(QGroupBox):
    def __init__(self):
        super().__init__()
        self.initUI()
    def initUI(self):
        self.setMaximumHeight(150)
        self.setFont(QFont('Arial', 10))
        paraLayout = QFormLayout(self)


        self.seqTypeLineEdit= QLineEdit()
        self.seqTypeLineEdit.setFont(QFont('Arial', 8))
        self.seqTypeLineEdit.setReadOnly(True)
        
        self.encodingMethodLineEdit = QLineEdit()
        self.encodingMethodLineEdit.setFont(QFont('Arial', 8))
        self.encodingMethodLineEdit.setReadOnly(True)
        
        self.paraLineEdit = QLineEdit()
        self.paraLineEdit.setFont(QFont('Arial', 8))
        self.paraLineEdit.setReadOnly(True)

        paraLayout.addRow('Sequence type:', self.seqTypeLineEdit)
        paraLayout.addRow('Encoding method:', self.encodingMethodLineEdit)
        paraLayout.addRow('Parameter(s):', self.paraLineEdit)
    def clear(self):
        global panelValue
        panelValue.clear()
        self.seqTypeLineEdit.setText('')

    def setType(self):
        global pageData
        self.seqTypeLineEdit.setText(pageData.type)
    def setMethodandParam(self):
        self.encodingMethodLineEdit.setText(panelValue.method)
        self.paraLineEdit.setText(panelValue.dict2text(panelValue.param))

class AllMethodTab(QTabWidget):
    def __init__(self):
        super().__init__()
        self.initUI()
    def initUI(self):
        '''Add subQWidget '''
        self.tab_DNA = QWidget()
        self.tab_RNA = QWidget()
        self.tab_Protein = QWidget()
        self.tab_DL_encoding = QWidget()
        self.addTab(self.tab_DL_encoding, 'Deep Learning method')
        self.addTab(self.tab_DNA, "DNA ")
        self.addTab(self.tab_RNA, "RNA ")
        self.addTab(self.tab_Protein, 'Protein ')
        

        '''Initialize tabWidget'''
        self.set_tab_DNA()
        self.set_tab_RNA()
        self.set_tab_Protein()
        self.set_tab_DL_encoding()

        
    def show_tab_DNA(self):
        self.setCurrentWidget(self.tab_DNA)
    def show_tab_RNA(self):
        self.setCurrentWidget(self.tab_RNA)
    def show_tab_Protein(self):
        self.setCurrentWidget(self.tab_Protein)
    def show_tab_DL_encoding(self):
        self.setCurrentWidget(self.tab_DL_encoding)
    def show_tab(self):
        global pageData
        type=pageData.type
        curshow_id=0
        self.refresh_show_tab()
        if type=='DNA':
            self.show_tab_DNA()
            curshow_id=0
        elif type=='RNA':
            self.show_tab_RNA()
            curshow_id=1
        elif type=='Protein':
            self.show_tab_Protein()
            curshow_id=2
        else:
            self.show_tab_DL_encoding()
        for i in range(3):
            if i!=curshow_id:
                self.setTabEnabled(i+1, False)
    def refresh_show_tab(self):
        for i in range(3):
            self.setTabEnabled(i+1, True)
    def set_tab_DNA(self):
        layout = QVBoxLayout()
        self.main_tab_DNA = TabDNA()
        layout.addWidget(self.main_tab_DNA)
        self.tab_DNA.setLayout(layout)

    def set_tab_RNA(self):
        layout = QVBoxLayout()
        self.main_tab_RNA = TabRNA()
        layout.addWidget(self.main_tab_RNA)
        self.tab_RNA.setLayout(layout)

    def set_tab_Protein(self):
        layout = QVBoxLayout()
        self.main_tab_Protein = TabProtein()
        layout.addWidget(self.main_tab_Protein)
        self.tab_Protein.setLayout(layout)

    def set_tab_DL_encoding(self):
        layout = QVBoxLayout()
        self.main_tab_DL_encoding = TabDLEncoding()
        layout.addWidget(self.main_tab_DL_encoding)
        self.tab_DL_encoding.setLayout(layout)

class AllMethodWidget(QTabWidget):
    def __init__(self):
        super().__init__()
        self.initUI()
    def initUI(self):
        title = QLabel('Step 2:Please select the encoding method')
        title.setFont(QFont('Arial', 12))
        self.parameterTab=AllMethodTab()
        self.chooseWidget=Choosewidget()
        self.curParamWidget=CurParamWidget()
        grid = QGridLayout()
        grid.addWidget(title, 0, 0,1,1)
        grid.addWidget(self.curParamWidget, 1, 0,1,1)
        grid.addWidget(self.parameterTab, 2, 0,1,1)
        grid.addWidget(self.chooseWidget, 3, 0,1,1)
        self.setLayout(grid)
    def clear(self):
        self.parameterTab.refresh_show_tab()
        self.curParamWidget.clear()

        
class Choosewidget(QWidget,QObject):
    encoding_signal = pyqtSignal()#signal connect table
    datatofile_signal = pyqtSignal(object,object,object)#input signal -> output file data
    next_btn_signal=pyqtSignal(object)#set data to other module data_array and purpose

    def __init__(self,parent=None):
        super(Choosewidget, self).__init__(parent)
        self.initUI()

    def initUI(self):
        self.gif = QMovie('images/progressgif_new.gif')
        self.progress_bar = QLabel()
        self.startBtn = QPushButton("Start", self)
        self.startBtn.clicked.connect(self.startBtnClicked)

        grid = QGridLayout()
        grid.addWidget(self.startBtn, 1, 0,1,5)
        grid.addWidget(self.progress_bar, 0, 1,1,3)
        self.setLayout(grid)
        

    def startBtnClicked(self):
        global pageData
        pageData.clearEncodingData()
        fasta_data,msg=pageData.judge_data(pageData.data)
        if len(msg)>0:
            QMessageBox.about(self, 'Error',msg)
        elif pageData.original_data is not None and len(pageData.original_data)>0 and panelValue.method is not None and len(panelValue.method)>0:
            self.progress_bar.setMovie(self.gif)
            self.gif.start()
            self.startEncoding()
        else:
            QMessageBox.about(self, 'Error', 'Please input your data and selection encoding method!')

    def get_bimethod(self,method,seqType):
        methods=method.sWplit('+')
        method1=methods[0]
        method2=methods[1]
        if seqType=='DNA':
            self.encodingFunc1 = getattr(encoding.DNAEncoding, method1)
            self.encodingFunc2 = getattr(encoding.DNAEncoding, method2)
        elif seqType=='RNA':
            self.encodingFunc1 = getattr(encoding.RNAEncoding, method1)
            self.encodingFunc2 = getattr(encoding.RNAEncoding, method2)
        elif seqType=='Protein':
            self.encodingFunc1 = getattr(encoding.ProteinEncoding, method1)
            self.encodingFunc2 = getattr(encoding.ProteinEncoding, method2)

    def startEncoding(self):
        global panelValue
        global pageData

        
        self.params=panelValue.param
        method=panelValue.method
        data=pageData.original_data
        pageData.encoding_panel=panelValue

        self.startBtn.setDisabled(True)
        print('Begin encoding')
        print(method)
        GeneralMethod=GENERAL_METHOD
        seqType=pageData.type
        try:
            if method in GeneralMethod:
                self.params['Type']=seqType
                if len(data.split('\n'))<1000 and method!='Kmer':
                    pass
                self.encodingFunc = getattr(encoding.GeneralEncoding, method)
            elif seqType=='DNA':
                if method in FeatureFusionMethod:
                    self.get_bimethod(method,seqType)
                else:
                    self.encodingFunc = getattr(encoding.DNAEncoding, method)
                
            elif seqType=='RNA':
                if method in FeatureFusionMethod:
                    self.get_bimethod(method,seqType)
                else:
                    self.encodingFunc = getattr(encoding.RNAEncoding, method)
            elif seqType=='Protein':
                if method in FeatureFusionMethod:
                    self.get_bimethod(method,seqType)
                else:
                    self.encodingFunc = getattr(encoding.ProteinEncoding, method)
        
       
            #set encoding data 大数据文件3.MB出现问题
            if method in FeatureFusionMethod:
                padding_array=[]
                encoding_array=[]
                encoding_header=[]
                vocab={}
                padding_array1,encoding_array1,encoding_header1,vocab1=self.encodingFunc1(data,self.params,'')
                padding_array2,encoding_array2,encoding_header2,vocab2=self.encodingFunc2(data,self.params,'')
                for i in range(len(padding_array1)):
                    padding_array.append(padding_array1[i]+padding_array2[i])
                    encoding_array.append(list(encoding_array1[i][:-1].astype('float'))+list(encoding_array2[i].astype('float')))
                encoding_header=encoding_header1+encoding_header2[2:]
                if type(vocab1)=='dict':
                    vocab=dict( vocab1, **vocab2 )
                else:
                    vocab=list(set.union(set( vocab1) ,set(vocab2 )))
                pageData.padding_array=padding_array
                pageData.encoding_array=np.array(encoding_array)
                pageData.encoding_header=encoding_header
                pageData.vocab=vocab
            else:
                pageData.padding_array,pageData.encoding_array,pageData.encoding_header,pageData.vocab=self.encodingFunc(data,self.params,'')
            # pageData.padding_array,pageData.encoding_array,pageData.encoding_header,pageData.vocab=self.encodingFunc(data,self.params,'')
            if len(pageData.encoding_array)>0 and pageData.encoding_panel.method not in DL_METHOD:
                pageData.encoding_feature_num=len(pageData.encoding_array[0])-1
                pageData.feature_num=pageData.encoding_feature_num
            else:
                pageData.encoding_feature_num=len(pageData.vocab)
                pageData.feature_num=pageData.encoding_feature_num
            pageData.encoding_feature_name=list(pageData.encoding_header[2:])
            if pageData.encoding_panel.method in DL_METHOD:
                pageData.segmentation_frequency=pageData.get_segmentation_frequency(pageData.encoding_array)
            # pageData.encoding_words_frequency
            
            # set result ---> UI
            name=np.array(pageData.sample_name).reshape(-1,1)
            pageData.table_value=pageData.changeArray2table(name,pageData.encoding_array,pageData.data_label)
            self.encoding_signal.emit()
            # set result ---> file

            pageData.encoding_output_filename=pageData.type+'_'+panelValue.method+'_'+getTimeStr()
            self.datatofile_signal.emit(pageData.encoding_output_filename,pageData.encoding_header,pageData.table_value)
            
            self.next_btn_signal.emit(pageData)
            self.progress_bar.clear()
            self.startBtn.setDisabled(False)

            print('End')
        except AttributeError as e:
            QMessageBox.about(self, 'Warning', 'Encoding method is not applicable to this data, please select again.')
                
class StatisticalTextInfo(QWidget):
    """StatisticalTextInfo
    Displays a statistics text box for a dataset.
    Widget:
        textInfo:QTextEdit
    """
    def __init__(self,pattern_full=False,maximumHeight=50):
        super().__init__()
        self.pattern_full=pattern_full
        self.maximumHeight=maximumHeight
        self.initUI()
    def initUI(self):
        '''init'''
        self.setMaximumHeight(self.maximumHeight)
        layout=QGridLayout(self)
        self.textInfo = QTextEdit()
        self.textInfo.setReadOnly(True)
        self.textInfo.setPlainText('')
        if self.pattern_full:
            self.textInfo.setFont(QFont('Arial', 14))
        else:
            self.textInfo.setFont(QFont('Arial', 8))
        layout.addWidget(self.textInfo,0,0)
    def refreshInfo(self,pattern_full=False):
        '''Update text boxes based on data sets'''
        if pattern_full:
            info='[Total data number] :'+str(pageData.data_num)+'\n'+\
                'Training data number : '+str(pageData.data_train_num)+'\nTesting  data number : '+str(pageData.data_test_num)
        else:
            info='[Total data number] :'+str(pageData.data_num)+'   //   '+\
                'Training data number : '+str(pageData.data_train_num)+'   //   Testing  data number : '+str(pageData.data_test_num)
        self.textInfo.setPlainText(info)
        return info

class ResultStatTab(QGroupBox):
    """ResultStatTab
    Displays a statistics text box and graph for a dataset.
    Widget:
        statTextInfo:StatisticalTextInfo
        graphList[]:PlotWidgets.FigureWidget()
                    ['graphLenDistribution','graphLabelDisTrain','graphLabelDisTest']
    """
    def __init__(self):
        super().__init__()
        self.initUI()
    def initUI(self):
        self.grid = QGridLayout(self)
        self.statTextInfo=StatisticalTextInfo()
        self.graphListname=['graphTrLenDistribution','graphTsLenDistribution','graphLabelDisTrain','graphLabelDisTest']
        self.graphList=[]
        self.setNewGraphList()

    def setNewGraphList(self,row=1):
        for name in self.graphListname:
            exec('self.%s=%s'%(name,'PlotWidgets.FigureWidget()'))
            exec('self.%s.append(self.%s)'%('graphList',name))
       
        # for i,graph in enumerate(self.graphList):
        #     self.grid.addWidget(graph,row,i)
        for i in range(0,len(self.graphList),2):
            self.grid.addWidget(self.graphList[i],row+i/2,0,1,1)
            self.grid.addWidget(self.graphList[i+1],row+i/2,1,1,1)
            

    def clear(self):
        self.statTextInfo.textInfo.setPlainText('')
        for i,graph in enumerate(self.graphList):
            self.grid.removeWidget(graph)
            sip.delete(graph)
        self.graphList.clear()
        self.setNewGraphList()
        
    def update_stat(self):

        self.clear()
        self.graphTrLenDistribution.figureCanvas.plotboxplot(pageData.training_dataset,'Train')
        self.graphTsLenDistribution.figureCanvas.plotboxplot(pageData.testing_dataset,'Test')
        self.graphLabelDisTrain.figureCanvas.plotLabelPieChart('Training data label distribution',pageData.data_label,pageData.training_sample_index)
        self.graphLabelDisTest.figureCanvas.plotLabelPieChart('Testing data label distribution',pageData.data_label,pageData.testing_sample_index)

        self.statTextInfo.refreshInfo()
        self.grid.addWidget(self.statTextInfo,0,0,1,2)
        # self.grid.addWidget(PlotWidgets.FigureWidget(),3,0,1,2)


class SegmentationStatTab(QWidget):
    def __init__(self):
        super().__init__()
        self.initUI()
    def initUI(self):
        self.grid = QGridLayout(self)
        self.graph = PlotWidgets.FigureWidget()
        self.grid.addWidget(self.graph,0,0)

    
    def clear(self):
        self.grid.removeWidget(self.graph)
        sip.delete(self.graph)
        self.graph = PlotWidgets.FigureWidget()


    def update_stat_graph(self):
        self.grid.removeWidget(self.graph)
        sip.delete(self.graph)

        self.graph = PlotWidgets.FigureWidget()
        if pageData.segmentation_frequency is not None:
            # num=min(len(list(pageData.segmentation_frequency.keys()),10)
            keys=pageData.segmentation_frequency.keys()
            values=pageData.segmentation_frequency.values()
            fre_num=min(int(len(keys)),MAX_FRE_NUM)
            self.graph.figureCanvas.plotbar(keys,values,'Sequence segmentation frequency (top'+str(fre_num)+')')
        else:
            self.clear()
        self.grid.addWidget(self.graph,0,0)


class ResultWidget(QTabWidget):
    def __init__(self):
        super().__init__()
        self.initUI()
    def initUI(self):
        '''Set tab'''
        self.tab_result_table= QWidget()
        self.tab_encoding_distribution = QWidget()
        self.tab_statistical_info = ResultStatTab()
        # self.tab_segmentation_stat=SegmentationStatTab()
        self.addTab(self.tab_result_table, " Encoding Result / Segmentation Results")
        self.addTab(self.tab_statistical_info, ' Sample Statistics ')
        # self.addTab(self.tab_segmentation_stat, " Sequence Segmentation Statistics ")

        ''''Initialize tab'''
        self.set_tab_result_table()
        # self.set_tab_encoding_distribution()
        # self.set_tab_statistical_info()
    def show_tab_result_table(self):
        self.setCurrentWidget(self.tab_result_table)
    def show_tab_statistical_info(self):
        self.setCurrentWidget(self.tab_statistical_info)
    def set_tab_result_table(self):  
        self.reTable=ResultTable()
        self.downloadWidget=DownloadWidget()
        self.new_segmentationStatTab=SegmentationStatTab()
        grid = QGridLayout()
        grid.addWidget(self.reTable,0,0)
        self.new_segmentationStatTab.setVisible(False)
        grid.addWidget(self.new_segmentationStatTab,2,0)
        grid.addWidget(self.downloadWidget,1,0)
        self.tab_result_table.setLayout(grid)

    def set_tab_encoding_distribution(self):
        self.tab_encoding_distribution.grid = QGridLayout(self.tab_encoding_distribution)
        self.tab_encoding_distribution.plotGraph = PlotWidgets.FigureWidget()
        self.tab_encoding_distribution.grid.addWidget(self.tab_encoding_distribution.plotGraph,0,0)

    def set_new_plotWidget(self):
        self.tab_encoding_distribution.grid.removeWidget(self.tab_encoding_distribution.plotGraph)
        sip.delete(self.tab_encoding_distribution.plotGraph)
        self.tab_encoding_distribution.plotGraph = PlotWidgets.FigureWidget()
        # self.tab_encoding_distribution.plotGraph.plotPieChart(pageData.original_data)
        self.tab_encoding_distribution.grid.addWidget(self.tab_encoding_distribution.plotGraph,0,0)

    def clearData(self):
        self.set_tab_encoding_distribution()
        self.tab_statistical_info.clear()
        self.reTable.updateData([],[],np.array([]))
        self.new_segmentationStatTab.clear()

    def refreshData(self):
        self.reTable.updateData(pageData.encoding_header,pageData.table_value)
        if pageData.segmentation_frequency is not None:
            self.new_segmentationStatTab.setVisible(True)
            self.new_segmentationStatTab.update_stat_graph()
        else:
            self.new_segmentationStatTab.setVisible(False)
    
    # def updateData(self):
    #     self.reTable.updateData(pageData.sample_name,pageData.encoding_header,pageData.encoding_array)



class RightWidget(QWidget,QObject):
    def __init__(self,parent=None):
        super(RightWidget, self).__init__(parent)
        self.initUI()
    def initUI(self):
        self.resultWidget=ResultWidget()
        # self.stateWidget=StateWidget()

        splitter = QSplitter(Qt.Vertical)
        splitter.addWidget(self.resultWidget)
        # splitter.addWidget(self.stateWidget)
        splitter.setSizes([1000, 100])

        #Set grid
        grid = QGridLayout()
        grid.addWidget(self.resultWidget, 0, 0,1,2)
        self.setLayout(grid)
        
    def refreshData(self):
        self.resultWidget.refreshData()

    def clearData(self):
        self.resultWidget.clearData()


class EncodingContentWidget(QWidget):
    
    def __init__(self):
        super().__init__()
        #init PageData
        global pageData
        pageData=PageData()
        self.pageData=pageData
        
        global panelValue
        panelValue=PanelValue()
        self.panelValue=panelValue

        # self.gif = QMovie('images/progress_bar.gif')
        # self.bdata=''

        # global bdata
        # bdata=self.bdata
        
        self.initUI()

    def initUI(self):
        self.inputWidget=InputWidget()
        self.allMethodWidget=AllMethodWidget()
        self.rightWidget=RightWidget()
        

        #set connect
        global panelValue
        panelValue.refresh_signal.connect(self.allMethodWidget.curParamWidget.setMethodandParam)

          
        self.inputWidget.input_signal.connect(self.allMethodWidget.parameterTab.show_tab)
        self.inputWidget.input_signal.connect(self.allMethodWidget.curParamWidget.setType)
        self.inputWidget.input_signal.connect(self.rightWidget.resultWidget.tab_statistical_info.statTextInfo.refreshInfo)
        self.inputWidget.input_signal.connect(self.rightWidget.resultWidget.show_tab_statistical_info)
        self.inputWidget.input_signal.connect(self.rightWidget.resultWidget.clearData)
        self.inputWidget.clear_signal.connect(self.allMethodWidget.clear)
        self.inputWidget.clear_signal.connect(self.rightWidget.clearData)

        # self.inputWidget.input_signal.connect(self.rightWidget.resultWidget.set_new_plotWidget)
        self.inputWidget.input_signal.connect(self.rightWidget.resultWidget.tab_statistical_info.update_stat)
        # self.inputWidget.input_signal.connect(self.rightWidget.resultWidget.tab_statistical_info.update_stat_graph)
        
        self.allMethodWidget.chooseWidget.encoding_signal.connect(self.rightWidget.refreshData)
        self.allMethodWidget.chooseWidget.encoding_signal.connect(self.rightWidget.resultWidget.show_tab_result_table)
        # self.allMethodWidget.chooseWidget.encoding_signal.connect(self.rightWidget.resultWidget.new_segmentationStatTab.update_stat_graph)
        # self.allMethodWidget.chooseWidget.encoding_signal.connect(self.rightWidget.resultWidget.tab_segmentation_stat.update_stat_graph)
        self.allMethodWidget.chooseWidget.datatofile_signal.connect(self.rightWidget.resultWidget.downloadWidget.setFile)
        
        #set layout
        layout = QVBoxLayout()

        splitter_left0 = QSplitter(Qt.Vertical)
        splitter_left0.addWidget(self.inputWidget)
        splitter_left0.addWidget(self.allMethodWidget)
        splitter_left0.setSizes([1000, 900])



        splitter = QSplitter(Qt.Horizontal)
        splitter.addWidget(splitter_left0)
        splitter.addWidget(self.rightWidget)
        splitter.setSizes([10, 1000])

        layout.addWidget(splitter)
        self.setLayout(layout)
    def setdata(self,data):
        global pageData
        pageData=PageData()
        self.pageData=data
        # self.bdata=data
        # global bdata
        # bdata=self.bdata