from Const import MAX_FRE_NUM
from matplotlib.figure import Figure
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.backends.backend_qt5 import NavigationToolbar2QT
from scipy.interpolate import make_interp_spline
from PyQt5.QtWidgets import QWidget,QVBoxLayout,QHBoxLayout
import sip
import numpy as np


class FigureWidget(QWidget):
    def __init__(self):
        super(FigureWidget, self).__init__()
        self.initUI()
    def mouseDoubleClickEvent(self, QMouseEvent):
           if self.isFullScreen():
              print("!fullScreen")
              self.showNormal()
           else:
              print("fullScreen")
              self.showFullScreen()
    def initUI(self):
        # self.setWindowTitle('iLearnPlus Histogram')
        # self.setWindowIcon(QIcon('images/logo.ico'))
        # self.resize(800, 600)
        layout = QVBoxLayout(self)
        self.figureCanvas = MyFigure()
        layout.addWidget(self.figureCanvas)
        self.navigationToolbar = NavigationToolbar2QT(self.figureCanvas, self)
        hLayout = QHBoxLayout()
        hLayout.addStretch(1)
        hLayout.addWidget(self.navigationToolbar)
        hLayout.addStretch(1)
        layout.addLayout(hLayout)

class MyFigure(FigureCanvas):
    def __init__(self,width=5, height=4, dpi=100,is_dyn=False):
    # def __init__(self,width=2, height=1, dpi=300,is_dyn=False):
        self.fig = Figure(figsize=(width, height), dpi=dpi)
        self.is_dyn=is_dyn
        super(MyFigure,self).__init__(self.fig)
        self.axes = self.fig.add_subplot(111)
        if self.is_dyn:
            self.axes.ion()

    def plotsin(self):
        
        t = np.arange(0.0, 3.0, 0.01)
        s = np.sin(2 * np.pi * t)
        self.axes.plot(t, s)

    def generate_dict(self,data):
        data_dict = {}
        for key in data:
            data_dict[key] = data_dict.get(key, 0) + 1
        return data_dict
    def plotEmbed(self,embedded,label,title=''):
        from matplotlib import colors
        self.axes.scatter(embedded[:, 0], embedded[:, 1],c=list(colors.XKCD_COLORS.values())[:len(embedded)],label=label)
        self.axes.set_title(title)
        self.axes.axis('off')

    def plotKmeans(self,X,C_i,centers,k=10,name=None,title=''):
        
        self.axes.scatter(X[:,0],X[:,1],c=C_i)
        self.axes.scatter(centers[:,0],centers[:,1],marker='*',s=60)
        if name is not None:
            for i in range(len(X)):
                self.axes.annotate(name[i],(X[i,0],X[i,1]))
        self.axes.set_title(title)
        self.axes.axis('off')

    def plotLabelPieChart(self,title,data,index):
        import numpy as np
        data_label=np.array(data)[index].tolist()
        data_label_dict=self.generate_dict(data_label)
 
        self.plotPieChart(self.axes,title,data_label_dict)

    def plotPieChart(self,axes,title,data_dict):

        axes.set_title(title)
        axes.pie(data_dict.values(),
        labels=data_dict.keys(),
        autopct= '%1.2f' ,
        startangle= 90 )
        

    def plotRocCurves(self,Datas):
        if Datas!=None:
            n=len(Datas)

            for i in range(n):
                Data=Datas[i]
                label=Data[0]
                data=Data[1]
                fpr_values=data['fpr'].values
                tpr_values=data['tpr'].values
                self.plotCurve(fpr_values,tpr_values,label)
            self.axes.legend()

    def plotPrcCurves(self,Datas):
        if Datas!=None:
            n=len(Datas)

            for i in range(n):
                Data=Datas[i]
                label=Data[0]
                data=Data[1]
                recall_values=data['recall'].values
                precision_values=data['precision'].values
                self.plotCurve(recall_values,precision_values,label)
            self.axes.legend()

    def get_smooth_x_y(self,x,y,num=500):
        return x,y
        # x_new = np.linspace(np.min(x),np.max(x),num)
        # x_y_pair=dict(zip(x,y))
        # y_smooth = make_interp_spline(list(x_y_pair.keys()),list(x_y_pair.values()))(x_new)
        # return x_new,y_smooth
    def plotCurve(self,x,y,label=''):
        
        self.axes.set_xticks(np.array([0.0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0]))
        self.axes.set_yticks(np.array([0.0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0]))
        x,y=self.get_smooth_x_y(x,y)
        self.axes.plot(x, y,label=label)
    
    def plotEpochCurve(self,alldata,title='',labelList=[''],isFold=True):

        self.axes.set_title(title)
        self.axes.set_xlabel('epoch')
        for i,data in enumerate(alldata):
            x=list(range(len(data)))
            y=data
            x,y=self.get_smooth_x_y(x,y)
            self.axes.plot(x, y,label='Fold'+str(i) if isFold else labelList[i])
        self.axes.legend()

    # def plotbox2plot(self,training_dataset,testing_dataset):
    #     import numpy as np
    #     all_len=[]
    #     mean=[]
    #     std=[]
    #     index_ls = []
    #     train_len_same=False
    #     test_len_same=False
    #     if training_dataset is not None:
    #         index_ls.append('Training data')
            
    #         train_data_len=[len(i) for i in training_dataset[1]]
    #         all_len.append(train_data_len)
    #         mean.append(np.mean(train_data_len))
    #         std.append(np.std(train_data_len))
    #         train_len_same=(np.array(train_data_len)==mean)

    #     if testing_dataset is not None:
    #         index_ls.append('Testing data')
    #         test_data_len=[len(i) for i in testing_dataset[1]]
    #         all_len.append(test_data_len)
    #         mean.append(np.mean(test_data_len))
    #         std.append(np.std(test_data_len))

    #     scale_ls = range(len(index_ls))

        
    #     self.axes.set_xlim([-0.5,1.5])
    #     self.axes.set_xticks(scale_ls,index_ls)
        
        
    #     all_smae=[]
    #     for tmean,tlen in zip(mean,all_len):
    #         same=[t==tmean for t in tlen]
    #         all_smae.append(np.sum(same)==len(tlen))

    #     if np.sum(all_smae)==len(mean):
    #         self.axes.bar(index_ls,mean)
    #         self.axes.set_title('Sequence length diagram')
    #     else:
    #         self.axes.set_xticks([1,2], ['x1', 'x2']) 
    #         self.axes.boxplot([train_data_len,test_data_len],
    #             notch=False, # box instead of notch shape
    #             sym='rs',    # red squares for outliers
    #             vert=True)   # vertical box aligmnent
    #         # self.axes.set_xticks([1,2], ['x1', 'x2'])
    #         self.axes.set_xticks([1,2], ['x1', 'x2'])
    #         self.axes.set_title('Sequence length mean variance \ndistribution diagram')
    def plotboxplot(self,training_dataset,type='Train'):
        import numpy as np
        all_len=[]
        mean=[]
        std=[]
        index_ls = []
        train_len_same=False
        if training_dataset is not None:
            index_ls.append(type+'ing data')
            
            train_data_len=[len(i) for i in training_dataset[1]]
            all_len.append(train_data_len)
            mean.append(np.mean(train_data_len))
            std.append(np.std(train_data_len))
            train_len_same=(np.array(train_data_len)==mean)
        else:
            return

        scale_ls = range(len(index_ls))

        
        self.axes.set_xlim([-0.5,1.5])
        self.axes.set_xticks(scale_ls,index_ls)
        
        
        all_smae=[]
        for tmean,tlen in zip(mean,all_len):
            same=[t==tmean for t in tlen]
            all_smae.append(np.sum(same)==len(tlen))

        # if np.sum(all_smae)==len(mean):
        #     self.axes.bar(index_ls,mean)
        #     self.axes.set_xticks([1], ['x1'])
        #     self.axes.set_title('Sequence length diagram')
        # else:
        #     # self.axes.set_xticks([1,2], ['x1', 'x2']) 
        #     self.axes.boxplot([train_data_len],
        #         notch=False, # box instead of notch shape
        #         sym='rs',    # red squares for outliers
        #         vert=True)   # vertical box aligmnent
        #     # self.axes.set_xticks([1,2], ['x1', 'x2'])
        #     # self.axes.set_xticks([1,2], ['x1', 'x2'])
        #     self.axes.set_title(type+': Sequence length distribution diagram')
        self.axes.boxplot([train_data_len],
                notch=False, # box instead of notch shape
                sym='rs',    # red squares for outliers
                vert=True,
                showmeans=True 
                )   # vertical box aligmnent
            # self.axes.set_xticks([1,2], ['x1', 'x2'])
            # self.axes.set_xticks([1,2], ['x1', 'x2'])
        self.axes.set_xticks([])
        self.axes.grid(ls="--")
        self.axes.set_title(type+': Sequence length distribution diagram')
    def plotErrorBar(self,training_dataset,testing_dataset):
        import numpy as np
        all_len=[]
        mean=[]
        std=[]
        index_ls = []
        train_len_same=False
        test_len_same=False
        if training_dataset is not None:
            index_ls.append('Training data')
            
            train_data_len=[len(i) for i in training_dataset[1]]
            all_len.append(train_data_len)
            mean.append(np.mean(train_data_len))
            std.append(np.std(train_data_len))
            train_len_same=(np.array(train_data_len)==mean)

        if testing_dataset is not None:
            index_ls.append('Testing data')
            test_data_len=[len(i) for i in testing_dataset[1]]
            all_len.append(test_data_len)
            mean.append(np.mean(test_data_len))
            std.append(np.std(test_data_len))

        scale_ls = range(len(index_ls))

        
        
        self.axes.set_xlim([-0.5,1.5])
        self.axes.set_xticks(scale_ls,index_ls)
        
        
        all_smae=[]
        for tmean,tlen in zip(mean,all_len):
            same=[t==tmean for t in tlen]
            all_smae.append(np.sum(same)==len(tlen))

        if np.sum(all_smae)==len(mean):
            self.axes.bar(index_ls,mean)
            self.axes.set_title('Sequence length diagram')
        else:    
            self.axes.errorbar(index_ls,mean, yerr=std, fmt="o")
            self.axes.set_title('Sequence length mean variance \ndistribution diagram')

    def plotbar(self,keys,values,title,x_max_num=MAX_FRE_NUM):
        
        
        # self.axes.set_xticks(np.array([0.0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0]))
        # self.axes.set_yticks(np.array([0.0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0]))
        self.axes.bar(list(keys)[:x_max_num],list(values)[:x_max_num])
        self.axes.set_title(title)
    def plotRocCurve(self):
        pass
    def plotPrcCurve(self):
        pass
