from pandas.core.base import NoNewAttributesMixin
from InputDialog import BaggingInputDialog, DLInputDialog, KNeighborsInputDialog, LGBMInputDialog, RandomForestInputDialog, SVMInputDialog
from Const import DEFAULT_FOLD, DL_METHOD, DL_MODEL, TEST_RATIO, TRAIN_RATIO, TRAIN_TEST_RAIR_NUM
from CommonClass import PageData, PanelValue
from math import e
import sys

from sklearn import model_selection
from util.commonUtil import str2param
from util.pyqtUtil import getIntLineEdit
from CommonWidget import CollapsibleBox, StateWidget,DownloadWidget,ResultTable
import csv
import os
import numpy as np
from PyQt5.QtGui import QIcon,QFont,QStandardItemModel,QStandardItem,QMovie
from PyQt5.QtWidgets import (QLineEdit,QScrollArea,QGroupBox,QWidget,QTabWidget,QLabel,QTextEdit,QPushButton,QSplitter,QLineEdit,QTableWidgetItem,
                              QFormLayout,QMainWindow,QDesktopWidget,QApplication,QGridLayout,QTableWidget,QAbstractItemView,
                                QAction,QMessageBox,QMenu,qApp,QFileDialog,QRadioButton,QTableView,QHeaderView,QVBoxLayout)
from PyQt5.QtCore import QObject,Qt,pyqtSignal
from PyQt5.QtGui import QIntValidator
import feature_selection.feature_selection
import threading
import pandas as pd
import model_selection.ML_model
import model_selection.DL_model
from model_selection.DL_model import DL_model
import PlotWidgets
import sip
from time import *

global pageData
global panelValue

class ModelParamWidget(QWidget):
    def __init__(self,method,parent=None):
        # super(ModelParamWidget, self).__init__(parent)
        super().__init__()
        self.method=method
        self.all_para={}
        self.initUI()
    def initUI(self):
        formLayout=QFormLayout()

        btnWidget=QWidget()
        btngrid=QGridLayout(btnWidget)
        confirmBtn = QPushButton(self.method, self)
        confirmBtn.clicked.connect(self.confirmBtnClicked)
        btngrid.addWidget(confirmBtn,0,0)

        
        formLayout.addRow(confirmBtn)
        
        self.setLayout(formLayout)

    def confirmBtnClicked(self):
        
        global panelValue
        if self.method in DL_MODEL:
            param, ok = DLInputDialog.getValues(self.method,pageData.feature_num) 
        else:
            if self.method=='Bagging':
                param, ok = BaggingInputDialog.getValues(self.method,pageData.feature_num)
            elif self.method=='KNeighbors':
                param,ok=KNeighborsInputDialog.getValues(self.method,pageData.feature_num)
            elif self.method=='LGBM':
                param,ok=LGBMInputDialog.getValues(self.method,pageData.feature_num)
            elif self.method=='RandomForest':
                param,ok=RandomForestInputDialog.getValues(self.method,pageData.feature_num)
            elif self.method=='SVM':
                param,ok=SVMInputDialog.getValues(self.method,pageData.feature_num)
            else:
                param, ok={},True
        # param={}
        # for key, value in self.all_para.items():
        #     param[key]=value.text()
        if ok:
            panelValue.refreshData(self.method,param)

        
    def getIntLineEdit(self):
        edit1=QLineEdit()
        edit1.setValidator(QIntValidator())
        edit1.setMaxLength(4)
        edit1.setAlignment(Qt.AlignRight)
        edit1.setFont(QFont('Arial',10))
        return edit1

class SplitParamWidget(QWidget):
    def __init__(self,method,parent=None):
        # super(SplitParamWidget, self).__init__(parent)
        super().__init__()
        self.method=method
        self.all_para={}
        self.initUI()
    def initUI(self):

        formLayout=QFormLayout()
        
        self.traindit=self.getIntLineEdit()
        self.traindit.setPlaceholderText("Please enter an integer")
        self.testedit=self.getIntLineEdit()
        self.testedit.setPlaceholderText("Please enter an integer")
        self.numedit=self.getIntLineEdit()
        self.numedit.setPlaceholderText("Number of train/test pair")
                
        self.all_para={}
        if self.method == 'StratifiedShuffleSplit':
            formLayout.addRow('Train',self.traindit)
            self.all_para['train_ratio']=self.traindit
            self.traindit.setText(str(TRAIN_RATIO))
            formLayout.addRow('Test',self.testedit)
            self.all_para['test_ratio']=self.testedit
            self.testedit.setText(str(TEST_RATIO))
            self.all_para['method_value']=self.numedit
            self.numedit.setText(str(TRAIN_TEST_RAIR_NUM))
            formLayout.addRow('Number',self.numedit)
        
        btnWidget=QWidget()
        btngrid=QGridLayout(btnWidget)
        confirmBtn = QPushButton("Confirm", self)
        confirmBtn.clicked.connect(self.confirmBtnClicked)
        btngrid.addWidget(confirmBtn,0,0)

        
        formLayout.addRow(confirmBtn)
        
        self.setLayout(formLayout)

    def confirmBtnClicked(self):
        global panelValue
        param={}
        if self.method=='LeaveOneOut':
            param['method_value']=str(pageData.data_train_num)
        for key, value in self.all_para.items():
            param[key]=value.text()
        panelValue.refreshDivisionData(self.method,param)

    def getIntLineEdit(self):
        edit1=QLineEdit()
        edit1.setValidator(QIntValidator())
        edit1.setMaxLength(4)
        edit1.setAlignment(Qt.AlignRight)
        edit1.setFont(QFont('Arial',10))
        return edit1


class KFoldTab(QWidget):
    def __init__(self, *args, **kwargs):
        super(KFoldTab, self).__init__(*args, **kwargs)
        self.setMinimumHeight(320)
        self.setMinimumHeight(350)
        self.initUI()
    def initUI(self):
        self.method=DEFAULT_FOLD

        vlay = QVBoxLayout(self)
        scroll = QScrollArea()
        vlay.addWidget(scroll)
        content = QWidget()
        scroll.setWidget(content)
        scroll.setWidgetResizable(True)
        vlay = QVBoxLayout(content)

        self.radioWidget=QWidget()
        m1Title = QLabel('KFold')
        m1Title.setFont(QFont('Arial', 9))
        m1Btn=QRadioButton()
        # m1Btn.setChecked(True)
        m1Btn.clicked.connect(lambda:self.setMethodClicked('KFold'))

        m2Title = QLabel('StratifiedKFold')
        m2Title.setFont(QFont('Arial', 9))
        
        m2Btn=QRadioButton()
        m2Btn.setChecked(True)
        m2Btn.clicked.connect(lambda:self.setMethodClicked('StratifiedKFold'))

        radiogrid=QGridLayout(self.radioWidget)
        radiogrid.addWidget(m1Title,0,3)
        radiogrid.addWidget(m1Btn,0,2)
        radiogrid.addWidget(m2Title,0,1)
        radiogrid.addWidget(m2Btn,0,0)

        self.crossWidget=QWidget()
        crosslayout=QFormLayout(self.crossWidget)
        self.cross_edit=self.getIntLineEdit()
        self.cross_edit.setPlaceholderText("Please enter an integer")
        self.cross_edit.setText('5')
        crosslayout.addRow('Cross-validation',self.cross_edit)

        self.confirmBtn = QPushButton("Confirm", self)
        self.confirmBtn.clicked.connect(self.confirmBtnClicked)

        vlay.addWidget(self.radioWidget)
        vlay.addWidget(self.crossWidget)
        vlay.addWidget(self.confirmBtn)


        
        vlay.addStretch()
    def getIntLineEdit(self):
        edit1=QLineEdit()
        edit1.setValidator(QIntValidator())
        edit1.setMaxLength(4)
        edit1.setAlignment(Qt.AlignRight)
        edit1.setFont(QFont('Arial',9))
        return edit1
    def setMethodClicked(self,method):
        self.method=method

    def confirmBtnClicked(self):
        global panelValue
        param={}
        param['method_value']=self.cross_edit.text()
        panelValue.refreshDivisionData(self.method,param)

class OtherTab(QWidget):
    def __init__(self, *args, **kwargs):
        super(OtherTab, self).__init__(*args, **kwargs)
        self.setMinimumHeight(320)
        self.setMinimumHeight(350)
        self.initUI()
    def initUI(self):
        vlay = QVBoxLayout(self)
        scroll = QScrollArea()
        vlay.addWidget(scroll)
        content = QWidget()
        scroll.setWidget(content)
        scroll.setWidgetResizable(True)
        vlay = QVBoxLayout(content)

        #set item
        box1 = CollapsibleBox("LeaveOneOut")
        lay = QVBoxLayout()
        lay.addWidget(SplitParamWidget('LeaveOneOut'))
        box1.setContentLayout(lay)

        #set item
        box2 = CollapsibleBox("StratifiedShuffleSplit")
        lay = QVBoxLayout()
        lay.addWidget(SplitParamWidget('StratifiedShuffleSplit'))
        box2.setContentLayout(lay)

 
        vlay.addWidget(box1)
        vlay.addWidget(box2)

        
        vlay.addStretch()

class DataSplitTab(QTabWidget):
    def __init__(self):
        super().__init__()
        self.initUI()
        # self.setMaximumHeight(250)
    def initUI(self):
        '''Add subQWidget '''
        self.tab_KFold = QWidget()
        self.tab_Other = QWidget()
        self.addTab(self.tab_KFold, "KFold ")
        self.addTab(self.tab_Other, "Other ")
        
        '''Initialize tabWidget'''
        self.set_KFold()
        self.set_tab_Other()

    def set_KFold(self):
        layout = QVBoxLayout()
        self.main_tab_KFold = KFoldTab()
        layout.addWidget(self.main_tab_KFold)
        self.tab_KFold.setLayout(layout)
        pass

    def set_tab_Other(self):
        layout = QVBoxLayout()
        self.main_tab_other = OtherTab()
        layout.addWidget(self.main_tab_other)
        self.tab_Other.setLayout(layout)


class DataWidget(QWidget):
    def __init__(self):
        super().__init__()
        self.initUI()
    def initUI(self):
        # data
        # dataBox = QGroupBox('Current dataset', self)
        # dataBox.setFont(QFont('Arial', 10))
        # dataBox.setMinimumHeight(80)
        # dataBoxLayout = QGridLayout()
        # self.datainfo=QLabel('')
        # # self.datainfo.setText('OK')
        # dataBoxLayout.addWidget(self.datainfo, 2, 0, 1, 2)
        # dataBox.setLayout(dataBoxLayout)
        
        # data method
        self.dataDivisionTab=DataSplitTab()
        self.dataDivisionTab.setMinimumHeight(200)
        # dataMethodBox = QGroupBox('Dataset division', self)
        # dataMethodBox.setFont(QFont('Arial', 10))
        # dataMethodBox.setMinimumHeight(200)
        

        # dataMethodBoxLayout = QGridLayout()
        # dataMethodBoxLayout.addWidget(self.dataDivisionTab, 0, 0, 1, 2)
        # dataMethodBox.setLayout(dataMethodBoxLayout)
        grid = QGridLayout()

        
        # grid.addWidget(dataBox, 0, 0,1,1)
        # grid.addWidget(dataMethodBox, 1, 0,1,1)
        grid.addWidget(self.dataDivisionTab, 1, 0,1,1)
        self.setLayout(grid)


    
class CurParamWidget(QGroupBox):
    def __init__(self):
        super().__init__()
        self.initUI()
    def initUI(self):
        self.setMaximumHeight(150)
        self.setFont(QFont('Arial', 10))
        paraLayout = QFormLayout(self)
        
        self.dataDivisionLineEdit = QLineEdit()
        self.dataDivisionLineEdit.setFont(QFont('Arial', 8))
        self.dataDivisionLineEdit.setReadOnly(True)

        self.modelLineEdit = QLineEdit()
        self.modelLineEdit.setFont(QFont('Arial', 8))
        self.modelLineEdit.setReadOnly(True)
        
        self.paraLineEdit = QLineEdit()
        self.paraLineEdit.setFont(QFont('Arial', 8))
        self.paraLineEdit.setReadOnly(True)

        paraLayout.addRow('Data division:', self.dataDivisionLineEdit)
        paraLayout.addRow('Model:', self.modelLineEdit)
        paraLayout.addRow('Parameter(s):', self.paraLineEdit)
    
    def refresh_division_param(self):
        data={}
        data['method']=panelValue.division_method
        if len(panelValue.division_param)>0:
            data['method_value']=panelValue.division_param['method_value']
        self.dataDivisionLineEdit.setText(panelValue.dict2text(data))
    def refresh_model_param(self):
        self.modelLineEdit.setText(panelValue.method)
        self.paraLineEdit.setText(panelValue.dict2text(panelValue.param))

class TabML(QWidget):
    def __init__(self, *args, **kwargs):
        super(TabML, self).__init__(*args, **kwargs)
        self.initUI()
    def initUI(self):
        vlay = QVBoxLayout(self)
        scroll = QScrollArea()
        vlay.addWidget(scroll)
        content = QWidget()
        scroll.setWidget(content)
        scroll.setWidgetResizable(True)
        vlay = QVBoxLayout(content)

        # ModelParamWidget
        btn1 = QPushButton("Ok", self)
        btn1.clicked.connect(self.btnClicked)

        #set item
        box1 = CollapsibleBox("AdaBoost")
        lay = QVBoxLayout()
        lay.addWidget(ModelParamWidget('AdaBoost'))
        lay.addWidget(btn1)
        box1.setContentLayout(lay)

        #set item
        box2 = CollapsibleBox("Bagging")
        lay = QVBoxLayout()
        lay.addWidget(ModelParamWidget('Bagging'))
        box2.setContentLayout(lay)

        # #set item
        # box3 = CollapsibleBox("SentencePiece  (DL encoding method)")
        # lay = QVBoxLayout()
        # lay.addWidget(CommonParamWidget('SentencePiece'))
        # box3.setContentLayout(lay)

        # #set item
        # box4 = CollapsibleBox("WordPiece      (DL encoding method)")
        # lay = QVBoxLayout()
        # lay.addWidget(CommonParamWidget('WordPiece'))
        # box4.setContentLayout(lay)

        vlay.addWidget(ModelParamWidget('AdaBoost'))
        vlay.addWidget(ModelParamWidget('Bagging'))
        vlay.addWidget(ModelParamWidget('DecisionTree'))
        vlay.addWidget(ModelParamWidget('GaussianNB'))
        vlay.addWidget(ModelParamWidget('KNeighbors'))
        vlay.addWidget(ModelParamWidget('LGBM'))
        vlay.addWidget(ModelParamWidget('LogisticRegression'))
        vlay.addWidget(ModelParamWidget('RandomForest'))
        vlay.addWidget(ModelParamWidget('SVM'))
        # vlay.addWidget(ModelParamWidget('Bagging'))
        # vlay.addWidget(box1)
        # vlay.addWidget(box2)
        # vlay.addWidget(box3)
        # vlay.addWidget(box4)

        
        vlay.addStretch()
    def btnClicked(self,btnname):
        print(btnname)

class TabDL(QWidget):
    def __init__(self, *args, **kwargs):
        super(TabDL, self).__init__(*args, **kwargs)
        self.initUI()
    def initUI(self):
        vlay = QVBoxLayout(self)
        scroll = QScrollArea()
        vlay.addWidget(scroll)
        content = QWidget()
        scroll.setWidget(content)
        scroll.setWidgetResizable(True)
        vlay = QVBoxLayout(content)

        #set item
        box1 = CollapsibleBox("CNN")
        lay = QVBoxLayout()
        lay.addWidget(ModelParamWidget('CNN'))
        lay.addWidget(ModelParamWidget('CNN_Simple_Attention'))
        lay.addWidget(ModelParamWidget('CNN_Multihead_Attention'))
        box1.setContentLayout(lay)

        #set item
        box2 = CollapsibleBox("RNN")
        lay = QVBoxLayout()
        lay.addWidget(ModelParamWidget('RNN'))
        lay.addWidget(ModelParamWidget('RNN_Simple_Attention'))
        lay.addWidget(ModelParamWidget('RNN_Multihead_Attention'))
        box2.setContentLayout(lay)

        #set item
        box3 = CollapsibleBox("LSTM")
        lay = QVBoxLayout()
        lay.addWidget(ModelParamWidget('LSTM'))
        box3.setContentLayout(lay)

        #set item
        box4 = CollapsibleBox("GRU")
        lay = QVBoxLayout()
        lay.addWidget(ModelParamWidget('GRU'))
        box4.setContentLayout(lay)
        
        #set item
        box5 = CollapsibleBox("Attention")
        lay = QVBoxLayout()
        lay.addWidget(ModelParamWidget('Attention'))
        box5.setContentLayout(lay)

        #set item
        box6 = CollapsibleBox("MLP")
        lay = QVBoxLayout()
        lay.addWidget(ModelParamWidget('MLP'))
        box6.setContentLayout(lay)
        vlay.addWidget(box1)
        vlay.addWidget(box2)
        vlay.addWidget(box3)
        vlay.addWidget(box4)
        vlay.addWidget(box5)
        vlay.addWidget(box6)

        
        vlay.addStretch()
class AllModelTab(QTabWidget):
    def __init__(self):
        super().__init__()
        self.setMinimumHeight(200)
        self.initUI()
    def initUI(self):
        '''Add subQWidget '''
        self.tab_ML = QWidget()
        self.tab_DL = QWidget()
        self.addTab(self.tab_ML, "ML Model ")
        self.addTab(self.tab_DL, "DL Model ")

        '''Initialize tabWidget'''
        self.set_tab_ML()
        self.set_tab_DL()

    def set_tab_ML(self):
        layout = QVBoxLayout()
        self.main_tab_ML = TabML()
        layout.addWidget(self.main_tab_ML)
        self.tab_ML.setLayout(layout)

    def set_tab_DL(self):
        layout = QVBoxLayout()
        self.main_tab_DL = TabDL()
        layout.addWidget(self.main_tab_DL)
        self.tab_DL.setLayout(layout)

        

class AllMethodWidget(QTabWidget):
    def __init__(self):
        super().__init__()
        self.initUI()
    def initUI(self):
        self.setMinimumWidth(320)
        self.setMaximumWidth(480)
        self.dataWidget=DataWidget()
        self.curParaWidget=CurParamWidget()
        self.allModelWidget=AllModelTab()
        self.chooseWidget=Choosewidget()#修改的部分

        grid = QGridLayout()
        # grid.addWidget(self.allModelWidget, 0, 0,1,1)
        # grid.addWidget(self.dataWidget, 1, 0,1,1) 
        
        bottomWidget=QWidget()
        grid1 = QGridLayout(bottomWidget)
        grid1.addWidget(self.dataWidget, 0, 0,1,1) 
        grid1.addWidget(self.curParaWidget, 1, 0,1,1)
        grid1.addWidget(self.chooseWidget, 2, 0,1,1)

        splitter = QSplitter(Qt.Vertical)
        splitter.addWidget(self.allModelWidget)
        splitter.addWidget(bottomWidget)
        splitter.setSizes([10, 1000])

        # grid.addWidget(self.curParaWidget, 2, 0,1,1)
        # grid.addWidget(self.chooseWidget, 3, 0,1,1)
        grid.addWidget(splitter, 0, 0,1,1)
        self.setLayout(grid)

        
class Choosewidget(QWidget,QObject):
    # ML signal
    outputData_signal = pyqtSignal(object,object,object)#input signal -> output file data
    training_score_signal = pyqtSignal(object,object,object)
    testing_score_signal = pyqtSignal(object,object,object)
    embed_signal = pyqtSignal(object,object,object)
    dl_ts_result_signal= pyqtSignal(object,object,object)
    roc_prc_signal=pyqtSignal(object)
    dl_acc_signal=pyqtSignal(object)
    dl_loss_signal=pyqtSignal(object)
    dl_sn_sp_signal=pyqtSignal(object)
    dl_roc_prc_signal=pyqtSignal(object)
    # dl_embed_signal=pyqtSignal(object)# draw embed
    # roc_signal=pyqtSignal(object)# draw roc signal
    # prc_signal=pyqtSignal(object)# draw prc signal

    outputData2file_signal= pyqtSignal(object,object,object)
    training_score2file_signal= pyqtSignal(object,object,object)
    testing_score2file_signal= pyqtSignal(object,object,object)
    embed2file_signal= pyqtSignal(object,object,object)
    dl_ts_result2file_signal= pyqtSignal(object,object,object)
    # DL signal

    # Common signal
    set_result_content_signal=pyqtSignal()
    pre_signal=pyqtSignal(object)#set data to pre module
    next_btn_signal=pyqtSignal(object)
    

    def __init__(self,parent=None):
        super(Choosewidget, self).__init__(parent)
        self.is_pred=False
        self.initUI()

    def initUI(self):
        self.gif = QMovie('images/progressgif_new.gif')
        self.progress_bar = QLabel()
        
        self.startBtn = QPushButton("Start", self)
        self.startBtn.clicked.connect(self.startBtnClicked)


        self.predBtn = QPushButton("Load existing model predictions", self)
        self.predBtn.clicked.connect(self.predBtnClicked)
        
        # self.stopBtn = QPushButton("Stop", self)
        # self.stopBtn.clicked.connect(self.stopBtnClicked)
        # self.stopBtn.setVisible(False)

        self.saveBtn = QPushButton("Save model", self)
        self.saveBtn.clicked.connect(self.saveBtnClicked)
        # self.saveBtn.setVisible(False)
        
        self.stateWidget=StateWidget()
        grid = QGridLayout()
        
        grid.addWidget(self.progress_bar, 0, 0,1,1)
        grid.addWidget(self.startBtn, 1, 0,1,1)
        grid.addWidget(self.saveBtn, 2, 0,1,1)
        grid.addWidget(self.predBtn, 3, 0,1,1)
        # grid.addWidget(self.stopBtn, 3, 0,1,1)

        self.setLayout(grid)
        
    # def stopBtnClicked(self):
    #     self.t.join()
    #     self.progress_bar.clear()
    #     self.startBtn.setDisabled(False)
    #     # self.stopBtn.setVisible(False)

        

    def saveBtnClicked(self):
        import torch
        if pageData.best_model_state_dict is not None:
            fname,ok= QFileDialog.getSaveFileName(self, 'Save file',pageData.model_save_path,'pth(*.pth)')
            if fname:
                torch.save(pageData.best_model_state_dict, fname)                    
                QMessageBox.about(self,'Success',"Model saved successfully.")
        else:
            QMessageBox.about(self,'Error',"The model is empty.")
    def predBtnClicked(self):
        self.startBtnClicked(is_pred=True)
    def startBtnClicked(self,is_pred=False):
        sender = self.sender()
        btn_type=sender.text()
        global pageData
        global panelValue

        if btn_type=='Stop':
            # self.t._stop_event.set()
            # self.t._stop_event.clear() 
            # self.startBtn.setText('Start')
            # self.predBtn.setDisabled(False)
            # self.saveBtn.setDisabled(False)
            pass
        else:
            # self.startBtn.setText('Stop')
            model=panelValue.method
            division=panelValue.division_method
            if is_pred==False:
                if pageData.training_dataset is not None and len(model)>0 and len(division)>0:
                    if int(panelValue.division_param['method_value'])<2:
                        QMessageBox.about(self, 'Error', 'The input fold must be greater than or equal to 2.')
                    else:
                        flag1 =panelValue.method in DL_MODEL and pageData.encoding_panel.method in DL_METHOD
                        flag2 =panelValue.method not in DL_MODEL and pageData.encoding_panel.method not in DL_METHOD
                        if flag1 or flag2:
                            self.progress_bar.setMovie(self.gif)
                            self.gif.start()
                            # self.stopBtn.setVisible(True)
                            self.t = threading.Thread(target=self.start)
                            self.t._stop_event = threading.Event()
                            self.t.start()
                            
                        else:
                            QMessageBox.about(self, 'Error', 'Note that machine learning ,deep learning models can only be applied to one\'s own encoding method!')
                else:
                    QMessageBox.about(self, 'Error', 'Please input your data and selection method!')
            else:
                if pageData.training_dataset is not None and 'model_state_dict_path' in panelValue.param.keys() and len(panelValue.param['model_state_dict_path'])>0:
                    self.is_pred=is_pred
                    self.t = threading.Thread(target=self.start())
                    self.t.start()
                else:
                        QMessageBox.about(self, 'Error', 'Please load the model through DLTab and click again.')
                
    def refresh_dl_data(self,log_eval,log_train,test_metrics,best_evalscore,curbest_model):
        tr_eval_metrics_matrix,tr_tr_metrics_matrix,test_metrics,best_evalacc,pageData.best_model_state_dict=log_eval,log_train,test_metrics,best_evalscore,curbest_model
        test_metrics_table_value=model_selection.DL_model.Metrics.getMetricsTable({'Test':test_metrics},False)
        pageData.test_metrics_table_value=test_metrics_table_value
        prefix_file=pageData.type+'_'+pageData.encoding_panel.method+'_'+pageData.model_selection_panel.method+'_'

        if self.is_pred==False:
            pageData.best_evalacc=best_evalacc
            self.dl_roc_prc_signal.emit([tr_eval_metrics_matrix['auc'],tr_eval_metrics_matrix['prc']])
            self.dl_sn_sp_signal.emit([tr_eval_metrics_matrix['sn'],tr_eval_metrics_matrix['sp']])
            self.dl_acc_signal.emit([tr_eval_metrics_matrix['acc'],tr_tr_metrics_matrix['acc']])
            self.dl_loss_signal.emit([tr_eval_metrics_matrix['loss'],tr_tr_metrics_matrix['loss']])
            # self.dl_embed_signal.emit(pageData.best_model_state_dict['embed.weight'])

            TableWidget.set_Table_File(self.dl_ts_result_signal,self.dl_ts_result2file_signal,test_metrics_table_value,prefix_file+'testing_metrics')
            embedding_result=np.hstack([np.array(list(pageData.vocab.keys())).reshape(-1,1),pageData.best_model_state_dict['embed.weight'].cpu().numpy()])
            TableWidget.set_Table_File(self.embed_signal,self.embed2file_signal,embedding_result,pageData.type+'_'+pageData.encoding_panel.method+'_'+'embedding_result')
        
        pageData.model_save_path=pageData.model_selection_panel.method+'_model.pth'
        self.set_result_content_signal.emit()
    
    def start(self):
        global pageData
        global panelValue
        pageData.model_selection_panel=panelValue
        
        
        model=panelValue.method
        methodParam=panelValue.param
        division_method=panelValue.division_method
        division_param=panelValue.division_param
        self.predBtn.setDisabled(True)
        self.startBtn.setDisabled(True)
        self.saveBtn.setDisabled(True)

        prefix_file=pageData.type+'_'+pageData.encoding_panel.method+'_'+pageData.model_selection_panel.method+'_'
        
        
        try:            
            begin_time=time()
            if model in DL_MODEL:
                # self.modelFunc=getattr(model_selection.DL_model, 'run_net')
                model_run=DL_model(pageData,division_method,division_param,model,methodParam)
                model_run.trainer._signal.connect(self.refresh_dl_data)
                tr_eval_metrics_matrix,tr_tr_metrics_matrix,test_metrics,best_evalacc,pageData.best_model_state_dict=model_run.run_net()
                # test_metrics_table_value=model_selection.DL_model.Metrics.getMetricsTable({'Test':test_metrics},False)
                # pageData.test_metrics_table_value=test_metrics_table_value
                
                # if is_pred==False:
                #     pageData.best_evalacc=best_evalacc
                    
                #     self.dl_roc_prc_signal.emit([tr_eval_metrics_matrix['auc'],tr_eval_metrics_matrix['prc']])
                #     self.dl_sn_sp_signal.emit([tr_eval_metrics_matrix['sn'],tr_eval_metrics_matrix['sp']])
                #     self.dl_acc_signal.emit([tr_eval_metrics_matrix['acc'],tr_tr_metrics_matrix['acc']])
                #     self.dl_loss_signal.emit([tr_eval_metrics_matrix['loss'],tr_tr_metrics_matrix['loss']])
                #     # self.dl_embed_signal.emit(pageData.best_model_state_dict['embed.weight'])

                #     TableWidget.set_Table_File(self.dl_ts_result_signal,self.dl_ts_result2file_signal,test_metrics_table_value,prefix_file+'testing_metrics')
                #     embedding_result=np.hstack([np.array(list(pageData.vocab.keys())).reshape(-1,1),pageData.best_model_state_dict['embed.weight'].numpy()])
                #     TableWidget.set_Table_File(self.embed_signal,self.embed2file_signal,embedding_result,pageData.type+'_'+pageData.encoding_panel.method+'_'+'embedding_result')
                
                # pageData.model_save_path=pageData.model_selection_panel.method+'_model.pth'
            else:
                self.modelFunc=getattr(model_selection.ML_model, model)

                if pageData.feature_selection_data is not None:
                    feature_name=pageData.feature_selection_header[2:]
                    training_dataset,testing_dataset=pageData.getDataset(pageData.data_purpose,pageData.feature_selection_data)
                else:
                    feature_name=pageData.encoding_feature_name
                    training_dataset,testing_dataset=pageData.getDataset(pageData.data_purpose,pageData.encoding_array)

                trainingAndMean_metric_dict,testing_metric_dict,trAndMean_table,ts_table,aucData,prcData,training_score,testing_score,message=self.modelFunc(training_dataset,testing_dataset,pageData.training_sample_name,pageData.testing_sample_name,feature_name,division_method,division_param,methodParam)
                all_metrics_table_data=trAndMean_table
                if ts_table is not None:
                    all_metrics_table_data.append(ts_table)
                pageData.test_metrics_table_value=ts_table
                prefix_file=pageData.type+'_'+pageData.encoding_panel.method+'_'+pageData.model_selection_panel.method+'_'
                #metric table
                TableWidget.set_Table_File(self.outputData_signal,self.outputData2file_signal,all_metrics_table_data,prefix_file+'metrics')
                #training score table
                TableWidget.set_Table_File(self.training_score_signal,self.training_score2file_signal,training_score,prefix_file+'training_score')                
                #testing score table
                if testing_score is not None:
                    TableWidget.set_Table_File(self.testing_score_signal,self.testing_score2file_signal,testing_score,prefix_file+'testing_score')                
                if division_method!='LeaveOneOut':
                    self.roc_prc_signal.emit([aucData,prcData])
                    # self.roc_signal.emit(aucData)
                    # self.prc_signal.emit(prcData)
            end_time=time()
            run_time=end_time-begin_time
            print('Running time is %f'%run_time)

        except AttributeError as e:
            QMessageBox.warning(self, 'Warning', 'Method is not applicable to this data, please select again.', QMessageBox.Ok | QMessageBox.No,
                                QMessageBox.Ok)
        
        # header=list(result.columns)
        # row_name=list(result.index)
        # table_array=result.values
        # self.outputData_signal.emit(header,table_array,row_name)
        
        self.pre_signal.emit(pageData)
        self.set_result_content_signal.emit()
        self.next_btn_signal.emit(pageData)
        self.progress_bar.clear()
        self.predBtn.setDisabled(False)
        self.startBtn.setDisabled(False)
        self.saveBtn.setDisabled(False)
        # self.stopBtn.setVisible(False)
        
        # print(result)
    def get_table_info(self,result):
        if result is not None:
            return list(result.columns),result.values,list(result.index)
        else:
            return [],None,[]
    



class RocPrcCurveWidget(QTabWidget):
    def __init__(self):
        super().__init__()
        self.initUI()
    def initUI(self,isEpoch=False,minWidth=750,maxWidth=950):
        self.isEpoch=isEpoch
        self.setMinimumWidth(minWidth)
        self.setMaximumWidth(maxWidth)
        '''Set tab'''
        self.tab_roc_curve= QWidget()
        self.tab_prc_curve = QWidget()
        self.addTab(self.tab_roc_curve, " ROC curve ")
        self.addTab(self.tab_prc_curve, " PRC curve ")
        
        ''''Initialize tab'''
        self.set_tab_roc_curve()
        self.set_tab_prc_curve()
    
    def set_tab_roc_curve(self):
        self.tab_roc_curve.grid = QGridLayout(self.tab_roc_curve)
        self.tab_roc_curve.plotGraph = PlotWidgets.FigureWidget()
        self.tab_roc_curve.grid.addWidget(self.tab_roc_curve.plotGraph,0,0)

    def set_tab_prc_curve(self):
        self.tab_prc_curve.grid = QGridLayout(self.tab_prc_curve)
        self.tab_prc_curve.plotGraph = PlotWidgets.FigureWidget()
        self.tab_prc_curve.grid.addWidget(self.tab_prc_curve.plotGraph,0,0)

    def set_new_roc_plotWidget(self,Datas):
        self.tab_roc_curve.grid.removeWidget(self.tab_roc_curve.plotGraph)
        sip.delete(self.tab_roc_curve.plotGraph)
        self.tab_roc_curve.plotGraph = PlotWidgets.FigureWidget()
        if self.isEpoch:
            pass
        else:
            self.tab_roc_curve.plotGraph.figureCanvas.plotRocCurves(Datas)
        self.tab_roc_curve.grid.addWidget(self.tab_roc_curve.plotGraph,0,0)

    def set_new_prc_plotWidget(self,Datas):
        self.tab_prc_curve.grid.removeWidget(self.tab_prc_curve.plotGraph)
        sip.delete(self.tab_prc_curve.plotGraph)
        self.tab_prc_curve.plotGraph = PlotWidgets.FigureWidget()
        self.tab_prc_curve.plotGraph.figureCanvas.plotPrcCurves(Datas)
        self.tab_prc_curve.grid.addWidget(self.tab_prc_curve.plotGraph,0,0)

class BiCurveTabWidget(QTabWidget):
    def __init__(self,chartType,chartNameList,isEpoch=False,minWidth=600,maxWidth=800,maxHeight=300):
        super().__init__()
        self.chartType=chartType
        self.chartNameList=chartNameList
        self.isEpoch=isEpoch
        self.minWidth=minWidth
        self.maxWidth=maxWidth
        self.maxHeight=maxHeight
        self.initUI()
    def initUI(self):
        self.setMinimumWidth(self.minWidth)
        self.setMaximumWidth(self.maxWidth)
        self.setMaximumHeight(self.maxHeight)
        '''Set tab'''
        self.tab_first= QWidget()
        self.tab_second = QWidget()
        self.addTab(self.tab_first, self.chartNameList[0])
        self.addTab(self.tab_second, self.chartNameList[1])

        ''''Initialize tab'''
        self.set_tab_first()
        self.set_tab_second()
    
    def set_tab_first(self):
        self.tab_first.grid = QGridLayout(self.tab_first)
        self.tab_first.plotGraph = PlotWidgets.FigureWidget()
        self.tab_first.grid.addWidget(self.tab_first.plotGraph,0,0)

    def set_tab_second(self):
        self.tab_second.grid = QGridLayout(self.tab_second)
        self.tab_second.plotGraph = PlotWidgets.FigureWidget()
        self.tab_second.grid.addWidget(self.tab_second.plotGraph,0,0)

    def clear_graph(self):
        self.tab_first.grid.removeWidget(self.tab_first.plotGraph)
        self.tab_second.grid.removeWidget(self.tab_second.plotGraph)

        sip.delete(self.tab_first.plotGraph)
        sip.delete(self.tab_second.plotGraph)

        self.tab_first.plotGraph = PlotWidgets.FigureWidget()
        self.tab_second.plotGraph = PlotWidgets.FigureWidget()

        self.tab_first.grid.addWidget(self.tab_first.plotGraph,0,0)
        self.tab_second.grid.addWidget(self.tab_second.plotGraph,0,0)

    def set_new_graph(self,Datas):
        self.clear_graph()
        if self.isEpoch:
            nameList=self.chartType.split('_')
            self.tab_first.plotGraph.figureCanvas.plotEpochCurve(Datas[0],nameList[0])
            self.tab_second.plotGraph.figureCanvas.plotEpochCurve(Datas[1],nameList[1])
        elif self.chartType=='roc_prc':
            self.tab_first.plotGraph.figureCanvas.plotRocCurves(Datas[0])
            self.tab_second.plotGraph.figureCanvas.plotPrcCurves(Datas[1])


class GraphGroupBox(QGroupBox):
    def __init__(self,title,chartType,graphListname,isEpoch=False,minWidth=600,maxWidth=800,maxHeight=300):
        super().__init__()
        self.setTitle(title)
        self.setStyleSheet("QGroupBox {font: bold;}")
        self.chartType=chartType
        self.graphListname=graphListname
        self.isEpoch=isEpoch
        self.minWidth=minWidth
        self.maxWidth=maxWidth
        self.maxHeight=maxHeight
        self.initUI()
    def initUI(self):
        
        self.setMinimumWidth(self.minWidth)
        self.setMaximumWidth(self.maxWidth)
        self.setMaximumHeight(self.maxHeight)

        self.grid = QGridLayout(self)
        self.graphList=[]
        self.setNewGraphList()

    def setNewGraphList(self,row=1):
        for name in self.graphListname:
            exec('self.%s=%s'%(name,'PlotWidgets.FigureWidget()'))
            exec('self.%s.append(self.%s)'%('graphList',name))
       
        for i,graph in enumerate(self.graphList):
            self.grid.addWidget(graph,row,i)

    def clear_graph(self):
        for i,graph in enumerate(self.graphList):
            self.grid.removeWidget(graph)
            sip.delete(graph)
        self.graphList.clear()
        self.setNewGraphList()
        
    def set_new_graph(self,Datas):
        self.clear_graph()
        if self.isEpoch:
            nameList=self.chartType.split('_')
            for i,graph in enumerate(self.graphList):
                graph.figureCanvas.plotEpochCurve(Datas[i],nameList[i])                
        elif self.chartType=='roc_prc':
            nameList=self.chartType.split('_')
            for i,graph in enumerate(self.graphList):
                graph.figureCanvas.plotRocCurves(Datas[i],nameList[i])  



def swap(t1, t2):
    return t2, t1

#通用的
class TableWidget(QWidget):
    def __init__(self,minHeight=350,maxHeight=400,layout=[[0,0,1,1],[1,0,1,1]]):
        super().__init__()

        self.setMinimumHeight(minHeight)
        self.setMaximumHeight(maxHeight)
        self.layout=layout
        self.initUI()
    def initUI(self):
        self.reTable=ResultTable()
        self.downloadWidget=DownloadWidget()
        grid = QGridLayout()
        # grid.addWidget(self.reTable,0,0)
        # grid.addWidget(self.downloadWidget,1,0)
        grid.addWidget(self.reTable,self.layout[0][0],self.layout[0][1],self.layout[0][2],self.layout[0][3])
        grid.addWidget(self.downloadWidget,self.layout[1][0],self.layout[1][1],self.layout[1][2],self.layout[1][3])
        self.setLayout(grid)
    @staticmethod
    def get_table_info(result,index=None):
        import numpy as np
        if result is None:
            return [],None,[]
        if type(result)==np.ndarray:
            return [str(i) for i in range(result.shape[1])],result,[str(i) for i in range(result.shape[0])]
        else:
            if index is None:
                return list(result.columns),result.values,list(result.index)
            else:
                return [str(i) for i in range(result.shape[1])],result,index

    @staticmethod
    def set_Table_File(table_signal,file_signal,data,filename='t',index=None):
        header,table_array,row_name=TableWidget.get_table_info(data,index)
        table_signal.emit(header,table_array,row_name)
        file_signal.emit(filename,header,table_array)

class AllResultShowTableTab(QTabWidget):
    def __init__(self):
        super().__init__()
        self.initUI()

    def initUI(self):
        '''Set tab'''
        self.tab_training_score= TableWidget()
        self.tab_testing_score = TableWidget()
        self.addTab(self.tab_training_score, " Training score ")
        self.addTab(self.tab_testing_score, " Testing score ")
        
    def setData(self):#0814待修改
        pass

    def set_tab_training_score(self):
        pass

    def set_tab_testing_score(self):
        pass
class MLResultWidget(QWidget):
    def __init__(self):
        super().__init__()
        self.initUI()
    def initUI(self):
    
        self.curveWidget=BiCurveTabWidget('roc_prc',[" ROC curve "," PRC curve "],False,600,800,500)
        self.tableWidget=TableWidget()
        self.allResultShowTableTab=AllResultShowTableTab()        

        splitter_left0 = QSplitter(Qt.Horizontal)
        splitter_left0.addWidget(self.curveWidget)
        splitter_left0.addWidget(self.allResultShowTableTab)
        splitter_left0.setSizes([1000, 900])
        splitter_left0.setMinimumHeight(400)

        splitter = QSplitter(Qt.Vertical)
        splitter.addWidget(splitter_left0)
        splitter.addWidget(self.tableWidget)#存放最后的training和testing数据
        splitter.setSizes([10, 1000])

        layout = QVBoxLayout()
        layout.addWidget(splitter)
        self.setLayout(layout)
        
    def clearData(self):

        self.tableWidget.reTable.updateData([],[],np.array([]))
        
# class EmbedWidget(QGroupBox):
#     def __init__(self):
#         super().__init__()
#         self.setTitle('Embedding vector result')
#         self.setStyleSheet("QGroupBox {font: bold;}")
#         self.setMinimumHeight(250)
#         self.setMaximumHeight(300)
#         self.initUI()
#     def initUI(self):
#         self.embedChartWidget=PlotWidgets.FigureWidget()
#         self.tableWidget=TableWidget(180,230)

#         self.layout = QGridLayout()
#         self.layout.addWidget(self.embedChartWidget,0,0)
#         self.layout.addWidget(self.tableWidget,0,1)        
#         self.setLayout(self.layout)
#     def updateData(self,data):
#         self.clearGraphData()
#         self.embedChartWidget.figureCanvas.plotEmbed(tsne(data),list(pageData.vocab.keys()),'embedding vector result')
#     def clearGraphData(self):
#         self.layout.removeWidget(self.embedChartWidget)
#         sip.delete(self.embedChartWidget)
#         self.embedChartWidget = PlotWidgets.FigureWidget()
#         self.layout.addWidget(self.embedChartWidget,0,0)
class EmbedWidget(QGroupBox):
    def __init__(self):
        super().__init__()
        self.setTitle('Embedding vector result')
        self.setStyleSheet("QGroupBox {font: bold;}")
        self.setMinimumHeight(250)
        self.setMaximumHeight(300)
        self.initUI()
    def initUI(self):
        # self.embedChartWidget=PlotWidgets.FigureWidget()
        self.tableWidget=TableWidget(180,230)

        self.layout = QGridLayout()
        # self.layout.addWidget(self.embedChartWidget,0,0)
        self.layout.addWidget(self.tableWidget,0,1)        
        self.setLayout(self.layout)
    # def updateData(self,data):
    #     self.clearGraphData()
    #     self.embedChartWidget.figureCanvas.plotEmbed(tsne(data),list(pageData.vocab.keys()),'embedding vector result')
    # def clearGraphData(self):
    #     self.layout.removeWidget(self.embedChartWidget)
    #     sip.delete(self.embedChartWidget)
    #     self.embedChartWidget = PlotWidgets.FigureWidget()
    #     self.layout.addWidget(self.embedChartWidget,0,0)
class DLResultWidget(QWidget):
    def __init__(self):
        super().__init__()
        # 哎呀忘记了还有一个MCC什么的表格还要放上去
        # self.graphListname=['graphTrACC','graphEvalACC','graphTrLOSS','graphEvalLOSS','graphTrLOSS']
        self.initUI()
    def initUI(self):
        self.embedWidget=EmbedWidget()
        # self.rocPrcWidget=BiCurveTabWidget('eval/roc_eval/prc',[" ROC curve "," PRC curve "],True,600,800,300)
        # self.snSpWidget=BiCurveTabWidget('eval/sn_eval/sp',[" SN curve "," SP curve "],True)
        self.rocPrcWidget=GraphGroupBox('ROC PRC','eval/roc_eval/prc',[" ROC_curve "," PRC_curve "],True,1200,1500,500)
        self.snSpWidget=GraphGroupBox('SN SP','eval/sn_eval/sp',[" SN_curve "," SP_curve "],True,1200,1500,500)
        self.accWidget=GraphGroupBox('ACC','eval/acc_train/acc',["eval_acc","train_acc"],True,1200,1500,500)
        self.lossWidget=GraphGroupBox('LOSS','eval/loss_train/loss',["eval_loss","train_loss"],True,1200,1500,500)

        self.tableWidget=TableWidget(80,90,[[0,0,1,1],[0,1,1,1]])

        layout = QGridLayout()
        
        # layout.addWidget(self.accWidget,1,0)
        # layout.addWidget(self.lossWidget,2,0)

        # layout.addWidget(self.embedWidget,0,0,1,2)
        # layout.addWidget(self.snSpWidget,1,1)
        # layout.addWidget(self.rocPrcWidget,2,1)

        # layout.addWidget(self.tableWidget,3,0,1,2)
        
        self.metricWidget=QTabWidget()
        self.metricWidget.addTab(self.accWidget, 'ACC')
        self.metricWidget.addTab(self.lossWidget, 'LOSS')
        self.metricWidget.addTab(self.snSpWidget, 'SN/SP')
        # self.metricWidget.addTab(self.rocPrcWidget, 'ROC/PRC')

        layout.addWidget(self.metricWidget,1,0)
        # layout.addWidget(self.lossWidget,2,0)

        layout.addWidget(self.embedWidget,0,0)
        # layout.addWidget(self.snSpWidget,1,1)
        # layout.addWidget(self.rocPrcWidget,2,1)

        # layout.addWidget(self.tableWidget,3,0,1,2)

        self.setLayout(layout)
    def clearData(self):
        pass
        # before data
        
        # self.set_tab_encoding_distribution()
        # self.tab_statistical_info.clear()
        # self.tableWidget.reTable.updateData([],[],np.array([]))
class ResultWidget(QWidget):
    def __init__(self):
        super().__init__()
        self.initUI()
    def initUI(self):
        self.MLResultWidget=MLResultWidget()
        self.MLResultWidget.setVisible(False)

        self.DLResultWidget=DLResultWidget()
        self.DLResultWidget.setVisible(False)
        
        layout = QVBoxLayout()
        layout.addWidget(self.MLResultWidget)
        layout.addWidget(self.DLResultWidget)
        self.setLayout(layout)
    def showContent(self):
        if pageData.model_selection_panel.method in DL_MODEL:
            self.MLResultWidget.setVisible(False)
            self.DLResultWidget.setVisible(True)
        else:
            self.MLResultWidget.setVisible(True)
            if pageData.model_selection_panel.division_method=='LeaveOneOut':
                self.MLResultWidget.curveWidget.setVisible(False)
            else:
                self.MLResultWidget.curveWidget.setVisible(True)
            self.DLResultWidget.setVisible(False)
    def clearData(self):
        self.MLResultWidget.clearData()
        self.DLResultWidget.clearData()





class ModelSelectionContentWidget(QWidget):
    # next_set_date_signal=pyqtSignal(object,object)
    def __init__(self,data=''):
        super().__init__()
        global pageData
        pageData=PageData()
        self.pageData=pageData
        
        global panelValue
        panelValue=PanelValue()
        self.panelValue=panelValue


        self.initUI()
    def initUI(self):

        self.allmethodWidget=AllMethodWidget()
        self.resultWidget=ResultWidget()
    #         def refresh_division_param
    # def refresh_model_param
        # set connection
        global panelValue
        panelValue.refresh_division_signal.connect(self.allmethodWidget.curParaWidget.refresh_division_param)
        panelValue.refresh_signal.connect(self.allmethodWidget.curParaWidget.refresh_model_param)

        # self.allmethodWidget.chooseWidget.outputData_signal.connect(self.resultWidget.showContent)
        self.allmethodWidget.chooseWidget.set_result_content_signal.connect(self.resultWidget.showContent)
        # set MLResultWidget connection
        self.allmethodWidget.chooseWidget.outputData_signal.connect(self.resultWidget.MLResultWidget.tableWidget.reTable.updateData)
        self.allmethodWidget.chooseWidget.training_score_signal.connect(self.resultWidget.MLResultWidget.allResultShowTableTab.tab_training_score.reTable.updateData)
        self.allmethodWidget.chooseWidget.testing_score_signal.connect(self.resultWidget.MLResultWidget.allResultShowTableTab.tab_testing_score.reTable.updateData)
        self.allmethodWidget.chooseWidget.outputData2file_signal.connect(self.resultWidget.MLResultWidget.tableWidget.downloadWidget.setFile)
        self.allmethodWidget.chooseWidget.training_score2file_signal.connect(self.resultWidget.MLResultWidget.allResultShowTableTab.tab_training_score.downloadWidget.setFile)
        self.allmethodWidget.chooseWidget.testing_score2file_signal.connect(self.resultWidget.MLResultWidget.allResultShowTableTab.tab_testing_score.downloadWidget.setFile)
        self.allmethodWidget.chooseWidget.roc_prc_signal.connect(self.resultWidget.MLResultWidget.curveWidget.set_new_graph)
        

        self.allmethodWidget.chooseWidget.dl_roc_prc_signal.connect(self.resultWidget.DLResultWidget.rocPrcWidget.set_new_graph)
        self.allmethodWidget.chooseWidget.dl_sn_sp_signal.connect(self.resultWidget.DLResultWidget.snSpWidget.set_new_graph)
        self.allmethodWidget.chooseWidget.dl_acc_signal.connect(self.resultWidget.DLResultWidget.accWidget.set_new_graph)
        self.allmethodWidget.chooseWidget.dl_loss_signal.connect(self.resultWidget.DLResultWidget.lossWidget.set_new_graph)
        # self.allmethodWidget.chooseWidget.dl_embed_signal.connect(self.resultWidget.DLResultWidget.embedWidget.updateData)
        self.allmethodWidget.chooseWidget.embed_signal.connect(self.resultWidget.DLResultWidget.embedWidget.tableWidget.reTable.updateData)
        self.allmethodWidget.chooseWidget.embed2file_signal.connect(self.resultWidget.DLResultWidget.embedWidget.tableWidget.downloadWidget.setFile)
        self.allmethodWidget.chooseWidget.dl_ts_result_signal.connect(self.resultWidget.DLResultWidget.tableWidget.reTable.updateData)
        self.allmethodWidget.chooseWidget.dl_ts_result2file_signal.connect(self.resultWidget.DLResultWidget.tableWidget.downloadWidget.setFile)

        splitter0 = QSplitter(Qt.Horizontal)
        splitter0.addWidget(self.allmethodWidget)
        splitter0.addWidget(self.resultWidget)
        splitter0.setSizes([10, 1000])

        #Set grid
        grid = QGridLayout()
        grid.addWidget(splitter0, 0, 0,1,2)
        self.setLayout(grid)
    def setdata(self,data):
        global pageData
        self.pageData=data
        pageData=data

        if data==None:
            QMessageBox.about(self, 'Warning','Data is empty')
        else:
            # showstr='Total data number is '+str(pageData.data_num)+'\n'+\
            #   ' - Training data number is : '+str(pageData.data_train_num)+'\n - Testing  data number is : '+str(pageData.data_test_num)
            # if pageData.feature_selection_data is not None:
            #     showstr=showstr+'\nThe number of features after feature selection :'+pageData.feature_selection_panel.param['feature_number']
            # self.allmethodWidget.dataWidget.datainfo.setText(showstr)  
            self.allmethodWidget.chooseWidget.pre_signal.emit(pageData)

        
